﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Notes.Domain
{
    [Table("MPR_Master")]
    public class vc_notes_MPR_Master
    {
        [Key]
        public String DocNo { get; set; }

        public string ApplicantCN { get; set; }
        public string MainUnitName { get; set; }
        public string ApplicantCareer { get; set; }
        public DateTime ApplicantCreatorDate { get; set; }
        public string SysComment { get; set; }
        public string ProbComment { get; set; }
        public string ProsComment { get; set; }
        public DateTime ReqDate { get; set; }
        public DateTime DisDate { get; set; }
        public string PrcEmpCName { get; set; }
        public string ActualPrcEmpCName { get; set; }
        public DateTime CalDate { get; set; }
        public DateTime CalDate_1 { get; set; }
        public DateTime ConfirmDate { get; set; }
        public int RateProgress { get; set; }
        public string ProcComment { get; set; }
        public DateTime ReceiveDate { get; set; }
        public DateTime AcceptDate { get; set; }
        public DateTime Updata_date { get; set; }
        public string IsFinish { get; set; }
        public string SysModel { get; set; }
        public string ACTIVITYOS { get; set; }
        public string WorkType { get; set; }
        public string WorkHours { get; set; }
    }
}