﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Notes.Domain
{
    [Table("Nas005_Master")]
    public class vc_notes_Nas005_Master
    {
        [Key]
        public String DocNo { get; set; }

        public string FillerCName { get; set; }
        public string FillerDEPOS { get; set; }
        public string CName { get; set; }
        public DateTime ApplicantCreatorDate { get; set; }
        public string MainUnitName { get; set; }
        public string EmpNo { get; set; }
        public string Acct { get; set; }
        public string AcctDesc { get; set; }
        public string Needdescription { get; set; }
        public string Analysisdescription { get; set; }
        public string PrcEmpCName { get; set; }
        public string Description { get; set; }
        public DateTime ReceiveDate { get; set; }
        public DateTime FinishDate { get; set; }
        public string Type { get; set; }
        public string Result { get; set; }
        public string Type1 { get; set; }
        public string IsChange { get; set; }
        public string IsFinish { get; set; }
    }
}