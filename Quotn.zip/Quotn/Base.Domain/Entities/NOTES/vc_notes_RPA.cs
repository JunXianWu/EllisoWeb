﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Notes.Domain
{
    [Table("RPA")]
    public class vc_notes_RPA
    {
        [Key]
        public String DocNo { get; set; }

        public DateTime ApplicantCreatorDate { get; set; }
        public string NotesDept { get; set; }
        public string ContactNm { get; set; }
        public string ContactTel { get; set; }
        public string ProbType { get; set; }
        public string IENum { get; set; }
        public string site { get; set; }
        public string ItemCode { get; set; }
        public string ItemQty { get; set; }
        public string CauseCommentTxt { get; set; }
        public string DeptMemberCN { get; set; }
        public string PrcEmpCName { get; set; }
        public string Expense { get; set; }
        public DateTime ReceiveDate { get; set; }
        public DateTime FinshDate { get; set; }
        public string FixType { get; set; }
        public string ItemCodeType { get; set; }
        public string IsFinish { get; set; }
        public string Q1 { get; set; }
        public string Q2 { get; set; }
        public string Q3 { get; set; }
        public string Q4 { get; set; }
        public string Q4_Reply { get; set; }
    }
}