﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_SAcustomer")]
    public class vc_SAcustomer
    {
        [Key,Column(Order=1)]
        public string cust_num { get; set; }

        public String name { get; set; }
        public string slsman_num { get; set; }
        public string slsman_name { get; set; }
        public string Area2 { get; set; }
        public string Area3 { get; set; }
        public string Area5 { get; set; }
        public string Channel1 { get; set; }
        public string Channel2 { get; set; }
        public string cust_type { get; set; }
    }
}