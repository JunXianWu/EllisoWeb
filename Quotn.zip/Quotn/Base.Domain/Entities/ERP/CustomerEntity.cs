﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Domain
{
    [Table("customer_mst")]
    public class CustomerEntity
    {
        [Key,Column(Order=1)]
        public int cust_seq { get; set; }

        [Key, Column(Order = 2)]
        public string cust_num { get; set; }

        [Key, Column(Order = 3)]
        public string site_ref { get; set; }

        public string cust_type { get; set; }

        public string slsman { get; set; }
    }
}