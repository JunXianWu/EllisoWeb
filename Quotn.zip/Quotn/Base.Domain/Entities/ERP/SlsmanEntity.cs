﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Domain
{
    [Table("slsman_mst")]
    public class SlsmanEntity
    {
        [Key,Column(Order=1)]
        public string slsman { get; set; }

        [Key, Column(Order = 2)]
        public String site_ref { get; set; }

        public string ref_num { get; set; }
    }
}