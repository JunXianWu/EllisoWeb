﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Domain
{
    [Table("custaddr_mst")]
    public class CustAddrEntity
    {
        [Key,Column(Order=1)]
        public string cust_num { get; set; }

        [Key, Column(Order = 2)]
        public int cust_seq { get; set; }

        [Key, Column(Order = 3)]
        public string site_ref { get; set; }

        public string name { get; set; }

        public string country { get; set; }

        public string external_email_addr { get; set; }
    }
}