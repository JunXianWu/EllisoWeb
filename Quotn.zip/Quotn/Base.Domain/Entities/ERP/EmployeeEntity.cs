﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Domain
{
    [Table("employee_mst")]
    public class EmployeeEntity
    {
        [Key,Column(Order=1)]
        public string emp_num { get; set; }

        [Key, Column(Order = 2)]
        public String site_ref { get; set; }

        public string name { get; set; }
    }
}