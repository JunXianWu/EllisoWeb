﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Domain
{
    [Table("custtype_mst")]
    public class CustTypeEntity
    {
        [Key,Column(Order=1)]
        public string cust_type { get; set; }

        [Key, Column(Order = 2)]
        public String site_ref { get; set; }

        public string description { get; set; }
    }
}