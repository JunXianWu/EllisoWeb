﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace IMS.Domain
{
    [Table("vc_ims_GroupFunction")]
    public class GroupFunctionEntity
    {
        [Key, Column(Order = 1)]
        public int GrpId { get; set; }

        [Key, Column(Order = 2)]
        public int FuncId { get; set; }

        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}