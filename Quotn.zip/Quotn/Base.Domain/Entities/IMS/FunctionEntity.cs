﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace IMS.Domain
{
    [Table("vc_ims_Function")]
    public class FunctionEntity
    {
        [Key]
        public int FuncId { get; set; }
        public string FuncName { get; set; }
        public string Node_Name { get; set; }
        public int NodeId { get; set; }
        public int NodeSeq { get; set; }
        public int ParentID { get; set; }
        public string Url { get; set; }
        public byte Enabled { get; set; }
        public string Icon { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}