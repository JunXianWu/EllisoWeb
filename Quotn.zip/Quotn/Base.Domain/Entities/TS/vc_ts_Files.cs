﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TS.Domain
{
    [Table("vc_ts_Files")]
    public class vc_ts_Files
    {
        [Key]
        public int Id { get; set; }

        public String Name { get; set; }
        public String ContentType { get; set; }
        public byte[] Data { get; set; }
    }
}