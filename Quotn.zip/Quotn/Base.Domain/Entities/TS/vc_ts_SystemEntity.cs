﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TS.Domain
{
    [Table("vc_ts_SystemParam")]
    public class vc_ts_SystemEntity
    {
        [Key, Column(Order = 1)]
        [DisplayName("參數序號")]
        public int ParamId { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("參數名稱")]
        public string ParamName { get; set; }

        [DisplayName("參數值")]
        public string ParamValue { get; set; }

        [Key, Column(Order = 3)]
        [DisplayName("參數單位")]
        public string ParamUm { get; set; }

        [DisplayName("順序")]
        public int Order { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateDate { get; set; }

        [DisplayName("建立者")]
        public string CreateUser { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateDate { get; set; }

        [DisplayName("更新者")]
        public string UpdateUser { get; set; }
    }
}