﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TS.Domain
{
    [Table("vc_ts_Employee")]
    public class vc_ts_Employee
    {
        [Key]
        public string EmployeeId { get; set; }

        public string EmployeeAd { get; set; }

        public string EmployeeName { get; set; }

        public string DepartmentId { get; set; }

        public Boolean IsAdmin { get; set; }
    }
}