﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace TS.Domain
{
    [Table("vc_ts_Timesheet")]
    public class vc_ts_Timesheet
    {
        [Key, Column(Order = 1)]
        public int TimeSheetId { get; set; }

        [Key, Column(Order = 2)]
        public int Seq { get; set; }

        [Key, Column(Order = 3)]
        public string EmployeeAd { get; set; }

        public int ParentSeq { get; set; }
        public int Order { get; set; }
        public string DocNo { get; set; }
        public string Category { get; set; }
        public string Item { get; set; }
        public string ItemDesc { get; set; }
        public string Question { get; set; }
        public decimal TtlTime { get; set; }
        public decimal ThisWeekTime { get; set; }
        public decimal LastWeekSchedule { get; set; }
        public decimal ThisWeekForecast { get; set; }
        public decimal ThisWeekActual { get; set; }
        public string InputDate { get; set; }
        public string OverDueList { get; set; }
        public string ForecastDate { get; set; }
        public string EditForecastDate { get; set; }
        public string CompleteDate { get; set; }
        public string IsPost { get; set; }
        public string Url { get; set; }
	    public DateTime CreateDate { get; set; }
        public DateTime UpdateDate { get; set; }
    }
}