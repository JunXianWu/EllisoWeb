﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_QuantityMag")]
    public class vc_quotn_QuantityMag
    {
        [Key, Column(Order = 1)]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("顏色")]
        public string Color { get; set; }

        [DisplayName("極少量報價")]
        public string QtyMag1 { get; set; }

        [DisplayName("少量報價")]
        public string QtyMag2 { get; set; }

        [DisplayName("小型經銷")]
        public string QtyMag3 { get; set; }

        [DisplayName("中型經銷")]
        public string QtyMag4 { get; set; }

        [DisplayName("大型經銷")]
        public string QtyMag5 { get; set; }

        [DisplayName("備註")]
        public string Memo { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }

    [Table("vc_quotn_QuantityMagHist")]
    public class vc_quotn_QuantityMagHist
    {
        [Key,Column(Order=1)]
        [DisplayName("流水號")]
        public Int64 Seq { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [Key, Column(Order = 3)]
        [DisplayName("顏色")]
        public string Color { get; set; }

        [DisplayName("極少量報價")]
        public string QtyMag1 { get; set; }

        [DisplayName("少量報價")]
        public string QtyMag2 { get; set; }

        [DisplayName("小型經銷")]
        public string QtyMag3 { get; set; }

        [DisplayName("中型經銷")]
        public string QtyMag4 { get; set; }

        [DisplayName("大型經銷")]
        public string QtyMag5 { get; set; }

        [DisplayName("備註")]
        public string Memo { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }
}