﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_CategoryParam")]
    public class vc_quotn_CategoryParam
    {
        [Key]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [DisplayName("分類名稱")]
        public string CategoryName { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }

    [Table("vc_quotn_CategoryParamHist")]
    public class vc_quotn_CategoryParamHist
    {
        [Key,Column(Order=1)]
        [DisplayName("流水號")]
        public Int64 Seq { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [DisplayName("分類名稱")]
        public string CategoryName { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }
}