﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_Sequence")]
    public class vc_quotn_Sequence
    {
        [Key]
        [DisplayName("序列代號")]
        public string SequenceId { get; set; }

        [DisplayName("序列名稱")]
        public string SequenceName { get; set; }

        [DisplayName("序列號")]
        public Int64 Sequence { get; set; }
    }
}