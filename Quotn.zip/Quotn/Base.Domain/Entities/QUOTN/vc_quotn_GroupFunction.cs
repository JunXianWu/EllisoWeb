﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_GroupFunction")]
    public class vc_quotn_GroupFunction
    {
        [Key, Column(Order = 1)]
        [DisplayName("群組編號")]
        public int GrpId { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("功能編號")]
        public int FuncId { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }
    }
}