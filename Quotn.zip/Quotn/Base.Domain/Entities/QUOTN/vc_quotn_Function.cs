﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_Function")]
    public class vc_quotn_Function
    {
        [Key]
        [DisplayName("功能編號")]
        public int FuncId { get; set; }

        [DisplayName("功能名稱")]
        public string FuncName { get; set; }

        [DisplayName("節點編號")]
        public int NodeId { get; set; }

        [DisplayName("節點序號")]
        public int NodeSeq { get; set; }

        [DisplayName("父編號")]
        public int ParentID { get; set; }

        [DisplayName("連結位置")]
        public string Url { get; set; }

        [DisplayName("是否啟用")]
        public byte Enabled { get; set; }

        [DisplayName("小圖")]
        public string Icon { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }
    }
}