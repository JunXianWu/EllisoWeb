﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_Group")]
    public class vc_quotn_Group
    {
        [Key]
        [DisplayName("群組編號")]
        public int GrpId { get; set; }

        [DisplayName("群組名稱")]
        public string GrpName { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }

    }
}
