﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Quotn.Domain
{
    [Table("vc_quotn_AreaMag")]
    public class vc_quotn_AreaMag
    {
        [Key, Column(Order = 1)]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("區域代號")]
        public string AreaId { get; set; }

        [DisplayName("區域倍率")]
        public decimal AreaMag { get; set; }

        [DisplayName("備註")]
        public string Memo { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }

    [Table("vc_quotn_AreaMagHist")]
    public class vc_quotn_AreaMagHist
    {
        [Key,Column(Order=1)]
        [DisplayName("流水號")]
        public Int64 Seq { get; set; }

        [Key, Column(Order = 2)]
        [DisplayName("分類代號")]
        public string CategoryId { get; set; }

        [Key, Column(Order = 3)]
        [DisplayName("區域代號")]
        public string AreaId { get; set; }

        [DisplayName("區域倍率")]
        public decimal AreaMag { get; set; }

        [DisplayName("備註")]
        public string Memo { get; set; }

        [DisplayName("建立日期")]
        public DateTime CreateTime { get; set; }

        [DisplayName("建立者")]
        public string Creator { get; set; }

        [DisplayName("更新日期")]
        public DateTime UpdateTime { get; set; }

        [DisplayName("更新者")]
        public string Updator { get; set; }
    }
}