﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base.Service.Utils
{
    public static class DateHandle
    {

        public static String[] CalWeekMonSun(String dateStr)
        {
            var date = DateTime.ParseExact(dateStr.ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            //取得該日期的當週第一天
            string firstday = date.AddDays(-Convert.ToInt16((int)date.DayOfWeek) + 1).ToString("yyyy/MM/dd");


            //取得該日期的當週最後一天，如果取到的dayofweek為0表示星期日，則不需要再減日期
            string lastday = "";
            int lsint = (int)Convert.ToDateTime(firstday).DayOfWeek;
            if (lsint > 0)
                lastday = Convert.ToDateTime(firstday).AddDays(7 - lsint).ToString("yyyy/MM/dd");
            else lastday = firstday;

            String[] weekRange = new String[2];
            weekRange[0] = firstday;
            weekRange[1] = lastday;

            return weekRange;
        }
    }
}
