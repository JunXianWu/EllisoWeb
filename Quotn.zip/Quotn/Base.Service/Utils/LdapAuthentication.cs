﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Principal;
using System.Runtime.InteropServices;
using System.DirectoryServices;

namespace Base.Service.Utils
{
    public class LdapAuthentication
    {

        private string _path;

        private string _filterAttribute;

        public string OS_Version()
        {
            OperatingSystem osInfo;
            string sAns = "1";
            osInfo = System.Environment.OSVersion;

            if (osInfo.Platform == PlatformID.Win32NT)
            {
                switch (osInfo.Version.Major)
                {
                    case 3:
                        // sAns = "Windows NT 3.51"
                        break;
                    case 4:
                        // sAns = "Windows NT 4.0"
                        break;
                    case 5:
                        if ((osInfo.Version.Minor == 0))
                        {
                            // sAns = "Windows 2000"
                            sAns = "0";
                        }
                        else if ((osInfo.Version.Minor == 1))
                        {
                            // sAns = "Windows XP"
                            sAns = "1";
                        }
                        else if ((osInfo.Version.Minor == 2))
                        {
                            // sAns = "Windows Server 2003"
                            sAns = "1";
                        }
                        else
                        {
                            // sAns = "Unknown Windows Version"
                            sAns = "1";
                        }

                        break;
                }
            }
            return sAns;
        }

        public LdapAuthentication(string path)
        {
            _path = path;
        }

        //驗證帳號、密碼有無錯誤
        public bool IsAuthenticated(string domain, string username, string pwd)
        {
            string domainAndUsername = (domain + ("\\" + username));
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            try
            {
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = ("(SAMAccountName="
                            + (username + ")"));
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                if ((result == null))
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                // Throw New Exception("帳號或密碼錯誤，請輸入電腦開機的帳號和密碼! ")
                // Throw New Exception("Error authenticating user. " & ex.Message)
                return false;
            }

            // Dim DC = Split(domain, ".")
            // Dim i As Integer
            // Try
            //     Dim ADPath As String
            //     ADPath = "LDAP://" & domain & "/CN=Users"
            //     For i = 0 To UBound(DC)
            //         ADPath = ADPath & ",DC=" & DC(i)
            //     Next
            //     Dim entry As New DirectoryServices.DirectoryEntry(ADPath, username, pwd, 1)
            //     Dim searcher As New DirectoryServices.DirectorySearcher("(&(objectCategory=person)(objectClass=user))")
            //     searcher.SearchRoot = entry
            //     Dim strResultSet As String
            //     searcher.PropertiesToLoad.Add("sAMAccountName")
            //     strResultSet = searcher.FindOne.ToString
            //     IsAuthenticated = True
            // Catch ex As Exception
            //     Throw New Exception("帳號或密碼錯誤，請輸入電腦開機的帳號和密碼! ")
            //     'Throw New Exception("Error authenticating user. " & ex.Message)
            //     IsAuthenticated = False
            // End Try
        }

        public bool IsAuthenticated(string domain, string username, string pwd, ref string Name)
        {
            string domainAndUsername = (domain + ("\\" + username));
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            try
            {
                // Bind to the native AdsObject to force authentication.            
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = ("(SAMAccountName="
                            + (username + ")"));
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                if ((result == null))
                {
                    return false;
                }

                // Update the new path to the user in the directory.
                _path = result.Path;
                _filterAttribute = ((string)(result.Properties["cn"][0]));
                Name = ((string)(result.Properties["cn"][0]));
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        //抓使用者姓名�
        public string GetUserName(string domain, string username, string pwd)
        {
            string domainAndUsername = (domain + ("\\" + username));
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            try
            {
                // Bind to the native AdsObject to force authentication.            
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = ("(SAMAccountName="
                            + (username + ")"));
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                if ((result == null))
                {
                    return "";
                }

                // Update the new path to the user in the directory.
                _path = result.Path;
                return ((string)(result.Properties["cn"][0]));
            }
            catch (Exception ex)
            {
                return "";
            }

        }
    }
}
