﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Web.Mvc;

namespace Base.Service.Utils
{
    public class DropDownList
    {

        public Hashtable getTimeSheetDropDownList()
        {

            List<SelectListItem> priorityItem = new List<SelectListItem>();
            priorityItem.Add(new SelectListItem
            {
                Text = "",
                Value = "0"
            });
            priorityItem.Add(new SelectListItem
            {
                Text = "1",
                Value = "1"
            });
            priorityItem.Add(new SelectListItem
            {
                Text = "2",
                Value = "2",
                Selected = true
            });
            priorityItem.Add(new SelectListItem
            {
                Text = "3",
                Value = "3"
            });

            List<SelectListItem> categoryItem = new List<SelectListItem>();
            categoryItem.Add(new SelectListItem
            {
                Text = "",
                Value = "0"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "系統問題單",
                Value = "1"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "系統需求單",
                Value = "2"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "設備維修單",
                Value = "3"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "設備需求單",
                Value = "4"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "資訊系統及網路使用申請單",
                Value = "5"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "專案",
                Value = "6"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "會議",
                Value = "7"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "追蹤",
                Value = "8"
            });
            categoryItem.Add(new SelectListItem
            {
                Text = "其他",
                Value = "9"
            });

            Hashtable returnHt = new Hashtable();
            returnHt.Add("priority", priorityItem);
            returnHt.Add("category", categoryItem);

            return returnHt;
        }


        public List<SelectListItem> getTrueFalseDownList()
        {

            List<SelectListItem> item = new List<SelectListItem>();
            item.Add(new SelectListItem
            {
                Text = "否",
                Value = "0"
            });
            item.Add(new SelectListItem
            {
                Text = "是",
                Value = "1"
            });

            return item;
        }

        public List<SelectListItem> getColorDownList()
        {

            List<SelectListItem> item = new List<SelectListItem>();
            item.Add(new SelectListItem
            {
                Text = "",
                Value = ""
            });
            item.Add(new SelectListItem
            {
                Text = "GS",
                Value = "GS"
            });
            item.Add(new SelectListItem
            {
                Text = "Matt",
                Value = "Matt"
            });
            item.Add(new SelectListItem
            {
                Text = "Color",
                Value = "Color"
            });

            return item;
        }
    }
}
