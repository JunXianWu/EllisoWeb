﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Base.Service.Utils
{
    public static class StringHandle
    {

        public static string TrimEachLine(string TrimString)
        {
            if (TrimString == null) return "";

            StringBuilder sbTrimString = new StringBuilder();
            string[] Separators = new string[] { Environment.NewLine };
            string[] aryString = TrimString.Split(Separators, StringSplitOptions.None);

            foreach (string LineString in aryString)
            {
                if (LineString.Trim().Length>0)
                sbTrimString.Append(LineString.Trim() + Environment.NewLine);
            }

            return sbTrimString.ToString();
        }
    }
}
