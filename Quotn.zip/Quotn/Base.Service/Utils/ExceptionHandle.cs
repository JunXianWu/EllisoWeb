﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.Infrastructure;

namespace Base.Service.Utils
{
    public static class ExceptionHandle
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static String getExceptionMsg(Exception ex)
        {
            String msg = "";

            if (ex.InnerException != null)
            {
                if (ex.InnerException.GetType().FullName.Equals("System.Data.UpdateException"))
                {
                    DbUpdateException bbUpdateException = (DbUpdateException)ex;
                    msg = bbUpdateException.InnerException.InnerException.Message;

                    if (msg.Contains("REFERENCE 條件約束"))
                    {
                        msg = "資料庫存在外鍵被引用，無法刪除";
                    }
                }
            }
            else
            {
                msg = ex.Message;

                if (ex.Message.Contains("相同索引"))
                {
                    msg = "資料庫存在主鍵，無法新增";
                }
            }

            logger.Error(msg);

            return msg;
        }
    }
}
