﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using TS.Data;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace TS.Service
{
    /// <summary>
    /// TsEmployeeService Interface
    /// </summary>
    public interface ITsTimesheetHistService
    {
        /// <summary>
        ///  Get All TimesheetHist
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_ts_TimesheetHist> GetTimesheetHists();

        /// <summary>
        /// Get TimesheetHist by TimesheetId
        /// </summary>
        /// <param name="TimesheetId"></param>
        /// <returns>vc_ts_TimesheetHist</returns>
        vc_ts_TimesheetHist GetTimesheetHistById(int timesheetId);

        /// <summary>
        /// Get TimesheetHist by EmployeeAd
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <returns>vc_ts_TimesheetHist</returns>
        vc_ts_TimesheetHist GetTimesheetHistByAd(String employeeAd);

        /// <summary>
        /// Get TimesheetHists by EmployeeAd,TimesheetId,Seq
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <param name="seq"></param>
        /// <returns>IEnumerable<vc_ts_TimesheetHist></returns>
        IEnumerable<vc_ts_TimesheetHist> GetTimesheetHistsByAdIdSeq(String employeeAd, int timesheetId, int seq);

        /// <summary>
        /// Add TimesheetHist Record
        /// </summary>
        /// <param name="timesheetHist">vc_ts_TimesheetHist</param>
        void CreateTimesheetHist(vc_ts_TimesheetHist timesheetHist);

        /// <summary>
        /// Update TimesheetHist Record
        /// </summary>
        /// <param name="timesheetHist">vc_ts_TimesheetHist</param>
        void UpdateTimesheetHist(vc_ts_TimesheetHist timesheetHist);

        /// <summary>
        /// Delete TimesheetHist by TimesheetId
        /// </summary>
        /// <param name="TimesheetId">TimesheetId</param>
        void DeleteTimesheetHist(int timesheetId);

        /// <summary>
        /// Commit TimesheetHist
        /// </summary>
        void Save();
    }

    public class TsTimesheetHistService : ITsTimesheetHistService
    {
        private readonly ITsTimesheetHistRepository tsTimesheetHistRepository;
        private readonly IUnitOfWork unitOfWork;

        public TsTimesheetHistService(ITsTimesheetHistRepository tsTimesheetHistRepository, IUnitOfWork unitOfWork)
        {
            this.tsTimesheetHistRepository = tsTimesheetHistRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_ts_TimesheetHist> GetTimesheetHists()
        {
            var timesheetHists = tsTimesheetHistRepository.GetAll();
            return timesheetHists;
        }

        public vc_ts_TimesheetHist GetTimesheetHistById(int timesheetId)
        {
            vc_ts_TimesheetHist timesheetHist = tsTimesheetHistRepository.Get(x => x.TimeSheetId == timesheetId);
            return timesheetHist;
        }

        public vc_ts_TimesheetHist GetTimesheetHistByAd(String employeeAd)
        {
            vc_ts_TimesheetHist timesheetHist = tsTimesheetHistRepository.Get(x => x.EmployeeAd == employeeAd);
            return timesheetHist;
        }

        public IEnumerable<vc_ts_TimesheetHist> GetTimesheetHistsByAdIdSeq(String employeeAd, int timesheetId, int seq)
        {
            var timesheetHists = tsTimesheetHistRepository.GetMany(x => x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId && x.Seq == seq);
            return timesheetHists;
        }

        public void CreateTimesheetHist(vc_ts_TimesheetHist timesheetHist)
        {
            tsTimesheetHistRepository.Add(timesheetHist);
            Save();
        }

        public void UpdateTimesheetHist(vc_ts_TimesheetHist timesheetHist)
        {
            tsTimesheetHistRepository.Update(timesheetHist);
            Save();
        }

        public void DeleteTimesheetHist(int timesheetId)
        {
            var timesheetHist = GetTimesheetHistById(timesheetId);
            tsTimesheetHistRepository.Delete(timesheetHist);
            Save();
        }
        
        public void Save()
        {
            unitOfWork.Commit();
        }
    }
}
