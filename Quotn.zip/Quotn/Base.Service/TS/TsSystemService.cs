﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using TS.Data;
using Base.Data.Infrastructure;
using System.Collections;
using Base.Data;

namespace TS.Service
{
    /// <summary>
    /// SystemService Interface
    /// </summary>
    public interface ITsSystemService
    {
        /// <summary>
        ///  Get All Systems
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_ts_SystemEntity> GetSystems();

        /// <summary>
        /// Get System by Id
        /// </summary>
        /// <param name="Id">Id</param>
        /// <returns>SystemEntity</returns>
        vc_ts_SystemEntity GetSystemByKey(int id,string name,string um);

        /// <summary>
        /// Update System  one Record
        /// </summary>
        /// <param name="system"></param>
        /// <param name="user"></param>
        void UpdateSystem(vc_ts_SystemEntity system, String user);

        /// <summary>
        /// Update System Record
        /// </summary>
        /// <param name="system"></param>
        /// <param name="user"></param>
        void UpdateSystem(IEnumerable<vc_ts_SystemEntity> system, String user);

        /// <summary>
        /// Commit System
        /// </summary>
        void Save();
    }

    public class TsSystemService : ITsSystemService
    {
        private readonly ITsSystemRepository systemRepository;
        private BaseContext bc = new BaseContext();
        private readonly IUnitOfWork unitOfWork;
        public TsSystemService(ITsSystemRepository systemRepository, IUnitOfWork unitOfWork)
        {
            this.systemRepository = systemRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_ts_SystemEntity> GetSystems()
        {
            var users = systemRepository.GetAll();
            return users;
        }

        public vc_ts_SystemEntity GetSystemByKey(int id, string name, string um)
        {
            var user = systemRepository.Get(x => x.ParamId == id && x.ParamName == name && x.ParamUm == um);
            return user;
        }

        public void UpdateSystem(IEnumerable<vc_ts_SystemEntity> system, String user)
        {
            foreach (var entity in system)
            {
                var se = (from x in bc.vc_ts_SystemEntity
                                         where x.ParamId == entity.ParamId && x.ParamName == entity.ParamName &&  x.ParamUm == entity.ParamUm
                                         select x
                              ).AsEnumerable();

                foreach (vc_ts_SystemEntity systemEntity in se)
                {
                    if (!systemEntity.ParamValue.Equals(entity.ParamValue))
                    {
                        systemEntity.ParamValue = entity.ParamValue;
                        systemEntity.UpdateUser = user;
                        systemEntity.UpdateDate = DateTime.Now;
                        systemRepository.Update(systemEntity);
                    }
                }
            }

            Save();
        }

        public void UpdateSystem(vc_ts_SystemEntity system, String user)
        {
            system.UpdateUser = user;
            system.UpdateDate = DateTime.Now;
            systemRepository.Update(system);

            Save();
        }

        public void Save()
        {
            unitOfWork.Commit();
        }
      
    }
}
