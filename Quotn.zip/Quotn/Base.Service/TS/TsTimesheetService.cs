﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using Notes.Domain;
using TS.Data;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using Base.Service.Utils;

namespace TS.Service
{
    /// <summary>
    /// TsEmployeeService Interface
    /// </summary>
    public interface ITsTimesheetService
    {
        /// <summary>
        ///  Get All Timesheet
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheets();

        /// <summary>
        ///  Get All Timesheet group by Id,Ad
        /// </summary>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetsGroupAdId();

        /// <summary>
        /// Get Person Timesheet group by Ad
        /// </summary>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetsGroupAd(String employeeAd);

        /// <summary>
        /// Get Timesheet by TimesheetId
        /// </summary>
        /// <param name="TimesheetId"></param>
        /// <returns>vc_ts_Timesheet</returns>
        vc_ts_Timesheet GetTimesheetById(int timesheetId);

        /// <summary>
        /// Get Timesheet by EmployeeAd & TimesheetId
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetByAdId(String employeeAd, int timesheetId);

        /// <summary>
        /// Get Timesheet by EmployeeAd & TimesheetId & Seq
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <param name="seq"></param>
        /// <returns>vc_ts_Timesheet</returns>
        vc_ts_Timesheet GetTimesheetByAdIdSeq(String employeeAd, int timesheetId, int seq);

        /// <summary>
        /// Get Need Aprove Timesheet
        /// </summary>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetNeedAproveTimesheet();

        /// <summary>
        /// Get Timesheet by EmployeeAd
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetByAd(String employeeAd);

        /// <summary>
        /// Get Timesheet by EmployeeAd Item no close
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetByAdNoClose(String employeeAd, int timesheetId);

        /// <summary>
        /// Get DocNo By EmployeeAd,EmployeeName from Notes
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="employeeName"></param>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetDocNoByName(String employeeAd, String employeeName);

        /// <summary>
        /// Get DocNo By EmployeeAd,EmployeeName,TimeSheetId from Notes
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="employeeName"></param>
        /// <param name="timeSheetId"></param>
        /// <returns></returns>
        IEnumerable<vc_ts_Timesheet> GetDocNoByName(String employeeAd, String employeeName, int timeSheetId);

        /// <summary>
        /// Check DocNo Existed and closed By Ad,DocNo
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="docNo"></param>
        /// <returns>Boolean</returns>
        Boolean ChkDocNoExistByAd(String employeeAd, String docNo, String category, int TimeSheetId, DateTime CompleteDate);

        /// <summary>
        /// Get Timesheet History by EmployeeAd, TimesheetId, Seq, ParentSeq
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <param name="Seq"></param>
        /// <param name="ParentSeq"></param>
        /// <returns>IEnumerable<vc_ts_Timesheet></returns>
        IEnumerable<vc_ts_Timesheet> GetHistTimesheetByKey(String employeeAd, int Seq, int ParentSeq);

        /// <summary>
        /// Add Timesheet Record
        /// </summary>
        /// <param name="timesheet">vc_ts_Timesheet</param>
        void CreateTimesheet(vc_ts_Timesheet timesheet);

        /// <summary>
        /// Add Timesheets Record
        /// </summary>
        /// <param name="timesheets"></param>
        /// <returns>ArrayList</returns>
        ArrayList CreateTimeSheets(IEnumerable<vc_ts_Timesheet> timesheets);

        /// <summary>
        /// Update Timesheet Record
        /// </summary>
        /// <param name="timesheet">vc_ts_Timesheet</param>
        void UpdateTimesheet(vc_ts_Timesheet timesheet);

        /// <summary>
        /// Update Timesheets Record
        /// </summary>
        /// <param name="timesheets"></param>
        /// <returns>ArrayList</returns>
        ArrayList UpdateTimesheets(IEnumerable<vc_ts_Timesheet> timesheets);

        /// <summary>
        /// Delete Timesheet by TimesheetId
        /// </summary>
        /// <param name="timesheetId">timesheetId</param>
        void DeleteTimesheet(int timesheetId);

        /// <summary>
        /// Delete Timesheet by EmployeeAd & TimesheetId
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        String DeleteTimesheetByAdId(String employeeAd, int timesheetId);

        /// <summary>
        /// Archive Timesheet by EmployeeAd & TimesheetId
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <returns></returns>
        String ArchiveTimesheetByAdId(String employeeAd, int timesheetId);

        /// <summary>
        /// Get OverDueList by employeeAd,timesheetId
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <param name="timesheetId"></param>
        /// <returns></returns>
        IEnumerable<vc_ts_Timesheet> GetTimesheetOverDue(String employeeAd, int timesheetId);

        /// <summary>
        /// Get TimeSheetId by EmployeeAd
        /// </summary>
        /// <param name="EmployeeAd"></param>
        /// <returns>int</returns>
        int GetTimeSheetId(String EmployeeAd);

        /// <summary>
        /// Get TimeSheetId By AddDays
        /// </summary>
        /// <param name="timesheetId"></param>
        /// <param name="day"></param>
        /// <returns></returns>
        int GetTimeSheetIdByAddDays(int timesheetId, int day);

        /// <summary>
        /// Get TimeSheet Seq
        /// </summary>
        /// <returns>int</returns>
        int GetTimeSheetSeq();

        /// <summary>
        /// Get File Seq
        /// </summary>
        /// <returns>int</returns>
        int GetFileSeq();

        /// <summary>
        /// Commit Timesheet
        /// </summary>
        void Save();
    }

    public class TsTimesheetService : ITsTimesheetService
    {
        private readonly ITsTimesheetRepository tsTimesheetRepository;
        private readonly ITsTimesheetHistRepository tsTimesheetHistRepository;
        private readonly IUnitOfWork unitOfWork;
        private BaseContext bc = new BaseContext();
        private NotesContext nc = new NotesContext();

        public TsTimesheetService(ITsTimesheetRepository tsTimesheetRepository, ITsTimesheetHistRepository tsTimesheetHistRepository, IUnitOfWork unitOfWork)
        {
            this.tsTimesheetRepository = tsTimesheetRepository;
            this.tsTimesheetHistRepository = tsTimesheetHistRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheets()
        {
            var timesheets = tsTimesheetRepository.GetAll();
            return timesheets;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetsGroupAdId()
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              join y in bc.vc_ts_Employee on x.EmployeeAd equals y.EmployeeAd into ps
                              from b in ps.DefaultIfEmpty()
                              group x by new { x.EmployeeAd } into g
                              let timesheetId = g.Max(a => a.TimeSheetId)
                              let updateDate = g.Max(a => a.UpdateDate)
                              select new
                              {
                                  TimesheetId = timesheetId,
                                  Seq = 0,
                                  EmployeeAd = g.Key.EmployeeAd,
                                  UpdateDate = updateDate
                              }).ToList()
                              .Select(x => new vc_ts_Timesheet
                              {
                                  TimeSheetId = x.TimesheetId,
                                  Seq = x.Seq,
                                  EmployeeAd = x.EmployeeAd,
                                  UpdateDate = x.UpdateDate
                              }
                              );
            List<vc_ts_Timesheet> list = new List<vc_ts_Timesheet>();
            list.AddRange(timesheets);

            return list.AsEnumerable();
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetsGroupAd(String employeeAd)
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              join y in bc.vc_ts_Employee on x.EmployeeAd equals y.EmployeeAd into ps
                              from b in ps.DefaultIfEmpty()
                              where x.EmployeeAd == employeeAd
                              group x by new { x.EmployeeAd, x.TimeSheetId, x.IsPost } into g
                              let updateDate = g.Max(a => a.UpdateDate)
                              select new
                              {
                                  TimesheetId = g.Key.TimeSheetId,
                                  Seq = 0,
                                  EmployeeAd = g.Key.EmployeeAd,
                                  IsPost = g.Key.IsPost,
                                  UpdateDate = updateDate
                              }).ToList().OrderByDescending(x => x.TimesheetId)
                              .Select(x => new vc_ts_Timesheet
                              {
                                  TimeSheetId = x.TimesheetId,
                                  Seq = x.Seq,
                                  EmployeeAd = x.EmployeeAd,
                                  IsPost = x.IsPost,
                                  UpdateDate = x.UpdateDate
                              }
                              );
            List<vc_ts_Timesheet> list = new List<vc_ts_Timesheet>();
            list.AddRange(timesheets);

            return list.AsEnumerable();
        }

        public vc_ts_Timesheet GetTimesheetById(int timesheetId)
        {
            vc_ts_Timesheet timesheet = tsTimesheetRepository.Get(x => x.TimeSheetId == timesheetId);
            return timesheet;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetByAdId(String employeeAd, int timesheetId)
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId
                              select x
                              ).AsEnumerable();

            return timesheets;
        }

        public vc_ts_Timesheet GetTimesheetByAdIdSeq(String employeeAd, int timesheetId, int seq)
        {
            vc_ts_Timesheet timesheet = tsTimesheetRepository.Get(x => x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId && x.Seq == seq);
            return timesheet;
        }

        public IEnumerable<vc_ts_Timesheet> GetNeedAproveTimesheet()
        {
            IEnumerable<vc_ts_Timesheet> timesheet = tsTimesheetRepository.GetMany(x => x.EditForecastDate != null || x.EditForecastDate != "");
            return timesheet;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetByAd(String employeeAd)
        {
            IEnumerable<vc_ts_Timesheet> timesheet = tsTimesheetRepository.GetMany(x => x.EmployeeAd == employeeAd);
            return timesheet;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetByAdNoClose(String employeeAd, int timesheetId)
        {
            var TimeSheetId = GetTimeSheetIdByAddDays(timesheetId, -7);
            var timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && x.ThisWeekActual < 100 && x.CompleteDate == null && (x.Category != "7") && x.TimeSheetId == TimeSheetId
                              select x
                  ).AsEnumerable();

            return timesheets;
        }

        public void CreateTimesheet(vc_ts_Timesheet timesheet)
        {
            tsTimesheetRepository.Add(timesheet);
            Save();
        }

        public ArrayList CreateTimeSheets(IEnumerable<vc_ts_Timesheet> timesheets)
        {
            ArrayList al = null;
            Hashtable ht = new Hashtable();
            DateTime currentTime = DateTime.Now;
            int seq = 0;

            foreach (vc_ts_Timesheet entity in timesheets)
            {
                var checkOk = ChkTimeSheetIsOk(ht, entity);

                if (checkOk && !(entity.Item == null || entity.Item.Equals("")))
                {
                    seq++;
                    var TimeSheetId = GetTimeSheetId(entity.EmployeeAd);
                    entity.Seq = GetTimeSheetSeq();
                    entity.TimeSheetId = TimeSheetId;
                    entity.CreateDate = currentTime;
                    entity.UpdateDate = currentTime;
                    tsTimesheetRepository.Add(entity);

                    vc_ts_TimesheetHist tTimesheetHist = new vc_ts_TimesheetHist();
                    tTimesheetHist.TimeSheetId = entity.TimeSheetId;
                    tTimesheetHist.Seq = entity.Seq;
                    tTimesheetHist.ParentSeq = entity.ParentSeq;
                    tTimesheetHist.Order = entity.Order;
                    tTimesheetHist.EmployeeAd = entity.EmployeeAd;
                    tTimesheetHist.DocNo = entity.DocNo;
                    tTimesheetHist.Category = entity.Category;
                    tTimesheetHist.Item = entity.Item;
                    tTimesheetHist.ItemDesc = entity.ItemDesc;
                    tTimesheetHist.Question = entity.Question;
                    tTimesheetHist.TtlTime = entity.TtlTime;
                    tTimesheetHist.ThisWeekTime = entity.ThisWeekTime;
                    tTimesheetHist.LastWeekSchedule = entity.LastWeekSchedule;
                    tTimesheetHist.ThisWeekForecast = entity.ThisWeekForecast;
                    tTimesheetHist.ThisWeekActual = entity.ThisWeekActual;
                    tTimesheetHist.InputDate = entity.InputDate;
                    tTimesheetHist.OverDueList = entity.OverDueList;
                    tTimesheetHist.ForecastDate = entity.ForecastDate;
                    tTimesheetHist.CompleteDate = entity.CompleteDate;
                    tTimesheetHist.IsPost = entity.IsPost;
                    tTimesheetHist.Url = StringHandle.TrimEachLine(entity.Url);
                    tTimesheetHist.Status = "新增";
                    tTimesheetHist.CreateDate = entity.CreateDate;
                    tTimesheetHist.UpdateDate = entity.UpdateDate;
                    tsTimesheetHistRepository.Add(tTimesheetHist);
                }
            }

            if (ht.Count == 0 && seq == 0) ht.Add("NoData", "無資料可新增");

            al = new ArrayList(ht.Values);

            if (al != null && al.Count == 0)
            {
                Save();
            }

            return al;
        }

        public void UpdateTimesheet(vc_ts_Timesheet timesheet)
        {
            tsTimesheetRepository.Update(timesheet);
            Save();
        }

        public ArrayList UpdateTimesheets(IEnumerable<vc_ts_Timesheet> timesheets)
        {
            ArrayList al = null;
            Hashtable ht = new Hashtable();
            DateTime currentTime = DateTime.Now;
            int seq = 0;

            foreach (vc_ts_Timesheet entity in timesheets)
            {
                var checkOk = ChkTimeSheetIsOk(ht, entity);

                if (checkOk && !(entity.Item == null || entity.Item.Equals("")))
                {
                    seq++;
                    var timeSheet = GetTimesheetByAdIdSeq(entity.EmployeeAd, entity.TimeSheetId, entity.Seq);
                    if (timeSheet == null)
                    {
                        entity.IsPost = "0";
                        entity.Seq = GetTimeSheetSeq();
                        entity.CreateDate = currentTime;
                        entity.UpdateDate = currentTime;
                        tsTimesheetRepository.Add(entity);

                        vc_ts_TimesheetHist tTimesheetHist = new vc_ts_TimesheetHist();
                        tTimesheetHist.TimeSheetId = entity.TimeSheetId;
                        tTimesheetHist.Seq = entity.Seq;
                        tTimesheetHist.ParentSeq = entity.ParentSeq;
                        tTimesheetHist.Order = entity.Order;
                        tTimesheetHist.EmployeeAd = entity.EmployeeAd;
                        tTimesheetHist.DocNo = entity.DocNo;
                        tTimesheetHist.Category = entity.Category;
                        tTimesheetHist.Item = entity.Item;
                        tTimesheetHist.ItemDesc = entity.ItemDesc;
                        tTimesheetHist.Question = entity.Question;
                        tTimesheetHist.TtlTime = entity.TtlTime;
                        tTimesheetHist.ThisWeekTime = entity.ThisWeekTime;
                        tTimesheetHist.LastWeekSchedule = entity.LastWeekSchedule;
                        tTimesheetHist.ThisWeekForecast = entity.ThisWeekForecast;
                        tTimesheetHist.ThisWeekActual = entity.ThisWeekActual;
                        tTimesheetHist.InputDate = entity.InputDate;
                        tTimesheetHist.OverDueList = entity.OverDueList;
                        tTimesheetHist.ForecastDate = entity.ForecastDate;
                        tTimesheetHist.CompleteDate = entity.CompleteDate;
                        tTimesheetHist.IsPost = "0";
                        tTimesheetHist.Url = StringHandle.TrimEachLine(entity.Url);
                        tTimesheetHist.Status = "新增";
                        tTimesheetHist.CreateDate = entity.CreateDate;
                        tTimesheetHist.UpdateDate = entity.UpdateDate;
                        tsTimesheetHistRepository.Add(tTimesheetHist);
                    }
                    else
                    {
                        //IsPost暫代是否刪除用
                        if (entity.IsPost != null && entity.IsPost.Equals("1"))
                        {
                            tsTimesheetRepository.Delete(timeSheet);
                        }
                        else
                        {
                            timeSheet.DocNo = entity.DocNo;
                            timeSheet.Category = entity.Category;
                            timeSheet.Item = entity.Item;
                            timeSheet.ItemDesc = entity.ItemDesc;
                            timeSheet.Question = entity.Question;
                            timeSheet.Order = entity.Order;
                            timeSheet.ThisWeekActual = entity.ThisWeekActual;
                            timeSheet.ThisWeekForecast = entity.ThisWeekForecast;
                            timeSheet.ThisWeekTime = entity.ThisWeekTime;
                            timeSheet.InputDate = entity.InputDate;
                            timeSheet.OverDueList = entity.OverDueList;
                            timeSheet.ForecastDate = entity.ForecastDate;
                            timeSheet.EditForecastDate = entity.EditForecastDate;
                            timeSheet.CompleteDate = entity.CompleteDate;
                            timeSheet.Url = StringHandle.TrimEachLine(entity.Url);
                            timeSheet.UpdateDate = currentTime;
                            timeSheet.IsPost = "0";
                            tsTimesheetRepository.Update(timeSheet);
                        }
                    }
                }
            }

            if (ht.Count == 0 && seq == 0) ht.Add("NoData", "無資料可新增或更新");

            al = new ArrayList(ht.Values);

            if (al != null && al.Count == 0)
            {
                try
                {
                    Save();
                }
                catch (Exception ex)
                {
                    ht.Add("SaveErr", "資料庫更新發生錯誤");
                    al = new ArrayList(ht.Values);
                }
            }

            return al;
        }

        public void DeleteTimesheet(int timesheetId)
        {
            var timesheet = GetTimesheetById(timesheetId);
            tsTimesheetRepository.Delete(timesheet);
            Save();
        }

        public String DeleteTimesheetByAdId(String employeeAd, int timesheetId)
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId
                              select x
                              ).AsEnumerable();
            foreach (vc_ts_Timesheet entity in timesheets)
            {
                if (entity.IsPost != null && !entity.IsPost.Equals("0"))
                {
                    return "";
                }
            }

            tsTimesheetRepository.Delete(x => employeeAd == x.EmployeeAd && timesheetId == x.TimeSheetId);
            Save();

            return null;
        }

        public String ArchiveTimesheetByAdId(String employeeAd, int timesheetId)
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId
                              select x
                              ).AsEnumerable();
            foreach (vc_ts_Timesheet entity in timesheets)
            {
                if (entity.IsPost != null && !entity.IsPost.Equals("0"))
                {
                    return "";
                }

                entity.IsPost = "1";
                tsTimesheetRepository.Update(entity);
            }

            Save();

            return null;
        }

        public IEnumerable<vc_ts_Timesheet> GetTimesheetOverDue(String employeeAd, int timesheetId)
        {
            var timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && x.TimeSheetId == timesheetId && x.OverDueList != null
                              select x
                              ).ToList();
            var chkTimesheets = from y in timesheets
                                where (y.ThisWeekActual < 100 && y.CompleteDate == null) || (Convert.ToDateTime(y.CompleteDate) > Convert.ToDateTime(y.ForecastDate))
                                select new vc_ts_Timesheet
                                {
                                    TimeSheetId = y.TimeSheetId,
                                    Seq = y.Seq,
                                    ParentSeq = y.ParentSeq,
                                    Order = y.Order,
                                    EmployeeAd = y.EmployeeAd,
                                    DocNo = y.DocNo,
                                    Category = y.Category,
                                    Item = y.Item,
                                    ItemDesc = y.ItemDesc,
                                    TtlTime = y.TtlTime,
                                    ThisWeekTime = y.ThisWeekTime,
                                    LastWeekSchedule = y.LastWeekSchedule,
                                    ThisWeekForecast = y.ThisWeekForecast,
                                    ThisWeekActual = y.ThisWeekActual,
                                    InputDate = y.InputDate,
                                    OverDueList = y.OverDueList,
                                    ForecastDate = y.ForecastDate,
                                    CompleteDate = y.CompleteDate,
                                    IsPost = y.IsPost,
                                    Url = y.Url,
                                    CreateDate = y.CreateDate,
                                    UpdateDate = y.UpdateDate,
                                    EditForecastDate = y.EditForecastDate
                                };

            return chkTimesheets;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        public IEnumerable<vc_ts_Timesheet> GetHistTimesheetByKey(String employeeAd, int Seq, int ParentSeq)
        {
            IEnumerable<vc_ts_Timesheet> timesheets = null;
            if (ParentSeq > 0)
            {
                timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && (x.Seq == ParentSeq || x.ParentSeq == ParentSeq)
                              select x
                                   ).AsEnumerable();
            }
            else
            {
                timesheets = (from x in bc.vc_ts_Timesheet
                              where x.EmployeeAd == employeeAd && (x.Seq == Seq)
                              select x
                       ).AsEnumerable();
            }

            return timesheets;
        }

        public int GetTimeSheetSeq()
        {
            int result = 0;

            var resultParameter = new SqlParameter("@Result", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };

            var getTimesheetID = bc.Database.ExecuteSqlCommand("vc_ts_GetTimeSheetSeqSp @Result out", resultParameter);
            result = (int)resultParameter.Value;

            return result;
        }

        public int GetFileSeq()
        {
            int result = 0;

            var resultParameter = new SqlParameter("@Result", SqlDbType.Int)
            {
                Direction = ParameterDirection.Output
            };

            var getFileID = bc.Database.ExecuteSqlCommand("vc_ts_GetFileSeqSp @Result out", resultParameter);
            result = (int)resultParameter.Value;

            return result;
        }

        public IEnumerable<vc_ts_Timesheet> GetDocNoByName(String employeeAd, String employeeName)
        {
            int TimeSheetId = GetTimeSheetId(employeeAd);
            List<vc_ts_Timesheet> timeSheetList = new List<vc_ts_Timesheet>();

            DateTime defaultDate = DateTime.ParseExact("19000101", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            DateTime overDate = DateTime.ParseExact("20160701", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            DateTime timeSheetIdDate = DateTime.ParseExact(TimeSheetId.ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

            //資訊系統問題單
            /****************************************************************/
            var ispMaster = (from x in nc.vc_notes_ISP_Master
                             where x.ActualPrcEmpCName == employeeName && x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate
                             select x
                      ).Union(
                       from x in nc.vc_notes_ISP_Master
                       where x.ActualPrcEmpCName == employeeName && (x.ConfirmDate == null || x.ConfirmDate == defaultDate)
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_ISP_Master isp in ispMaster)
            {
                //之前單號已存在且未完成則換下一筆
                if (ChkDocNoExistByAd(employeeAd, isp.DocNo, "1", TimeSheetId, isp.ConfirmDate))
                {
                    continue;
                }

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = isp.DocNo;
                entity.Category = "1";
                entity.Item = isp.SysComment;
                entity.ItemDesc = "申請人:" + isp.ApplicantCN + "\n" + isp.ProbCommentTxt;
                entity.InputDate = isp.ReceiveDate.ToString("yyyy/MM/dd");
                entity.ForecastDate = isp.CalDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = isp.ConfirmDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊系統開發需求單 
            /****************************************************************/
            var mprMaster = (from x in nc.vc_notes_MPR_Master
                             where x.ActualPrcEmpCName == employeeName && ((x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate) || (x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate && x.ACTIVITYOS == "取消申請"))
                             select x
                      ).Union(
                       from x in nc.vc_notes_MPR_Master
                       where x.ActualPrcEmpCName == employeeName && (x.ConfirmDate == null || x.ConfirmDate == defaultDate) && x.ACTIVITYOS != "取消申請"
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_MPR_Master mpr in mprMaster)
            {
                //之前單號已存在且未完成則換下一筆
                if (ChkDocNoExistByAd(employeeAd, mpr.DocNo, "2", TimeSheetId, mpr.ConfirmDate))
                {
                    continue;
                }

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = mpr.DocNo;
                entity.Category = "2";
                entity.Item = mpr.SysComment;
                entity.ItemDesc = "申請人:" + mpr.ApplicantCN + Environment.NewLine + mpr.ProbComment + Environment.NewLine + mpr.ProsComment;
                entity.InputDate = mpr.ReceiveDate.ToString("yyyy/MM/dd");
                entity.ForecastDate = mpr.CalDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = mpr.ConfirmDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊設備維修單 
            /****************************************************************/
            var rpa = (from x in nc.vc_notes_RPA
                       where x.PrcEmpCName == employeeName & x.FinshDate > defaultDate && x.FinshDate >= timeSheetIdDate
                       select x
                      ).Union(
                       from x in nc.vc_notes_RPA
                       where x.PrcEmpCName == employeeName && (x.FinshDate == null || x.FinshDate == defaultDate) && x.ReceiveDate >= overDate
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_RPA r in rpa)
            {
                //之前單號已存在且未完成則換下一筆
                if (ChkDocNoExistByAd(employeeAd, r.DocNo, "3", TimeSheetId, r.FinshDate))
                {
                    continue;
                }

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = r.DocNo;
                entity.Category = "3";
                entity.Item = r.ProbType;
                entity.ItemDesc = r.CauseCommentTxt;
                entity.InputDate = r.ReceiveDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = r.FinshDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊設備需求單 
            /****************************************************************/
            var nas005 = (from x in nc.vc_notes_Nas005_Master
                          where x.PrcEmpCName == employeeName && x.FinishDate > defaultDate && x.FinishDate >= timeSheetIdDate
                          select x
                      ).Union(
                       from x in nc.vc_notes_Nas005_Master
                       where x.PrcEmpCName == employeeName && (x.FinishDate == null || x.FinishDate == defaultDate) && x.ReceiveDate >= overDate
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_Nas005_Master nas_005 in nas005)
            {
                //之前單號已存在且未完成則換下一筆
                if (ChkDocNoExistByAd(employeeAd, nas_005.DocNo, "4", TimeSheetId, nas_005.FinishDate))
                {
                    continue;
                }

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = nas_005.DocNo;
                entity.Category = "4";
                entity.Item = nas_005.Needdescription;
                entity.ItemDesc = nas_005.Analysisdescription;
                entity.InputDate = nas_005.ReceiveDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = nas_005.FinishDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            IEnumerable<vc_ts_Timesheet> ts = timeSheetList;

            return ts;
        }

        public IEnumerable<vc_ts_Timesheet> GetDocNoByName(String employeeAd, String employeeName, int timeSheetId)
        {
            int TimeSheetId = GetTimeSheetId(employeeAd);
            List<vc_ts_Timesheet> timeSheetList = new List<vc_ts_Timesheet>();

            DateTime defaultDate = DateTime.ParseExact("19000101", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            DateTime overDate = DateTime.ParseExact("20160701", "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            //DateTime timeSheetIdDate = DateTime.ParseExact(TimeSheetId.ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
            DateTime timeSheetIdDate = DateTime.ParseExact(timeSheetId.ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

            //資訊系統問題單
            /****************************************************************/
            var ispMaster = (from x in nc.vc_notes_ISP_Master
                             where x.ActualPrcEmpCName == employeeName && x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate
                             select x
                      ).Union(
                       from x in nc.vc_notes_ISP_Master
                       where x.ActualPrcEmpCName == employeeName && (x.ConfirmDate == null || x.ConfirmDate == defaultDate)
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_ISP_Master isp in ispMaster)
            {
                ////之前單號已存在且未完成則換下一筆
                //if (ChkDocNoExistByAd(employeeAd, isp.DocNo, "1", timeSheetId, isp.ConfirmDate))
                //{
                //    continue;
                //}

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = isp.DocNo;
                entity.Category = "1";
                entity.Item = isp.SysComment;
                entity.ItemDesc = "申請人:" + isp.ApplicantCN + "\n" + isp.ProbCommentTxt;
                entity.InputDate = isp.ReceiveDate.ToString("yyyy/MM/dd");
                entity.ForecastDate = isp.CalDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = isp.ConfirmDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊系統開發需求單 
            /****************************************************************/
            var mprMaster = (from x in nc.vc_notes_MPR_Master
                             where x.ActualPrcEmpCName == employeeName && ((x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate) || (x.ConfirmDate > defaultDate && x.ConfirmDate >= timeSheetIdDate && x.ACTIVITYOS == "取消申請"))
                             select x
                      ).Union(
                       from x in nc.vc_notes_MPR_Master
                       where x.ActualPrcEmpCName == employeeName && (x.ConfirmDate == null || x.ConfirmDate == defaultDate) && x.ACTIVITYOS != "取消申請"
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_MPR_Master mpr in mprMaster)
            {
                ////之前單號已存在且未完成則換下一筆
                //if (ChkDocNoExistByAd(employeeAd, mpr.DocNo, "2", timeSheetId, mpr.ConfirmDate))
                //{
                //    continue;
                //}

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = mpr.DocNo;
                entity.Category = "2";
                entity.Item = mpr.SysComment;
                entity.ItemDesc = "申請人:" + mpr.ApplicantCN + Environment.NewLine + mpr.ProbComment + Environment.NewLine + mpr.ProsComment;
                entity.InputDate = mpr.ReceiveDate.ToString("yyyy/MM/dd");
                entity.ForecastDate = mpr.CalDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = mpr.ConfirmDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊設備維修單 
            /****************************************************************/
            var rpa = (from x in nc.vc_notes_RPA
                       where x.PrcEmpCName == employeeName & x.FinshDate > defaultDate && x.FinshDate >= timeSheetIdDate
                       select x
                      ).Union(
                       from x in nc.vc_notes_RPA
                       where x.PrcEmpCName == employeeName && (x.FinshDate == null || x.FinshDate == defaultDate) && x.ReceiveDate >= overDate
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_RPA r in rpa)
            {
                ////之前單號已存在且未完成則換下一筆
                //if (ChkDocNoExistByAd(employeeAd, r.DocNo, "3", timeSheetId,r.FinshDate))
                //{
                //    continue;
                //}

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = r.DocNo;
                entity.Category = "3";
                entity.Item = r.ProbType;
                entity.ItemDesc = r.CauseCommentTxt;
                entity.InputDate = r.ReceiveDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = r.FinshDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            //資訊設備需求單 
            /****************************************************************/
            var nas005 = (from x in nc.vc_notes_Nas005_Master
                          where x.PrcEmpCName == employeeName && x.FinishDate > defaultDate && x.FinishDate >= timeSheetIdDate
                          select x
                      ).Union(
                       from x in nc.vc_notes_Nas005_Master
                       where x.PrcEmpCName == employeeName && (x.FinishDate == null || x.FinishDate == defaultDate) && x.ReceiveDate >= overDate
                       select x
                      ).AsEnumerable();

            foreach (vc_notes_Nas005_Master nas_005 in nas005)
            {
                ////之前單號已存在且未完成則換下一筆
                //if (ChkDocNoExistByAd(employeeAd, nas_005.DocNo, "4", timeSheetId, nas_005.FinishDate))
                //{
                //    continue;
                //}

                //之前單號已存在且已完成或無單號存在
                vc_ts_Timesheet entity = new vc_ts_Timesheet();
                entity.TimeSheetId = TimeSheetId;
                entity.Seq = 0;
                entity.ParentSeq = 0;
                entity.EmployeeAd = employeeAd;
                entity.DocNo = nas_005.DocNo;
                entity.Category = "4";
                entity.Item = nas_005.Needdescription;
                entity.ItemDesc = nas_005.Analysisdescription;
                entity.InputDate = nas_005.ReceiveDate.ToString("yyyy/MM/dd");
                entity.CompleteDate = nas_005.FinishDate.ToString("yyyy/MM/dd").Replace("1900/01/01", "");
                timeSheetList.Add(entity);
            }
            /****************************************************************/

            IEnumerable<vc_ts_Timesheet> ts = timeSheetList;

            return ts;
        }

        public Boolean ChkDocNoExistByAd(String employeeAd, String docNo, String category, int TimeSheetId, DateTime CompleteDate)
        {
            Boolean isExist = true;
            String completeDate = CompleteDate.ToString("yyyy/MM/dd");

            var timesheets1 = (from x in bc.vc_ts_Timesheet
                               where x.EmployeeAd == employeeAd && x.DocNo == docNo && x.Category == category && ((x.CompleteDate != null || x.CompleteDate != "") && x.TimeSheetId != TimeSheetId && x.CompleteDate != completeDate)
                               select x
                              ).ToList();
            if (timesheets1.Count > 0)
            {
                isExist = false;
            }

            var timesheets2 = (from x in bc.vc_ts_Timesheet
                               where x.EmployeeAd == employeeAd && x.DocNo == docNo
                               select x
                  ).ToList();

            if (timesheets2.Count == 0)
            {
                isExist = false;
            }

            return isExist;
        }

        public int GetTimeSheetId(String EmployeeAd)
        {
            var TimeSheetId = 0;
            DateTime thisMonday = DateTime.Today.AddDays(-1 * (((int)DateTime.Today.DayOfWeek) - 1));
            DateTime lastMonday = thisMonday.AddDays(-7);
            DateTime nextMonday = thisMonday.AddDays(7);

            IEnumerable<vc_ts_Timesheet> ts1 = GetTimesheetByAdId(EmployeeAd, Int32.Parse(lastMonday.ToString("yyyyMMdd")));
            IEnumerable<vc_ts_Timesheet> ts2 = GetTimesheetByAdId(EmployeeAd, Int32.Parse(thisMonday.ToString("yyyyMMdd")));
            IEnumerable<vc_ts_Timesheet> ts3 = GetTimesheetByAdId(EmployeeAd, Int32.Parse(nextMonday.ToString("yyyyMMdd")));

            if (ts3.ToList().Count == 0)
            {
                TimeSheetId = Int32.Parse(nextMonday.ToString("yyyyMMdd"));
            }
            if (ts2.ToList().Count == 0)
            {
                TimeSheetId = Int32.Parse(thisMonday.ToString("yyyyMMdd"));
            }
            if (ts1.ToList().Count == 0)
            {
                TimeSheetId = Int32.Parse(lastMonday.ToString("yyyyMMdd"));
            }

            if (TimeSheetId == 0)
            {
                TimeSheetId = GetTimeSheetIdByAddDays(Int32.Parse(nextMonday.ToString("yyyyMMdd")),7);
            }

            return TimeSheetId;
        }

        public int GetTimeSheetIdByAddDays(int timeSheetId, int day)
        {
            DateTime dt = DateTime.ParseExact(timeSheetId.ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);

            var TimeSheetId = Int32.Parse(dt.AddDays(day).ToString("yyyyMMdd"));

            return TimeSheetId;
        }

        public Boolean ChkTimeSheetIsOk(Hashtable ht, vc_ts_Timesheet entity)
        {
            var checkOk = true;
            if (!(entity.Item == null || entity.Item.Equals("")))
            {
                if (entity.Category != null && (entity.Category.Equals("7") || entity.Category.Equals("8") || entity.Category.Equals("9")))
                {
                    if ((entity.ItemDesc == null || entity.ItemDesc.Equals(""))) { if (!ht.Contains(1)) ht.Add(1, "項目描述與問題處理為必輸項"); checkOk = false; }
                    if (entity.Order == 0) { if (!ht.Contains(5)) ht.Add(5, "優先序為必輸項"); checkOk = false; }
                }
                else
                {
                    if ((entity.ItemDesc == null || entity.ItemDesc.Equals(""))) { if (!ht.Contains(1)) ht.Add(1, "項目描述與問題處理為必輸項"); checkOk = false; }
                    //if (entity.ThisWeekForecast.Equals("") || entity.ThisWeekForecast == 0) { if (!ht.Contains(2)) ht.Add(2, "本週預計進度為必輸項"); checkOk = false; }
                    if (entity.InputDate == null || entity.InputDate.Equals("")) { if (!ht.Contains(3)) ht.Add(3, "建立日期為必輸項"); checkOk = false; }
                    if (entity.ForecastDate == null || entity.ForecastDate.Equals(""))
                    {
                        if (entity.CompleteDate != null && !entity.CompleteDate.Equals(""))
                        {
                        }
                        else
                        {
                            if (!ht.Contains(4)) ht.Add(4, "預計完成日為必輸項"); checkOk = false;
                        }
                    }
                    if (entity.Order == 0) { if (!ht.Contains(5)) ht.Add(5, "優先序為必輸項"); checkOk = false; }
                }
            }

            if ((entity.Item == null || entity.Item.Equals("")))
            {
                if (!(entity.ItemDesc == null || entity.ItemDesc.Equals(""))) { checkOk = false; }
                if (!(entity.ThisWeekForecast.Equals("")) && entity.ThisWeekForecast > 0) { checkOk = false; }
                if (!(entity.InputDate == null || entity.InputDate.Equals(""))) { checkOk = false; }
                if (!(entity.ForecastDate == null || entity.ForecastDate.Equals(""))) { checkOk = false; }
                if (!checkOk) { if (!ht.Contains(6)) ht.Add(6, "項目為必輸項"); }
            }

            if (!(entity.CompleteDate == null || entity.CompleteDate.Equals("")))
            {
                if (entity.ThisWeekActual != 100)
                {
                    if (entity.Category != null && !(entity.Category.Equals("7") || entity.Category.Equals("8") || entity.Category.Equals("9")))
                    {
                        checkOk = false;
                        if (!ht.Contains(7)) ht.Add(7, "完成日已輸入，實際進度應為100");
                    }
                }
            }

            if (entity.ThisWeekActual == 100)
            {
                if (entity.CompleteDate == null || entity.CompleteDate.Equals(""))
                {
                    if (entity.Category != null && !(entity.Category.Equals("7") || entity.Category.Equals("8") || entity.Category.Equals("9")))
                    {
                        checkOk = false;
                        if (!ht.Contains(8)) ht.Add(8, "實際進度為100，完成日為必輸");
                    }
                }
            }

            return checkOk;
        }
    }
}
