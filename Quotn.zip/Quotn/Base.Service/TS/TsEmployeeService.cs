﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using TS.Data;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace TS.Service
{
    /// <summary>
    /// TsEmployeeService Interface
    /// </summary>
    public interface ITsEmployeeService
    {
        /// <summary>
        ///  Get All Employee
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_ts_Employee> GetEmployees();

        /// <summary>
        /// Get Employee by EmployeeId
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns>vc_ts_Employee</returns>
        vc_ts_Employee GetEmployeeById(String employeeId);

        /// <summary>
        /// Get Employee by EmployeeAd
        /// </summary>
        /// <param name="employeeAd"></param>
        /// <returns>vc_ts_Employee</returns>
        vc_ts_Employee GetEmployeeByAd(String employeeAd);

        /// <summary>
        /// Add Employee Record
        /// </summary>
        /// <param name="employee">vc_ts_Employee</param>
        void CreateEmployee(vc_ts_Employee employee);

        /// <summary>
        /// Update Employee Record
        /// </summary>
        /// <param name="employee">vc_ts_Employee</param>
        void UpdateEmployee(vc_ts_Employee employee);

        /// <summary>
        /// Delete Employee by employeeId
        /// </summary>
        /// <param name="employeeId">employeeId</param>
        void DeleteEmployee(String employee);

        /// <summary>
        /// Commit Employee
        /// </summary>
        void Save();
    }

    public class TsEmployeeService : ITsEmployeeService
    {
        private readonly ITsEmployeeRepository tsEmployeeRepository;
        private readonly IUnitOfWork unitOfWork;

        public TsEmployeeService(ITsEmployeeRepository tsEmployeeRepository, IUnitOfWork unitOfWork)
        {
            this.tsEmployeeRepository = tsEmployeeRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_ts_Employee> GetEmployees()
        {
            var Employees = tsEmployeeRepository.GetAll();
            return Employees;
        }

        public vc_ts_Employee GetEmployeeById(String employeeId)
        {
            vc_ts_Employee employee = tsEmployeeRepository.Get(x => x.EmployeeId == employeeId);
            return employee;
        }

        public vc_ts_Employee GetEmployeeByAd(String employeeAd)
        {
            vc_ts_Employee employee = tsEmployeeRepository.Get(x => x.EmployeeAd == employeeAd);
            return employee;
        }

        public void CreateEmployee(vc_ts_Employee employee)
        {
            tsEmployeeRepository.Add(employee);
            Save();
        }

        public void UpdateEmployee(vc_ts_Employee employee)
        {
            tsEmployeeRepository.Update(employee);
            Save();
        }

        public void DeleteEmployee(String employeeId)
        {
            var employee = GetEmployeeById(employeeId);
            tsEmployeeRepository.Delete(employee);
            Save();
        }
        
        public void Save()
        {
            unitOfWork.Commit();
        }
    }
}
