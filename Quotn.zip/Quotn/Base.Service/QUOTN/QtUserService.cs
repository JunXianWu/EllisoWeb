﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// UserService Interface
    /// </summary>
    public interface IQtUserService
    {
        /// <summary>
        ///  Get All User
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_Employee> GetUsers();

        /// <summary>
        /// Get User by userSeq
        /// </summary>
        /// <param name="UserSeq">userSeq</param>
        /// <returns>vc_quotn_Employee</returns>
        vc_quotn_Employee GetUser(int userSeq);

        vc_quotn_Employee GetUserById(String userId);

        /// <summary>
        /// Get User by userAd
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        vc_quotn_Employee GetUserByAd(String userAd);

        /// <summary>
        /// Add User Record
        /// </summary>
        /// <param name="user">vc_quotn_Employee</param>
        void CreateUser(vc_quotn_Employee user);

        /// <summary>
        /// Update User Record
        /// </summary>
        /// <param name="user">vc_quotn_Employee</param>
        void UpdateUser(vc_quotn_Employee user);

        /// <summary>
        /// Delete User Record
        /// </summary>
        /// <param name="userId"></param>
        void DeleteUser(String userId);

        /// <summary>
        /// Get Action By UserAd & FuncId
        /// </summary>
        /// <param name="userAd"></param>
        /// <param name="funcName"></param>
        /// <returns></returns>
        List<String> GetActionByUserFuncId(String userAd, String funcName);

        /// <summary>
        /// Commit User
        /// </summary>
        void Save();
    }

    public class QtUserService : IQtUserService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtUserRepository userRepository;
        private readonly IQtFunctionRepository functionRepository;
        private readonly IQtGroupFunctionRepository groupFunctionRepository;

        public QtUserService(IQtUserRepository userRepository,IQtFunctionRepository functionRepository, IQtGroupFunctionRepository groupFunctionRepository, IUnitOfWork unitOfWork)
        {
            this.userRepository = userRepository;
            this.functionRepository = functionRepository;
            this.groupFunctionRepository = groupFunctionRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_Employee> GetUsers()
        {
            var users = userRepository.GetAll();
            return users;
        }

        public vc_quotn_Employee GetUser(int userSeq)
        {
            var user = userRepository.GetById(userSeq);
            return user;
        }

        public vc_quotn_Employee GetUserById(String userId)
        {
            vc_quotn_Employee user = userRepository.Get(x => x.EmployeeId == userId);
            return user;
        }

        public vc_quotn_Employee GetUserByAd(String userAd)
        {
            vc_quotn_Employee user = userRepository.Get(x => x.EmployeeAd == userAd);
            return user;
        }

        public void CreateUser(vc_quotn_Employee users)
        {
            userRepository.Add(users);
            Save();
        }

        public void UpdateUser(vc_quotn_Employee user)
        {
            userRepository.Update(user);
            Save();
        }

        public void DeleteUser(String userId)
        {
            vc_quotn_Employee user = userRepository.GetById(userId);
            userRepository.Delete(user);
            Save();
        }

        public List<String> GetActionByUserFuncId(String userAd, String funcName)
        {
            var funcId = functionRepository.Get(x => x.FuncName == funcName).FuncId;
            var grpId = userRepository.Get(x=> x.EmployeeAd==userAd).GrpId;
            var groupFunc = groupFunctionRepository.GetMany(x => x.GrpId == grpId).OrderBy(x=>x.FuncId);
            List<String> actionList = new List<String>();
            foreach (var entity in groupFunc)
            {
                var action = functionRepository.Get(x => x.ParentID == funcId && x.FuncId == entity.FuncId && x.Url != null && x.Url.IndexOf("/") == -1);
                if (action != null)
                {
                    actionList.Add(action.FuncName);
                }
            }
            return actionList;
        }
        
        public void Save()
        {
            unitOfWork.Commit();
        }
      
    }
}
