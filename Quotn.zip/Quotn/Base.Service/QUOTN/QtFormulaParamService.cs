﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// UserService Interface
    /// </summary>
    public interface IQtFormulaParamService
    {
        /// <summary>
        ///  Get All Formula
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_FormulaParam> GetFormulas();

        /// <summary>
        /// Get Formula by formulaId
        /// </summary>
        /// <param name="formulaId">formulaId</param>
        /// <returns>vc_quotn_FormulaParam</returns>
        vc_quotn_FormulaParam GetFormula(String formulaId);

        /// <summary>
        /// Add Formula Record
        /// </summary>
        /// <param name="user">vc_quotn_FormulaParam</param>
        void CreateFormula(vc_quotn_FormulaParam formula);

        /// <summary>
        /// Update Formula Record
        /// </summary>
        /// <param name="user">vc_quotn_FormulaParam</param>
        void UpdateFormula(vc_quotn_FormulaParam formula);

        /// <summary>
        /// Update Formula Records
        /// </summary>
        /// <param name="formulas"></param>
        /// <param name="user"></param>
        void UpdateFormulas(IEnumerable<vc_quotn_FormulaParam> formulas, String user);

        /// <summary>
        /// Delete Formula Record
        /// </summary>
        /// <param name="Seq"></param>
        void DeleteFormula(String formulaId);

        /// <summary>
        /// Delete Formula All
        /// </summary>
        void DeleteFormulaAll();

        /// <summary>
        /// Create Formula History
        /// </summary>
        /// <param name="formula"></param>
        void CreateFormulaHist(vc_quotn_FormulaParamHist formula);

        /// <summary>
        /// Get Formula History List
        /// </summary>
        /// <returns></returns>
        IEnumerable<vc_quotn_FormulaParamHist> GetFormulaHList();

        /// <summary>
        /// Get FormulaHList By Seq
        /// </summary>
        /// <param name="seq"></param>
        /// <returns></returns>
        IEnumerable<vc_quotn_FormulaParamHist> GetFormulaHListBySeq(long seq);

        /// <summary>
        /// Commit User
        /// </summary>
        void Save();
    }

    public class QtFormulaParamService : IQtFormulaParamService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtFormulaParamRepository formulaParamRepository;
        private readonly IQtFormulaParamHistRepository formulaParamHistRepository;
        private readonly IQtSequenceService qtSequenceService;

        public QtFormulaParamService(IQtFormulaParamRepository formulaParamRepository, IQtFormulaParamHistRepository formulaParamHistRepository, IQtSequenceService qtSequenceService, IUnitOfWork unitOfWork)
        {
            this.formulaParamRepository = formulaParamRepository;
            this.formulaParamHistRepository = formulaParamHistRepository;
            this.qtSequenceService = qtSequenceService;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_FormulaParam> GetFormulas()
        {
            var formulas = formulaParamRepository.GetAll();
            return formulas;
        }

        public vc_quotn_FormulaParam GetFormula(String formulaId)
        {
            var formula = formulaParamRepository.GetById(formulaId);
            return formula;
        }

        public void CreateFormula(vc_quotn_FormulaParam formula)
        {
            formulaParamRepository.Add(formula);
            Save();
        }

        public void UpdateFormula(vc_quotn_FormulaParam formula)
        {
            formulaParamRepository.Update(formula);
            Save();
        }

        public void UpdateFormulas(IEnumerable<vc_quotn_FormulaParam> formulas, String user)
        {
            DateTime currentTime = DateTime.Now;
            List<vc_quotn_FormulaParam> formulaParamList = new List<vc_quotn_FormulaParam>();

            CheckData(formulas);

            //刪除主檔
            IEnumerable<vc_quotn_FormulaParam> getFormulas = GetFormulas();
            foreach (vc_quotn_FormulaParam entity in getFormulas)
            {
                vc_quotn_FormulaParam formula = formulaParamRepository.GetById(entity.FormulaId);
                formulaParamRepository.Delete(formula);
            }

            //新增主檔
            foreach (vc_quotn_FormulaParam entity in formulas)
            {
                if (entity.FormulaId == null) continue;

                entity.Creator = user;
                entity.CreateTime = currentTime;
                entity.Updator = user;
                entity.UpdateTime = currentTime;
                formulaParamRepository.Add(entity);
                formulaParamList.Add(entity);
            }

            //建立歷程
            if (formulaParamList.Count > 0)
            {
                Int64 seq = qtSequenceService.GetSequence("FormulaParam", "公式參數設定");
                foreach (vc_quotn_FormulaParam entity in formulaParamList)
                {
                    vc_quotn_FormulaParamHist formulaParamHist = new vc_quotn_FormulaParamHist();
                    formulaParamHist.Seq = seq;
                    formulaParamHist.FormulaId = entity.FormulaId;
                    formulaParamHist.FormulaName = entity.FormulaName;
                    formulaParamHist.Memo = entity.Memo;
                    formulaParamHist.CreateTime = entity.CreateTime;
                    formulaParamHist.Creator = entity.Creator;
                    formulaParamHist.UpdateTime = entity.UpdateTime;
                    formulaParamHist.Updator = entity.Updator;
                    formulaParamHistRepository.Add(formulaParamHist);
                }
            }

            Save();
        }

        public void DeleteFormula(String formulaId)
        {
            vc_quotn_FormulaParam formula = formulaParamRepository.GetById(formulaId);
            formulaParamRepository.Delete(formula);
            Save();
        }

        public void DeleteFormulaAll()
        {
            IEnumerable<vc_quotn_FormulaParam> formulas = GetFormulas();
            foreach (vc_quotn_FormulaParam entity in formulas)
            {
                DeleteFormula(entity.FormulaId);
            }
        }

        public void CreateFormulaHist(vc_quotn_FormulaParamHist formula)
        {
            formulaParamHistRepository.Add(formula);
            Save();
        }

        public IEnumerable<vc_quotn_FormulaParamHist> GetFormulaHList()
        {
            IEnumerable<vc_quotn_FormulaParamHist> formulaParamHist = formulaParamHistRepository.GetAll();

            var consolidatedChildren =
                from c in formulaParamHist
                group c by new
                {
                    c.Seq,
                    c.Updator,
                    c.UpdateTime,
                } into gcs
                select new vc_quotn_FormulaParamHist()
                {
                    Seq = gcs.Key.Seq,
                    Updator = gcs.Key.Updator,
                    UpdateTime = gcs.Key.UpdateTime
                };
            return consolidatedChildren;
        }

        public IEnumerable<vc_quotn_FormulaParamHist> GetFormulaHListBySeq(long seq)
        {
            IEnumerable<vc_quotn_FormulaParamHist> formulaHList = formulaParamHistRepository.GetMany(x => x.Seq == seq);
            return formulaHList;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        private void CheckData(IEnumerable<vc_quotn_FormulaParam> formulas)
        {
            Hashtable paramHt = new Hashtable();
            foreach (vc_quotn_FormulaParam formulaParam in formulas)
            {
                if (formulaParam.FormulaId != null)
                {
                    if (!paramHt.Contains(formulaParam.FormulaId))
                    {
                        paramHt.Add(formulaParam.FormulaId, formulaParam.FormulaName);
                    }
                    else
                    {
                        throw new Exception("代號重複");
                    }
                }
            }
        }
    }
}
