﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// UserService Interface
    /// </summary>
    public interface IQtSequenceService
    {
        /// <summary>
        /// Get Sequence by sequenceId & sequenceName
        /// </summary>
        /// <param name="sequenceId"></param>
        /// <param name="sequenceName"></param>
        /// <returns>Int64</returns>
        Int64 GetSequence(String sequenceId, String sequenceName);

        void Save();
    }

    public class QtSequenceService : IQtSequenceService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtSequenceRepository sequenceRepository;

        public QtSequenceService(IQtSequenceRepository sequenceRepository, IUnitOfWork unitOfWork)
        {
            this.sequenceRepository = sequenceRepository;
            this.unitOfWork = unitOfWork;
        }

        public Int64 GetSequence(String sequenceId, String sequenceName)
        {
            var sequence = sequenceRepository.Get(x => x.SequenceId == sequenceId);
            if (sequence == null)
            {
                vc_quotn_Sequence seq = new vc_quotn_Sequence();
                seq.SequenceId = sequenceId;
                seq.SequenceName = sequenceName;
                seq.Sequence = 1;
                sequence = seq;
                sequenceRepository.Add(seq);
                Save();
            }
            else
            {
                sequence.SequenceName = sequenceName;
                sequence.Sequence = sequence.Sequence + 1;
                sequenceRepository.Update(sequence);
                Save();
            }
            return sequence.Sequence;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }
      
    }
}
