﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// QtAreaMagService Interface
    /// </summary>
    public interface IQtAreaMagService
    {
        /// <summary>
        ///  Get All AreaMag
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_AreaMag> GetAreaMags();

        /// <summary>
        /// Get AreaMag by areaMagId
        /// </summary>
        /// <param name="areaMagId">areaMagId</param>
        /// <returns>vc_quotn_AreaMag</returns>
        vc_quotn_AreaMag GetAreaMag(String areaMagId);

        /// <summary>
        /// Add AreaMag Record
        /// </summary>
        /// <param name="user">vc_quotn_AreaMag</param>
        void CreateAreaMag(vc_quotn_AreaMag areaMag);

        /// <summary>
        /// Update AreaMag Record
        /// </summary>
        /// <param name="user">vc_quotn_AreaMag</param>
        void UpdateAreaMag(vc_quotn_AreaMag areaMag);

        /// <summary>
        /// Update AreaMag Records
        /// </summary>
        /// <param name="areaMags"></param>
        /// <param name="user"></param>
        void UpdateAreaMags(IEnumerable<vc_quotn_AreaMag> areaMags, String user);

        /// <summary>
        /// Delete AreaMag Record
        /// </summary>
        /// <param name="Seq"></param>
        void DeleteAreaMag(String categoryId, String areaId);

        /// <summary>
        /// Create AreaMag History
        /// </summary>
        /// <param name="areaMag"></param>
        void CreateAreaMagHist(vc_quotn_AreaMagHist areaMag);

        /// <summary>
        /// Get AreaMag History List
        /// </summary>
        /// <returns></returns>
        IEnumerable<vc_quotn_AreaMagHist> GetAreaMagHList();

        /// <summary>
        /// Get AreaMagHList By Seq
        /// </summary>
        /// <param name="seq"></param>
        /// <returns></returns>
        IEnumerable<vc_quotn_AreaMagHist> GetAreaMagHListBySeq(long seq);

        /// <summary>
        /// Commit 
        /// </summary>
        void Save();
    }

    public class QtAreaMagService : IQtAreaMagService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtAreaMagRepository areaMagRepository;
        private readonly IQtAreaMagHistRepository areaMagHistRepository;
        private readonly IQtSequenceService qtSequenceService;

        public QtAreaMagService(IQtAreaMagRepository areaMagRepository, IQtAreaMagHistRepository areaMagHistRepository, IQtSequenceService qtSequenceService, IUnitOfWork unitOfWork)
        {
            this.areaMagRepository = areaMagRepository;
            this.areaMagHistRepository = areaMagHistRepository;
            this.qtSequenceService = qtSequenceService;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_AreaMag> GetAreaMags()
        {
            var areaMags = areaMagRepository.GetAll();
            return areaMags;
        }

        public vc_quotn_AreaMag GetAreaMag(String areaMagId)
        {
            var areaMag = areaMagRepository.GetById(areaMagId);
            return areaMag;
        }

        public void CreateAreaMag(vc_quotn_AreaMag areaMag)
        {
            areaMagRepository.Add(areaMag);
            Save();
        }

        public void UpdateAreaMag(vc_quotn_AreaMag areaMag)
        {
            areaMagRepository.Update(areaMag);
            Save();
        }

        public void UpdateAreaMags(IEnumerable<vc_quotn_AreaMag> areaMags,String user)
        {
            DateTime currentTime = DateTime.Now;
            List<vc_quotn_AreaMag> areaMagList = new List<vc_quotn_AreaMag>();

            CheckData(areaMags);

            //刪除主檔
            IEnumerable<vc_quotn_AreaMag> getAreaMags = GetAreaMags();
            foreach (vc_quotn_AreaMag entity in getAreaMags)
            {
                vc_quotn_AreaMag areaMag = areaMagRepository.Get(x => x.CategoryId==entity.CategoryId && x.AreaId == entity.AreaId);
                areaMagRepository.Delete(areaMag);
            }

            //新增主檔
            foreach (vc_quotn_AreaMag entity in areaMags)
            {
                if (entity.CategoryId == null && entity.AreaId == null) continue;

                entity.Creator = user;
                entity.CreateTime = currentTime;
                entity.Updator = user;
                entity.UpdateTime = currentTime;
                areaMagRepository.Add(entity);
                areaMagList.Add(entity);
            }

            //建立歷程
            if (areaMagList.Count > 0)
            {
                Int64 seq = qtSequenceService.GetSequence("AreaMag", "區域倍率設定");
                foreach (vc_quotn_AreaMag entity in areaMagList)
                {
                    vc_quotn_AreaMagHist areaMagHist = new vc_quotn_AreaMagHist();
                    areaMagHist.Seq = seq;
                    areaMagHist.CategoryId = entity.CategoryId;
                    areaMagHist.AreaId = entity.AreaId;
                    areaMagHist.AreaMag = entity.AreaMag;
                    areaMagHist.Memo = entity.Memo;
                    areaMagHist.CreateTime = entity.CreateTime;
                    areaMagHist.Creator = entity.Creator;
                    areaMagHist.UpdateTime = entity.UpdateTime;
                    areaMagHist.Updator = entity.Updator;
                    areaMagHistRepository.Add(areaMagHist);
                }
            }

            Save();
        }

        public void DeleteAreaMag(String categoryId, String areaId)
        {
            vc_quotn_AreaMag areaMag = areaMagRepository.Get(x => x.CategoryId == categoryId && x.AreaId == areaId);
            areaMagRepository.Delete(areaMag);
            Save();
        }

        public void CreateAreaMagHist(vc_quotn_AreaMagHist areaMag)
        {
            areaMagHistRepository.Add(areaMag);
            Save();
        }

        public IEnumerable<vc_quotn_AreaMagHist> GetAreaMagHList()
        {
            IEnumerable<vc_quotn_AreaMagHist> formulaParamHist = areaMagHistRepository.GetAll();

            var consolidatedChildren =
                from c in formulaParamHist
                group c by new
                {
                    c.Seq,
                    c.Updator,
                    c.UpdateTime,
                } into gcs
                select new vc_quotn_AreaMagHist()
                {
                    Seq = gcs.Key.Seq,
                    Updator = gcs.Key.Updator,
                    UpdateTime = gcs.Key.UpdateTime
                };
            return consolidatedChildren;
        }

        public IEnumerable<vc_quotn_AreaMagHist> GetAreaMagHListBySeq(long seq)
        {
            IEnumerable<vc_quotn_AreaMagHist> formulaHList = areaMagHistRepository.GetMany(x => x.Seq == seq);
            return formulaHList;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        private void CheckData(IEnumerable<vc_quotn_AreaMag> areaMags)
        {
            Hashtable paramHt = new Hashtable();
            foreach (vc_quotn_AreaMag areaMag in areaMags)
            {
                if (areaMag.AreaMag == null)
                {
                    throw new Exception("區域倍率為必輸項");
                }
            }
        }
      
    }
}
