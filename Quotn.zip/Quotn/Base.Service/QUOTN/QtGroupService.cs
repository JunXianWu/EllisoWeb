﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// GroupService Interface
    /// </summary>
    public interface IQtGroupService
    {
        /// <summary>
        ///  Get All Group
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_Group> GetGroups();

        /// <summary>
        /// Get Group by GrpId
        /// </summary>
        /// <param name="GrpId">GrpId</param>
        /// <returns>vc_quotn_Group</returns>
        vc_quotn_Group GetGroup(int GrpId);

        /// <summary>
        /// Get Group and GroupFunction by GrpId
        /// </summary>
        /// <param name="grpId"></param>
        /// <returns>ArrayList</returns>
        Hashtable GetGroupFunction(int grpId);

        /// <summary>
        /// Add Group Record
        /// </summary>
        /// <param name="group">vc_quotn_Group</param>
        void CreateGroup(vc_quotn_Group group);

        /// <summary>
        /// Delete Group by GrpId
        /// </summary>
        /// <param name="GrpId">GrpId</param>
        void DeleteGroup(int GrpId);

        /// <summary>
        /// Add Group and GroupFunction Record
        /// </summary>
        /// <param name="grpName">Group Id</param>
        /// <param name="funcId">Function ID</param>
        /// <param name="user">User</param>
        void CreateGroupFunction(String grpName, String funcId, String user);

        /// <summary>
        /// Edit Group and GroupFunction Record
        /// </summary>
        /// <param name="grpId"></param>
        /// <param name="grpName"></param>
        /// <param name="funcId"></param>
        /// <param name="user"></param>
        void EditGroupFunction(int grpId, String grpName,String funcId, String user);

        /// <summary>
        /// Delete Group and GroupFunction Record
        /// </summary>
        /// <param name="GrpId"></param>
        void DeleteGroupFunction(int GrpId);

        /// <summary>
        /// get Function parent
        /// </summary>
        /// <param name="func"></param>
        Hashtable getFuncParent(int func,Hashtable ht);

        /// <summary>
        /// Commit Group
        /// </summary>
        void Save();
    }

    public class QtGroupService : IQtGroupService
    {
        private readonly IQtGroupRepository groupRepository;
        private readonly IQtGroupFunctionRepository groupFunctionRepository;
        private readonly IQtFunctionRepository functionRepository;
        private readonly IUnitOfWork unitOfWork;

        public QtGroupService(IQtGroupRepository groupRepository, IQtGroupFunctionRepository groupFunctionRepository, IQtFunctionRepository functionRepository,IUnitOfWork unitOfWork)
        {
            this.groupRepository = groupRepository;
            this.groupFunctionRepository = groupFunctionRepository;
            this.functionRepository = functionRepository;
            this.unitOfWork = unitOfWork;
        }

        public QtGroupService(IQtGroupRepository groupRepository, IUnitOfWork unitOfWork)
        {
            this.groupRepository = groupRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_Group> GetGroups()
        {
            var groups = groupRepository.GetAll();
            return groups;
        }

        public vc_quotn_Group GetGroup(int grpId)
        {
            var group = groupRepository.GetById(grpId);
            return group;
        }

        public Hashtable GetGroupFunction(int grpId)
        {
            Hashtable ht = new Hashtable();

            var group = groupRepository.GetById(grpId);
            ht.Add("GrpId", grpId);
            ht.Add("GrpName", group.GrpName);

            IEnumerable<vc_quotn_GroupFunction> groupFunction = groupFunctionRepository.GetMany(x => x.GrpId == grpId);
            Int32[] funcId = new Int32[groupFunction.Count()];
            var count = 0;
            foreach (var entity in groupFunction)
            {
               funcId[count]=entity.FuncId;
               count++;
            }

            ht.Add("FuncId", funcId);

            return ht;
        }

        public void CreateGroup(vc_quotn_Group group)
        {
            groupRepository.Add(group);
            Save();
        }

        public void CreateGroupFunction(String grpName, String funcId,String user)
        {
            String[] funcIdArr = funcId.Split(',');
            DateTime currentTime = DateTime.Now;
            vc_quotn_Group ge = new vc_quotn_Group();
            ge.GrpName = grpName;
            ge.Creator = user;
            ge.CreateTime = currentTime;
            ge.Updator = user;
            ge.UpdateTime = currentTime;

            groupRepository.Add(ge);
            Save();

            Hashtable ht = new Hashtable();
            foreach (var i in funcIdArr)
            {
                getFuncParent(Int32.Parse(i), ht);
            }
            foreach (System.Collections.DictionaryEntry objDE in ht)
            {
                vc_quotn_GroupFunction gfe = new vc_quotn_GroupFunction();
                gfe.GrpId = ge.GrpId;
                gfe.FuncId = Int32.Parse(objDE.Key.ToString());
                gfe.CreateTime = ge.CreateTime;
                gfe.UpdateTime = ge.UpdateTime;
                groupFunctionRepository.Add(gfe);
            }

            Save();
        }

        public void EditGroupFunction(int grpId, String grpName, String funcId, String user)
        {
            String[] funcIdArr = funcId.Split(',');
            DateTime currentTime = DateTime.Now;

            //update Group
            vc_quotn_Group ge = GetGroup(grpId);
            ge.GrpName = grpName;
            ge.Updator = user;
            ge.UpdateTime = currentTime;
            groupRepository.Update(ge);

            //delete GroupFunction
            groupFunctionRepository.Delete(x => x.GrpId == grpId);

            //insert GroupFunction
            Hashtable ht = new Hashtable();
            foreach (var i in funcIdArr)
            {
                getFuncParent(Int32.Parse(i), ht);
            }
            foreach (System.Collections.DictionaryEntry objDE in ht)
            {
                vc_quotn_GroupFunction gfe = new vc_quotn_GroupFunction();
                gfe.GrpId = ge.GrpId;
                gfe.FuncId = Int32.Parse(objDE.Key.ToString());
                gfe.CreateTime = ge.CreateTime;
                gfe.UpdateTime = ge.UpdateTime;
                groupFunctionRepository.Add(gfe);
            }

            Save();
        }

        public void DeleteGroupFunction(int grpId)
        {
            //delete GroupFunction
            groupFunctionRepository.Delete(x => x.GrpId == grpId);

            //delete Group
            DeleteGroup(grpId);

            Save();
        }

        public void DeleteGroup(int grpId)
        {
            var group = GetGroup(grpId);
            groupRepository.Delete(group);
            Save();
        }

        public Hashtable getFuncParent(int func, Hashtable ht)
        {
            if (!ht.ContainsKey(func)) 
            {
                ht.Add(func, func);
            }

            vc_quotn_Function fe = functionRepository.GetById(func);
            if (fe.ParentID > 0)
            {
                getFuncParent(fe.ParentID, ht);
            }

            return ht;
        }
        
        public void Save()
        {
            unitOfWork.Commit();
        }
      
    }
}
