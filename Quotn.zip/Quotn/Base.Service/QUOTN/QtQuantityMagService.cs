﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;
using System.Web.Mvc;

namespace Quotn.Service
{
    /// <summary>
    /// QtQuantityMagService Interface
    /// </summary>
    public interface IQtQuantityMagService
    {
        /// <summary>
        ///  Get All QuantityMag
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_QuantityMag> GetQuantityMags();

        /// <summary>
        /// Get QuantityMag by quantityMagId
        /// </summary>
        /// <param name="quantityMagId">quantityMagId</param>
        /// <returns>vc_quotn_QuantityMag</returns>
        vc_quotn_QuantityMag GetQuantityMag(String quantityMagId);

        /// <summary>
        /// Add QuantityMag Record
        /// </summary>
        /// <param name="user">vc_quotn_QuantityMag</param>
        void CreateQuantityMag(vc_quotn_QuantityMag quantityMag);

        /// <summary>
        /// Update QuantityMag Record
        /// </summary>
        /// <param name="user">vc_quotn_QuantityMag</param>
        void UpdateQuantityMag(vc_quotn_QuantityMag quantityMag);

        /// <summary>
        /// Update QuantityMag Records
        /// </summary>
        /// <param name="quantityMags"></param>
        /// <param name="user"></param>
        void UpdateQuantityMags(IEnumerable<vc_quotn_QuantityMag> quantityMags, String user);

        /// <summary>
        /// Delete QuantityMag Record
        /// </summary>
        /// <param name="Seq"></param>
        void DeleteQuantityMag(String categoryId, String color);

        /// <summary>
        /// Create QuantityMag History
        /// </summary>
        /// <param name="quantityMag"></param>
        void CreateQuantityMagHist(vc_quotn_QuantityMagHist quantityMag);

        /// <summary>
        /// Get QuantityMag History List
        /// </summary>
        /// <returns></returns>
        IEnumerable<vc_quotn_QuantityMagHist> GetQuantityMagHList();

        /// <summary>
        /// Get QuantityMagHList By Seq
        /// </summary>
        /// <param name="seq"></param>
        /// <returns></returns>
        IEnumerable<vc_quotn_QuantityMagHist> GetQuantityMagHListBySeq(long seq);

        /// <summary>
        /// get Category DropDown List
        /// </summary>
        /// <returns></returns>
        List<SelectListItem> getCategoryDownList();

        /// <summary>
        /// Commit 
        /// </summary>
        void Save();
    }

    public class QtQuantityMagService : IQtQuantityMagService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtQuantityMagRepository quantityMagRepository;
        private readonly IQtQuantityMagHistRepository quantityMagHistRepository;
        private readonly IQtSequenceService qtSequenceService;
        private readonly IQtCategoryParamRepository categoryParamRepository;

        public QtQuantityMagService(IQtQuantityMagRepository quantityMagRepository, IQtQuantityMagHistRepository quantityMagHistRepository, 
                                    IQtSequenceService qtSequenceService, IQtCategoryParamRepository categoryParamRepository, 
                                    IUnitOfWork unitOfWork)
        {
            this.quantityMagRepository = quantityMagRepository;
            this.quantityMagHistRepository = quantityMagHistRepository;
            this.qtSequenceService = qtSequenceService;
            this.categoryParamRepository = categoryParamRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_QuantityMag> GetQuantityMags()
        {
            var quantityMags = quantityMagRepository.GetAll();
            return quantityMags;
        }

        public vc_quotn_QuantityMag GetQuantityMag(String quantityMagId)
        {
            var quantityMag = quantityMagRepository.GetById(quantityMagId);
            return quantityMag;
        }

        public void CreateQuantityMag(vc_quotn_QuantityMag quantityMag)
        {
            quantityMagRepository.Add(quantityMag);
            Save();
        }

        public void UpdateQuantityMag(vc_quotn_QuantityMag quantityMag)
        {
            quantityMagRepository.Update(quantityMag);
            Save();
        }

        public void UpdateQuantityMags(IEnumerable<vc_quotn_QuantityMag> quantityMags,String user)
        {
            DateTime currentTime = DateTime.Now;
            List<vc_quotn_QuantityMag> quantityMagList = new List<vc_quotn_QuantityMag>();

            CheckData(quantityMags);

            IEnumerable<vc_quotn_QuantityMag> getQuantityMags = GetQuantityMags();
            foreach (vc_quotn_QuantityMag entity in quantityMags)
            {
                entity.Updator = user;
                entity.UpdateTime = currentTime;

                if (entity.CategoryId == null) continue;

                IEnumerable<vc_quotn_QuantityMag> orientity = getQuantityMags.Where(x => x.CategoryId == entity.CategoryId && x.Color == entity.Color);

                foreach (vc_quotn_QuantityMag qty in orientity)
                {
                    entity.Creator = qty.Creator;
                    entity.CreateTime = qty.CreateTime;
                }

                int add = orientity.Count();

                if (add == 0)//新增主檔
                {
                    entity.Creator = user;
                    entity.CreateTime = currentTime;
                    quantityMagRepository.Add(entity);
                }
                else//更新主檔
                {
                    int upd = getQuantityMags.Where(x => x.CategoryId == entity.CategoryId && x.Color == entity.Color &&
                                                         x.QtyMag1 == entity.QtyMag1 && x.QtyMag2 == entity.QtyMag2 &&
                                                         x.QtyMag3 == entity.QtyMag3 && x.QtyMag4 == entity.QtyMag4 &&
                                                         x.QtyMag5 == entity.QtyMag5 && x.Memo == entity.Memo
                                                   ).Count();
                    if (upd == 0)
                    {

                        IEnumerable<vc_quotn_QuantityMag> updEntity = getQuantityMags.Where(x => x.CategoryId == entity.CategoryId && x.Color == entity.Color);
                        foreach (vc_quotn_QuantityMag qty in updEntity)
                        {
                            qty.QtyMag1 = entity.QtyMag1;
                            qty.QtyMag2 = entity.QtyMag2;
                            qty.QtyMag3 = entity.QtyMag3;
                            qty.QtyMag4 = entity.QtyMag4;
                            qty.QtyMag5 = entity.QtyMag5;
                            qty.Memo = entity.Memo;
                            quantityMagRepository.Update(qty);
                        }
                    }
                }

                quantityMagList.Add(entity);
            }

            //刪除主檔
            foreach (vc_quotn_QuantityMag entity in getQuantityMags)
            {
                int del = quantityMags.Where(x => x.CategoryId == entity.CategoryId && x.Color == entity.Color).Count();
                if (del == 0)
                {
                    quantityMagRepository.Delete(entity);
                }
            }

            //建立歷程
            if (quantityMagList.Count > 0)
            {
                Int64 seq = qtSequenceService.GetSequence("QuantityMag", "數量倍率設定");
                foreach (vc_quotn_QuantityMag entity in quantityMagList)
                {
                    vc_quotn_QuantityMagHist quantityMagHist = new vc_quotn_QuantityMagHist();
                    quantityMagHist.Seq = seq;
                    quantityMagHist.CategoryId = entity.CategoryId;
                    quantityMagHist.Color = entity.Color;
                    quantityMagHist.QtyMag1 = entity.QtyMag1;
                    quantityMagHist.QtyMag2 = entity.QtyMag2;
                    quantityMagHist.QtyMag3 = entity.QtyMag3;
                    quantityMagHist.QtyMag4 = entity.QtyMag4;
                    quantityMagHist.QtyMag5 = entity.QtyMag5;
                    quantityMagHist.Memo = entity.Memo;
                    quantityMagHist.CreateTime = entity.CreateTime;
                    quantityMagHist.Creator = entity.Creator;
                    quantityMagHist.UpdateTime = entity.UpdateTime;
                    quantityMagHist.Updator = entity.Updator;
                    quantityMagHistRepository.Add(quantityMagHist);
                }
            }

            Save();
        }

        public void DeleteQuantityMag(String categoryId, String color)
        {
            vc_quotn_QuantityMag quantityMag = quantityMagRepository.Get(x => x.CategoryId == categoryId && x.Color == color);
            quantityMagRepository.Delete(quantityMag);
            Save();
        }

        public void CreateQuantityMagHist(vc_quotn_QuantityMagHist quantityMag)
        {
            quantityMagHistRepository.Add(quantityMag);
            Save();
        }

        public IEnumerable<vc_quotn_QuantityMagHist> GetQuantityMagHList()
        {
            IEnumerable<vc_quotn_QuantityMagHist> formulaParamHist = quantityMagHistRepository.GetAll();

            var consolidatedChildren =
                from c in formulaParamHist
                group c by new
                {
                    c.Seq,
                    c.Updator,
                    c.UpdateTime,
                } into gcs
                select new vc_quotn_QuantityMagHist()
                {
                    Seq = gcs.Key.Seq,
                    Updator = gcs.Key.Updator,
                    UpdateTime = gcs.Key.UpdateTime
                };
            return consolidatedChildren;
        }

        public IEnumerable<vc_quotn_QuantityMagHist> GetQuantityMagHListBySeq(long seq)
        {
            IEnumerable<vc_quotn_QuantityMagHist> formulaHList = quantityMagHistRepository.GetMany(x => x.Seq == seq);
            return formulaHList;
        }

        public List<SelectListItem> getCategoryDownList()
        {
            IEnumerable<vc_quotn_CategoryParam> getCategorys = categoryParamRepository.GetAll();

            List<SelectListItem> item = new List<SelectListItem>();
            item.Add(new SelectListItem
            {
                Text = "",
                Value = ""
            });

            foreach (vc_quotn_CategoryParam category in getCategorys)
            {
                item.Add(new SelectListItem
                {
                    Text = category.CategoryName,
                    Value = category.CategoryId
                });
            }

            return item;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        private void CheckData(IEnumerable<vc_quotn_QuantityMag> quantityMags)
        {
            Hashtable paramHt = new Hashtable();
            foreach (vc_quotn_QuantityMag quantityMag in quantityMags)
            {
                if (quantityMag.CategoryId != null && (quantityMag.QtyMag1 == null))
                {
                    throw new Exception("數量倍率為必輸項");
                }

                if (quantityMag.CategoryId != null && quantityMag.Color == null)
                {
                    quantityMag.Color = " ";
                }
            }
        }
      
    }
}
