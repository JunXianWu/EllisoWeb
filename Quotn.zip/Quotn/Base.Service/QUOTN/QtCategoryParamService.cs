﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// QtCategoryParamService Interface
    /// </summary>
    public interface IQtCategoryParamService
    {
        /// <summary>
        ///  Get All Category
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_CategoryParam> GetCategorys();

        /// <summary>
        /// Get Category by categoryId
        /// </summary>
        /// <param name="categoryId">categoryId</param>
        /// <returns>vc_quotn_CategoryParam</returns>
        vc_quotn_CategoryParam GetCategory(String categoryId);

        /// <summary>
        /// Add Category Record
        /// </summary>
        /// <param name="user">vc_quotn_CategoryParam</param>
        void CreateCategory(vc_quotn_CategoryParam category);

        /// <summary>
        /// Update Category Record
        /// </summary>
        /// <param name="user">vc_quotn_CategoryParam</param>
        void UpdateCategory(vc_quotn_CategoryParam category);

        /// <summary>
        /// Update Category Records
        /// </summary>
        /// <param name="categorys"></param>
        /// <param name="user"></param>
        void UpdateCategorys(IEnumerable<vc_quotn_CategoryParam> categorys, String user);

        /// <summary>
        /// Delete Category Record
        /// </summary>
        /// <param name="Seq"></param>
        void DeleteCategory(String categoryId);

        /// <summary>
        /// Delete Category All
        /// </summary>
        void DeleteCategoryAll();

        /// <summary>
        /// Create Category History
        /// </summary>
        /// <param name="category"></param>
        void CreateCategoryHist(vc_quotn_CategoryParamHist category);

        /// <summary>
        /// Get Category History List
        /// </summary>
        /// <returns></returns>
        IEnumerable<vc_quotn_CategoryParamHist> GetCategoryHList();

        /// <summary>
        /// Get CategoryHList By Seq
        /// </summary>
        /// <param name="seq"></param>
        /// <returns></returns>
        IEnumerable<vc_quotn_CategoryParamHist> GetCategoryHListBySeq(long seq);

        /// <summary>
        /// Commit 
        /// </summary>
        void Save();
    }

    public class QtCategoryParamService : IQtCategoryParamService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtCategoryParamRepository categoryParamRepository;
        private readonly IQtCategoryParamHistRepository categoryParamHistRepository;
        private readonly IQtSequenceService qtSequenceService;

        public QtCategoryParamService(IQtCategoryParamRepository categoryParamRepository, IQtCategoryParamHistRepository categoryParamHistRepository, IQtSequenceService qtSequenceService, IUnitOfWork unitOfWork)
        {
            this.categoryParamRepository = categoryParamRepository;
            this.categoryParamHistRepository = categoryParamHistRepository;
            this.qtSequenceService = qtSequenceService;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_CategoryParam> GetCategorys()
        {
            var categorys = categoryParamRepository.GetAll();
            return categorys;
        }

        public vc_quotn_CategoryParam GetCategory(String categoryId)
        {
            var category = categoryParamRepository.GetById(categoryId);
            return category;
        }

        public void CreateCategory(vc_quotn_CategoryParam category)
        {
            categoryParamRepository.Add(category);
            Save();
        }

        public void UpdateCategory(vc_quotn_CategoryParam category)
        {
            categoryParamRepository.Update(category);
            Save();
        }

        public void UpdateCategorys(IEnumerable<vc_quotn_CategoryParam> categorys,String user)
        {
            DateTime currentTime = DateTime.Now;
            List<vc_quotn_CategoryParam> categoryParamList = new List<vc_quotn_CategoryParam>();

            CheckData(categorys);

            //刪除主檔
            IEnumerable<vc_quotn_CategoryParam> getCategorys = GetCategorys();
            foreach (vc_quotn_CategoryParam entity in getCategorys)
            {
                vc_quotn_CategoryParam category = categoryParamRepository.GetById(entity.CategoryId);
                categoryParamRepository.Delete(category);
            }

            //新增主檔
            foreach (vc_quotn_CategoryParam entity in categorys)
            {
                if (entity.CategoryId == null) continue;

                entity.Creator = user;
                entity.CreateTime = currentTime;
                entity.Updator = user;
                entity.UpdateTime = currentTime;
                categoryParamRepository.Add(entity);
                categoryParamList.Add(entity);
            }

            //建立歷程
            if (categoryParamList.Count > 0)
            {
                Int64 seq = qtSequenceService.GetSequence("Category", "分類參數設定");
                foreach (vc_quotn_CategoryParam entity in categoryParamList)
                {
                    vc_quotn_CategoryParamHist categoryParamHist = new vc_quotn_CategoryParamHist();
                    categoryParamHist.Seq = seq;
                    categoryParamHist.CategoryId = entity.CategoryId;
                    categoryParamHist.CategoryName = entity.CategoryName;
                    categoryParamHist.CreateTime = entity.CreateTime;
                    categoryParamHist.Creator = entity.Creator;
                    categoryParamHist.UpdateTime = entity.UpdateTime;
                    categoryParamHist.Updator = entity.Updator;
                    categoryParamHistRepository.Add(categoryParamHist);
                }
            }

            Save();
        }

        public void DeleteCategory(String categoryId)
        {
            vc_quotn_CategoryParam category = categoryParamRepository.GetById(categoryId);
            categoryParamRepository.Delete(category);
            Save();
        }

        public void DeleteCategoryAll()
        {
            IEnumerable<vc_quotn_CategoryParam> formulas = GetCategorys();
            foreach (vc_quotn_CategoryParam entity in formulas)
            {
                DeleteCategory(entity.CategoryId);
            }
        }

        public void CreateCategoryHist(vc_quotn_CategoryParamHist category)
        {
            categoryParamHistRepository.Add(category);
            Save();
        }

        public IEnumerable<vc_quotn_CategoryParamHist> GetCategoryHList()
        {
            IEnumerable<vc_quotn_CategoryParamHist> formulaParamHist = categoryParamHistRepository.GetAll();

            var consolidatedChildren =
                from c in formulaParamHist
                group c by new
                {
                    c.Seq,
                    c.Updator,
                    c.UpdateTime,
                } into gcs
                select new vc_quotn_CategoryParamHist()
                {
                    Seq = gcs.Key.Seq,
                    Updator = gcs.Key.Updator,
                    UpdateTime = gcs.Key.UpdateTime
                };
            return consolidatedChildren;
        }

        public IEnumerable<vc_quotn_CategoryParamHist> GetCategoryHListBySeq(long seq)
        {
            IEnumerable<vc_quotn_CategoryParamHist> formulaHList = categoryParamHistRepository.GetMany(x => x.Seq == seq);
            return formulaHList;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        private void CheckData(IEnumerable<vc_quotn_CategoryParam> categorys)
        {
            Hashtable paramHt = new Hashtable();
            foreach (vc_quotn_CategoryParam categoryParam in categorys)
            {
                if (categoryParam.CategoryId != null)
                {
                    if (!paramHt.Contains(categoryParam.CategoryId))
                    {
                        paramHt.Add(categoryParam.CategoryId, categoryParam.CategoryName);
                    }
                    else
                    {
                        throw new Exception("代號重複");
                    }
                }
            }
        }
      
    }
}
