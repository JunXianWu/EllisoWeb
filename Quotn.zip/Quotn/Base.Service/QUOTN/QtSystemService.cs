﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QT.Data;
using Quotn.Domain;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// SystemService Interface
    /// </summary>
    public interface IQtSystemService
    {
        /// <summary>
        ///  Get All Systems
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_SystemParam> GetSystems();

        /// <summary>
        /// Get System By Key
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="um"></param>
        /// <returns></returns>
        vc_quotn_SystemParam GetSystemByKey(int id, string name, string um);

        /// <summary>
        /// Update System Record
        /// </summary>
        /// <param name="system"></param>
        /// <param name="user"></param>
        void UpdateSystem(IEnumerable<vc_quotn_SystemParam> system,String user);

        /// <summary>
        /// Commit System
        /// </summary>
        void Save();
    }

    public class QtSystemService : IQtSystemService
    {
        private readonly IQtSystemRepository systemRepository;
        private readonly IUnitOfWork unitOfWork;
        private BaseContext bc = new BaseContext();

        public QtSystemService(IQtSystemRepository systemRepository, IUnitOfWork unitOfWork)
        {
            this.systemRepository = systemRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_SystemParam> GetSystems()
        {
            var users = systemRepository.GetAll();
            return users;
        }

        public vc_quotn_SystemParam GetSystemByKey(int id, string name, string um)
        {
            var user = systemRepository.Get(x => x.ParamId == id && x.ParamName == name && x.ParamUm == um);
            return user;
        }

        public void UpdateSystem(IEnumerable<vc_quotn_SystemParam> system, String user)
        {
            foreach (var entity in system)
            {
                var se = (from x in bc.vc_quotn_SystemParam
                          where x.ParamId == entity.ParamId && x.ParamName == entity.ParamName && x.ParamUm == entity.ParamUm
                          select x
                              ).AsEnumerable();

                foreach (vc_quotn_SystemParam systemEntity in se)
                {
                    if (!systemEntity.ParamValue.Equals(entity.ParamValue))
                    {
                        systemEntity.ParamValue = entity.ParamValue;
                        systemEntity.Updator = user;
                        systemEntity.UpdateTime = DateTime.Now;
                        systemRepository.Update(systemEntity);
                    }
                }
            }

            Save();
        }

        public void Save()
        {
            unitOfWork.Commit();
        }
      
    }
}
