﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using Base.Data;
using System.Data;

namespace Quotn.Service
{
    public class QtEasyUITreeHelper
    {
        private BaseContext db = new BaseContext();

        public vc_quotn_Function GetRootNode()
        {
            if (this.db.vc_quotn_Function.Any())
            {
                return this.db.vc_quotn_Function.FirstOrDefault(x => x.ParentID <= 0);
            } 
            return null;
        }
        public IQueryable<vc_quotn_Function> GetNodes(bool isReadAll = false)
        {
            var query = this.db.vc_quotn_Function.AsQueryable();
            if (!isReadAll)
            {
                return query.Where(x => x.Enabled == 1 || (x.Enabled==0 && x.Url!=null && x.Url.IndexOf("/")==-1));
            } 
            return query;
        }
    }
}
