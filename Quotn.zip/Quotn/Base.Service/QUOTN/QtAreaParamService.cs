﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using QT.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace Quotn.Service
{
    /// <summary>
    /// QtAreaParamService Interface
    /// </summary>
    public interface IQtAreaParamService
    {
        /// <summary>
        ///  Get All Area
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<vc_quotn_AreaParam> GetAreas();

        /// <summary>
        /// Get Area by areaId
        /// </summary>
        /// <param name="areaId">areaId</param>
        /// <returns>vc_quotn_AreaParam</returns>
        vc_quotn_AreaParam GetArea(String areaId);

        /// <summary>
        /// Add Area Record
        /// </summary>
        /// <param name="user">vc_quotn_AreaParam</param>
        void CreateArea(vc_quotn_AreaParam area);

        /// <summary>
        /// Update Area Record
        /// </summary>
        /// <param name="user">vc_quotn_AreaParam</param>
        void UpdateArea(vc_quotn_AreaParam area);

        /// <summary>
        /// Update Area Records
        /// </summary>
        /// <param name="areas"></param>
        /// <param name="user"></param>
        void UpdateAreas(IEnumerable<vc_quotn_AreaParam> areas, String user);

        /// <summary>
        /// Delete Area Record
        /// </summary>
        /// <param name="Seq"></param>
        void DeleteArea(String areaId);

        /// <summary>
        /// Delete Area All
        /// </summary>
        void DeleteAreaAll();

        /// <summary>
        /// Create Area History
        /// </summary>
        /// <param name="area"></param>
        void CreateAreaHist(vc_quotn_AreaParamHist area);

        /// <summary>
        /// Get Area History List
        /// </summary>
        /// <returns></returns>
        IEnumerable<vc_quotn_AreaParamHist> GetAreaHList();

        /// <summary>
        /// Get AreaHList By Seq
        /// </summary>
        /// <param name="seq"></param>
        /// <returns></returns>
        IEnumerable<vc_quotn_AreaParamHist> GetAreaHListBySeq(long seq);

        /// <summary>
        /// Commit 
        /// </summary>
        void Save();
    }

    public class QtAreaParamService : IQtAreaParamService
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IQtAreaParamRepository areaParamRepository;
        private readonly IQtAreaParamHistRepository areaParamHistRepository;
        private readonly IQtSequenceService qtSequenceService;

        public QtAreaParamService(IQtAreaParamRepository areaParamRepository, IQtAreaParamHistRepository areaParamHistRepository, IQtSequenceService qtSequenceService, IUnitOfWork unitOfWork)
        {
            this.areaParamRepository = areaParamRepository;
            this.areaParamHistRepository = areaParamHistRepository;
            this.qtSequenceService = qtSequenceService;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<vc_quotn_AreaParam> GetAreas()
        {
            var areas = areaParamRepository.GetAll();
            return areas;
        }

        public vc_quotn_AreaParam GetArea(String areaId)
        {
            var area = areaParamRepository.GetById(areaId);
            return area;
        }

        public void CreateArea(vc_quotn_AreaParam area)
        {
            areaParamRepository.Add(area);
            Save();
        }

        public void UpdateArea(vc_quotn_AreaParam area)
        {
            areaParamRepository.Update(area);
            Save();
        }

        public void UpdateAreas(IEnumerable<vc_quotn_AreaParam> areas,String user)
        {
            DateTime currentTime = DateTime.Now;
            List<vc_quotn_AreaParam> areaParamList = new List<vc_quotn_AreaParam>();

            CheckData(areas);

            //刪除主檔
            IEnumerable<vc_quotn_AreaParam> getAreas = GetAreas();
            foreach (vc_quotn_AreaParam entity in getAreas)
            {
                if (areas.Where(x => x.AreaId == entity.AreaId).Count()==0)
                {
                    vc_quotn_AreaParam area = areaParamRepository.GetById(entity.AreaId);
                    areaParamRepository.Delete(area);
                }
            }

            //新增主檔
            foreach (vc_quotn_AreaParam entity in areas)
            {
                if (entity.AreaId == null) continue;

                entity.Creator = user;
                entity.CreateTime = currentTime;
                entity.Updator = user;
                entity.UpdateTime = currentTime;
                areaParamList.Add(entity);

                if (getAreas.Where(x => x.AreaId == entity.AreaId).Count() == 0)
                {
                    areaParamRepository.Add(entity);
                }
            }

            //建立歷程
            if (areaParamList.Count > 0)
            {
                Int64 seq = qtSequenceService.GetSequence("AreaParam", "區域參數設定");
                foreach (vc_quotn_AreaParam entity in areaParamList)
                {
                    vc_quotn_AreaParamHist areaParamHist = new vc_quotn_AreaParamHist();
                    areaParamHist.Seq = seq;
                    areaParamHist.AreaId = entity.AreaId;
                    areaParamHist.AreaName = entity.AreaName;
                    areaParamHist.CreateTime = entity.CreateTime;
                    areaParamHist.Creator = entity.Creator;
                    areaParamHist.UpdateTime = entity.UpdateTime;
                    areaParamHist.Updator = entity.Updator;
                    areaParamHistRepository.Add(areaParamHist);
                }
            }

            Save();
        }

        public void DeleteArea(String areaId)
        {
            vc_quotn_AreaParam area = areaParamRepository.GetById(areaId);
            areaParamRepository.Delete(area);
            Save();
        }

        public void DeleteAreaAll()
        {
            IEnumerable<vc_quotn_AreaParam> formulas = GetAreas();
            foreach (vc_quotn_AreaParam entity in formulas)
            {
                DeleteArea(entity.AreaId);
            }
        }

        public void CreateAreaHist(vc_quotn_AreaParamHist area)
        {
            areaParamHistRepository.Add(area);
            Save();
        }

        public IEnumerable<vc_quotn_AreaParamHist> GetAreaHList()
        {
            IEnumerable<vc_quotn_AreaParamHist> formulaParamHist = areaParamHistRepository.GetAll();

            var consolidatedChildren =
                from c in formulaParamHist
                group c by new
                {
                    c.Seq,
                    c.Updator,
                    c.UpdateTime,
                } into gcs
                select new vc_quotn_AreaParamHist()
                {
                    Seq = gcs.Key.Seq,
                    Updator = gcs.Key.Updator,
                    UpdateTime = gcs.Key.UpdateTime
                };
            return consolidatedChildren;
        }

        public IEnumerable<vc_quotn_AreaParamHist> GetAreaHListBySeq(long seq)
        {
            IEnumerable<vc_quotn_AreaParamHist> formulaHList = areaParamHistRepository.GetMany(x => x.Seq == seq);
            return formulaHList;
        }

        public void Save()
        {
            unitOfWork.Commit();
        }

        private void CheckData(IEnumerable<vc_quotn_AreaParam> areas)
        {
            Hashtable paramHt = new Hashtable();
            foreach (vc_quotn_AreaParam areaParam in areas)
            {
                if (areaParam.AreaId != null)
                {
                    if (!paramHt.Contains(areaParam.AreaId))
                    {
                        paramHt.Add(areaParam.AreaId, areaParam.AreaName);
                    }
                    else
                    {
                        throw new Exception("代號重複");
                    }
                }
            }
        }
      
    }
}
