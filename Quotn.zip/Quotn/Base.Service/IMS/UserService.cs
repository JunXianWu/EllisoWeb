﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IMS.Domain;
using IMS.Data;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;

namespace IMS.Service
{
    /// <summary>
    /// UserService Interface
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        ///  Get All User
        /// </summary>
        /// <returns>IEnumerable</returns>
        IEnumerable<UserEntity> GetUsers();

        /// <summary>
        /// Get User by userSeq
        /// </summary>
        /// <param name="UserSeq">userSeq</param>
        /// <returns>UserEntity</returns>
        UserEntity GetUser(int userSeq);

        /// <summary>
        /// Get User by userId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>UserEntity</returns>
        UserEntity GetUserById(String userId);

        /// <summary>
        /// Get UserSeq by userId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        int GetUserSeqById(String userId);

        /// <summary>
        /// Add User Record
        /// </summary>
        /// <param name="user">UserEntity</param>
        void CreateUser(UserEntity user);

        /// <summary>
        /// Update User Record
        /// </summary>
        /// <param name="user">UserEntity</param>
        void UpdateUser(UserEntity user);

        /// <summary>
        /// Delete User by userSeq
        /// </summary>
        /// <param name="UserSeq">userSeq</param>
        void DeleteUser(int userSeq);

        /// <summary>
        /// Commit User
        /// </summary>
        void Save();
    }

    public class UserService : IUserService
    {
        private readonly IUserRepository userRepository;
        private readonly IUnitOfWork unitOfWork;

        public UserService(IUserRepository userRepository, IUnitOfWork unitOfWork)
        {
            this.userRepository = userRepository;
            this.unitOfWork = unitOfWork;
        }

        public IEnumerable<UserEntity> GetUsers()
        {
            var users = userRepository.GetAll();
            return users;
        }

        public UserEntity GetUser(int userSeq)
        {
            var user = userRepository.GetById(userSeq);
            return user;
        }

        public UserEntity GetUserById(String userId)
        {
            UserEntity user = userRepository.Get(x => x.UserId == userId);
            return user;
        }

        public int GetUserSeqById(String userId)
        {
            int userSeq = userRepository.Get(x => x.UserId == userId).UserSeq;
            return userSeq;
        }

        public void CreateUser(UserEntity users)
        {
            userRepository.Add(users);
            Save();
        }

        public void UpdateUser(UserEntity user)
        {
            userRepository.Update(user);
            Save();
        }

        public void DeleteUser(int userSeq)
        {
            var user = GetUser(userSeq);
            userRepository.Delete(user);
            Save();
        }
        
        public void Save()
        {
            unitOfWork.Commit();
        }
    }
}
