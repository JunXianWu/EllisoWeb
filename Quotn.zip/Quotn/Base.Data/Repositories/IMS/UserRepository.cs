﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IMS.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace IMS.Data
{

    public class UserRepository : RepositoryBase<UserEntity>, IUserRepository
    {
        public UserRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IUserRepository : IRepository<UserEntity>
    {
    }
}
