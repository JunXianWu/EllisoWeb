﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace TS.Data
{

    public class TsTimesheetRepository : RepositoryBase<vc_ts_Timesheet>, ITsTimesheetRepository
    {
        public TsTimesheetRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface ITsTimesheetRepository : IRepository<vc_ts_Timesheet>
    {
    }
}
