﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace TS.Data
{

    public class TsEmployeeRepository : RepositoryBase<vc_ts_Employee>, ITsEmployeeRepository
    {
        public TsEmployeeRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface ITsEmployeeRepository : IRepository<vc_ts_Employee>
    {
    }
}
