﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TS.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace TS.Data
{

    public class TsFilesRepository : RepositoryBase<vc_ts_Files>, ITsFilesRepository
    {
        public TsFilesRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface ITsFilesRepository : IRepository<vc_ts_Files>
    {
    }
}
