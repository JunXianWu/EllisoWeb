﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtCategoryParamRepository : RepositoryBase<vc_quotn_CategoryParam>, IQtCategoryParamRepository
    {
        public QtCategoryParamRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtCategoryParamRepository : IRepository<vc_quotn_CategoryParam>
    {
    }

    public class QtCategoryParamHistRepository : RepositoryBase<vc_quotn_CategoryParamHist>, IQtCategoryParamHistRepository
    {
        public QtCategoryParamHistRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtCategoryParamHistRepository : IRepository<vc_quotn_CategoryParamHist>
    {
    }
}
