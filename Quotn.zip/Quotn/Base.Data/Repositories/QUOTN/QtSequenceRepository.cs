﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtSequenceRepository : RepositoryBase<vc_quotn_Sequence>, IQtSequenceRepository
    {
        public QtSequenceRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtSequenceRepository : IRepository<vc_quotn_Sequence>
    {
    }
}
