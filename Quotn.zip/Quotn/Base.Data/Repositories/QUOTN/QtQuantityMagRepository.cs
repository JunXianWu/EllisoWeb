﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtQuantityMagRepository : RepositoryBase<vc_quotn_QuantityMag>, IQtQuantityMagRepository
    {
        public QtQuantityMagRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtQuantityMagRepository : IRepository<vc_quotn_QuantityMag>
    {
    }

    public class QtQuantityMagHistRepository : RepositoryBase<vc_quotn_QuantityMagHist>, IQtQuantityMagHistRepository
    {
        public QtQuantityMagHistRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtQuantityMagHistRepository : IRepository<vc_quotn_QuantityMagHist>
    {
    }
}
