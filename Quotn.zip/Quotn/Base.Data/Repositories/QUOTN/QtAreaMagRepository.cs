﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtAreaMagRepository : RepositoryBase<vc_quotn_AreaMag>, IQtAreaMagRepository
    {
        public QtAreaMagRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtAreaMagRepository : IRepository<vc_quotn_AreaMag>
    {
    }

    public class QtAreaMagHistRepository : RepositoryBase<vc_quotn_AreaMagHist>, IQtAreaMagHistRepository
    {
        public QtAreaMagHistRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtAreaMagHistRepository : IRepository<vc_quotn_AreaMagHist>
    {
    }
}
