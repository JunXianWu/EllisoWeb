﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtGroupFunctionRepository : RepositoryBase<vc_quotn_GroupFunction>, IQtGroupFunctionRepository
    {
        public QtGroupFunctionRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtGroupFunctionRepository : IRepository<vc_quotn_GroupFunction>
    {
    }
}
