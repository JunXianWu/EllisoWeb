﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtFormulaParamRepository : RepositoryBase<vc_quotn_FormulaParam>, IQtFormulaParamRepository
    {
        public QtFormulaParamRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtFormulaParamRepository : IRepository<vc_quotn_FormulaParam>
    {
    }

    public class QtFormulaParamHistRepository : RepositoryBase<vc_quotn_FormulaParamHist>, IQtFormulaParamHistRepository
    {
        public QtFormulaParamHistRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtFormulaParamHistRepository : IRepository<vc_quotn_FormulaParamHist>
    {
    }
}
