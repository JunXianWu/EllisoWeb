﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Quotn.Domain;
using Base.Data.Infrastructure;
using System.Data;

namespace QT.Data
{

    public class QtAreaParamRepository : RepositoryBase<vc_quotn_AreaParam>, IQtAreaParamRepository
    {
        public QtAreaParamRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtAreaParamRepository : IRepository<vc_quotn_AreaParam>
    {
    }

    public class QtAreaParamHistRepository : RepositoryBase<vc_quotn_AreaParamHist>, IQtAreaParamHistRepository
    {
        public QtAreaParamHistRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

    public interface IQtAreaParamHistRepository : IRepository<vc_quotn_AreaParamHist>
    {
    }
}
