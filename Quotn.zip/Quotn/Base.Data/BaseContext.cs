﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using IMS.Domain;
using TS.Domain;
using Quotn.Domain;

namespace Base.Data
{
    public class BaseContext : DbContext
    {
        public DbSet<UserEntity> UserEntity { get; set; }
        public DbSet<FunctionEntity> FunctionEntity { get; set; }
        public DbSet<GroupFunctionEntity> GroupFunctionEntity { get; set; }
        public DbSet<vc_ts_Employee> vc_ts_Employee { get; set; }
        public DbSet<vc_ts_Timesheet> vc_ts_Timesheet { get; set; }
        public DbSet<vc_ts_TimesheetHist> vc_ts_TimesheetHist { get; set; }
        public DbSet<vc_ts_SystemEntity> vc_ts_SystemEntity { get; set; }
        public DbSet<vc_quotn_Employee> vc_quotn_Employee { get; set; }
        public DbSet<vc_quotn_Function> vc_quotn_Function { get; set; }
        public DbSet<vc_quotn_Group> vc_quotn_Group { get; set; }
        public DbSet<vc_quotn_GroupFunction> vc_quotn_GroupFunction { get; set; }
        public DbSet<vc_quotn_SystemParam> vc_quotn_SystemParam { get; set; }
        public DbSet<vc_quotn_FormulaParam> vc_quotn_FormulaParam { get; set; }
        public DbSet<vc_quotn_FormulaParamHist> vc_quotn_FormulaParamHist { get; set; }
        public DbSet<vc_quotn_AreaParam> vc_quotn_AreaParam { get; set; }
        public DbSet<vc_quotn_AreaParamHist> vc_quotn_AreaParamHist { get; set; }
        public DbSet<vc_quotn_CategoryParam> vc_quotn_CategoryParam { get; set; }
        public DbSet<vc_quotn_CategoryParamHist> vc_quotn_CategoryParamHist { get; set; }
        public DbSet<vc_quotn_AreaMag> vc_quotn_AreaMag { get; set; }
        public DbSet<vc_quotn_AreaMagHist> vc_quotn_AreaMagHist { get; set; }
        public DbSet<vc_quotn_QuantityMag> vc_quotn_QuantityMag { get; set; }
        public DbSet<vc_quotn_QuantityMagHist> vc_quotn_QuantityMagHist { get; set; }
        public DbSet<vc_quotn_Sequence> vc_quotn_Sequence { get; set; }

        public BaseContext()
            : base("name=" + System.Environment.MachineName)
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<BaseContext>());
        }

        public virtual void Commit()
        {
            base.SaveChanges();
        }
    }

    public class BaseContextInitializer : DropCreateDatabaseIfModelChanges<BaseContext>
    {
    }
}