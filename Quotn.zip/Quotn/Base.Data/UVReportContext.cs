﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using Quotn.Domain;
namespace Base.Data
{
    public class UVReportContext : DbContext
    {
        public DbSet<vc_SAcustomer> vc_SAcustomer { get; set; }

        public UVReportContext()
            : base("name=UVREPORT_" + System.Environment.MachineName)
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<UVReportContext>());
        }

        public virtual void Commit()
        {
            base.SaveChanges();
        }
    }
}