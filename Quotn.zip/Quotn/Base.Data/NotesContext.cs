﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using IMS.Domain;
using TS.Domain;
using Notes.Domain;
namespace Base.Data
{
    public class NotesContext : DbContext
    {
        public DbSet<vc_notes_ISP_Master> vc_notes_ISP_Master { get; set; }
        public DbSet<vc_notes_MPR_Master> vc_notes_MPR_Master { get; set; }
        public DbSet<vc_notes_Nas005_Master> vc_notes_Nas005_Master { get; set; }
        public DbSet<vc_notes_RPA> vc_notes_RPA { get; set; }

        public NotesContext()
            : base("name=NOTES_" + System.Environment.MachineName)
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<NotesContext>());
        }

        public virtual void Commit()
        {
            base.SaveChanges();
        }
    }
}