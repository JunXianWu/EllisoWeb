﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Threading;
using System.IO;
using TS.Domain;
using Base.Data;
using Base.Data.Infrastructure;
using System.Collections;
using System.Linq;

namespace TimeSheet.App_Start
{
    public class BackgroundWork
    {
        public static object oLock = new object();
        private static Timer timer;

        // 開始背景作業
        public void StartWork()
        {
            TimeSpan delayTime = new TimeSpan(0, 0, 0); // 應用程式起動後多久開始執行
            TimeSpan intervalTime = new TimeSpan(0, 1, 0); // 應用程式起動後間隔多久重複執行
            TimerCallback timerDelegate = new TimerCallback(BatchMethod);  // 委派呼叫方法
            timer = new Timer(timerDelegate, null, delayTime, intervalTime);  // 產生 timer
        }

        // 背景批次方法
        private void BatchMethod(object pStatus)
        {
            lock (oLock)
            {
                BaseContext bc = new BaseContext();
                var se = (from x in bc.vc_ts_SystemEntity
                          where x.ParamId == 2
                          select x
                              ).AsEnumerable();
                int week = 0, hour = 0, minute = 0;

                foreach (vc_ts_SystemEntity systemEntity in se)
                {
                    if (systemEntity.ParamUm.Equals("星期"))
                    {
                        week = Int32.Parse(systemEntity.ParamValue);
                    }
                    if (systemEntity.ParamUm.Equals("時"))
                    {
                        hour = Int32.Parse(systemEntity.ParamValue);
                    }
                    if (systemEntity.ParamUm.Equals("分"))
                    {
                        minute = Int32.Parse(systemEntity.ParamValue);
                    }
                }
                DateTime nowDate = DateTime.Now;

                DateTime dt = new DateTime(nowDate.Year, nowDate.Month, nowDate.Day);
                string nowWeek = dt.DayOfWeek.ToString("d");//tmp2 = 4 
                int nowHour = nowDate.Hour;
                int nowMinute = nowDate.Minute;

                if (Int32.Parse(nowWeek) == week && nowHour == hour && nowMinute == minute)
                {
                    //鎖定TimeSheet版本
                    var q = from p in bc.vc_ts_Timesheet
                            where p.IsPost == null || p.IsPost == "0"
                            select p;
                    foreach (var p in q)
                    {
                        p.IsPost = "1";
                    }

                    bc.SaveChanges();

                    //設定System鎖定Flag
                    var b = from a in bc.vc_ts_SystemEntity
                            where a.ParamId == 2 && a.ParamName == "排程鎖定" && a.ParamUm =="是否鎖定"
                            select a;
                    foreach (var a in b)
                    {
                        a.ParamValue = "1";
                    }

                    bc.SaveChanges();

                    using (StreamWriter sw = new StreamWriter(
                    System.Web.Hosting.HostingEnvironment.MapPath("~/ScheduleLockLog.txt")))
                    {
                        sw.WriteLine(DateTime.Now + " ： 星期-" + week + ",時-" + hour + ",分-" + minute);
                    }


                }
            }
        }
    }
}
