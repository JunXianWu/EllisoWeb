﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using CSSystem.Web.IoC;
using QT.Data;
using Base.Data.Infrastructure;
using Quotn.Domain;
using Quotn.Service;
using CSSystem.Web.Helpers;
using System.Data.Entity;
using Microsoft.Practices.Unity;
using TimeSheet.App_Start;

namespace CSSystem
{
    // 注意: 如需啟用 IIS6 或 IIS7 傳統模式的說明，
    // 請造訪 http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AuthConfig.RegisterAuth();
            IUnityContainer container = GetUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        private IUnityContainer GetUnityContainer()
        {
            //Create UnityContainer          
            IUnityContainer container = new UnityContainer()
            .RegisterType<IDatabaseFactory, DatabaseFactory>(new HttpContextLifetimeManager<IDatabaseFactory>())
            .RegisterType<IUnitOfWork, UnitOfWork>(new HttpContextLifetimeManager<IUnitOfWork>())
            .RegisterType<IQtFunctionRepository, QtFunctionRepository>(new HttpContextLifetimeManager<IQtFunctionRepository>())
            .RegisterType<IQtGroupFunctionRepository, QtGroupFunctionRepository>(new HttpContextLifetimeManager<IQtGroupFunctionRepository>())
            .RegisterType<IQtGroupRepository, QtGroupRepository>(new HttpContextLifetimeManager<IQtGroupRepository>())
            .RegisterType<IQtUserRepository, QtUserRepository>(new HttpContextLifetimeManager<IQtUserRepository>())
            .RegisterType<IQtSystemRepository, QtSystemRepository>(new HttpContextLifetimeManager<IQtSystemRepository>())
            .RegisterType<IQtFormulaParamRepository, QtFormulaParamRepository>(new HttpContextLifetimeManager<IQtFormulaParamRepository>())
            .RegisterType<IQtFormulaParamHistRepository, QtFormulaParamHistRepository>(new HttpContextLifetimeManager<IQtFormulaParamHistRepository>())
            .RegisterType<IQtAreaParamRepository, QtAreaParamRepository>(new HttpContextLifetimeManager<IQtAreaParamRepository>())
            .RegisterType<IQtAreaParamHistRepository, QtAreaParamHistRepository>(new HttpContextLifetimeManager<IQtAreaParamHistRepository>())
            .RegisterType<IQtCategoryParamRepository, QtCategoryParamRepository>(new HttpContextLifetimeManager<IQtCategoryParamRepository>())
            .RegisterType<IQtCategoryParamHistRepository, QtCategoryParamHistRepository>(new HttpContextLifetimeManager<IQtCategoryParamHistRepository>())
            .RegisterType<IQtAreaMagRepository, QtAreaMagRepository>(new HttpContextLifetimeManager<IQtAreaMagRepository>())
            .RegisterType<IQtAreaMagHistRepository, QtAreaMagHistRepository>(new HttpContextLifetimeManager<IQtAreaMagHistRepository>())
            .RegisterType<IQtQuantityMagRepository, QtQuantityMagRepository>(new HttpContextLifetimeManager<IQtQuantityMagRepository>())
            .RegisterType<IQtQuantityMagHistRepository, QtQuantityMagHistRepository>(new HttpContextLifetimeManager<IQtQuantityMagHistRepository>())
            .RegisterType<IQtSequenceRepository, QtSequenceRepository>(new HttpContextLifetimeManager<IQtSequenceRepository>())
            .RegisterType<IQtGroupService, QtGroupService>(new HttpContextLifetimeManager<IQtGroupService>())
            .RegisterType<IQtUserService, QtUserService>(new HttpContextLifetimeManager<IQtUserService>())
            .RegisterType<IQtSystemService, QtSystemService>(new HttpContextLifetimeManager<IQtSystemService>())
            .RegisterType<IQtFormulaParamService, QtFormulaParamService>(new HttpContextLifetimeManager<IQtFormulaParamService>())
            .RegisterType<IQtAreaParamService, QtAreaParamService>(new HttpContextLifetimeManager<IQtAreaParamService>())
            .RegisterType<IQtCategoryParamService, QtCategoryParamService>(new HttpContextLifetimeManager<IQtCategoryParamService>())
            .RegisterType<IQtAreaMagService, QtAreaMagService>(new HttpContextLifetimeManager<IQtAreaMagService>())
            .RegisterType<IQtQuantityMagService, QtQuantityMagService>(new HttpContextLifetimeManager<IQtQuantityMagService>())
            .RegisterType<IQtSequenceService, QtSequenceService>(new HttpContextLifetimeManager<IQtSequenceService>());
             return container;
        }

        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            HttpCookie MyLang = Request.Cookies["lang"];
            if (MyLang != null)
            {
                System.Threading.Thread.CurrentThread.CurrentCulture =
                    new System.Globalization.CultureInfo(MyLang.Value);
                System.Threading.Thread.CurrentThread.CurrentUICulture =
                    new System.Globalization.CultureInfo(MyLang.Value);
            }
        }
    }
}