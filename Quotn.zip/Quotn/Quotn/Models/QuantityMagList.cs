﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace QT.Models
{
    public class QuantityMagList
    {
        public long Seq { get; set; }
        public String CategoryId { get; set; }
        public String CategoryName { get; set; }
        public String Color { get; set; }
        public String QtyMag1 { get; set; }
        public String QtyMag2 { get; set; }
        public String QtyMag3 { get; set; }
        public String QtyMag4 { get; set; }
        public String QtyMag5 { get; set; }
        public String Memo { get; set; }
        public String Updator { get; set; }
        public DateTime UpdateTime { get; set; }
        public IPagedList<QuantityMagList> QuantityMagListModels { get; set; }
        public IPagedList<QuantityMagList> QuantityMagHListModels { get; set; }
        public int Page { get; set; }
    }
}