﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace TS.Models
{
    public class TimeSheetViewModel
    {
        [Display(Name = "組合Key")]
        public String CheckBoxKey { get; set; }

        [Display(Name = "流水號")]
        public int TimesheetSeq { get; set; }

        [Display(Name = "版本號")]
        public int TimeSheetId { get; set; }

        [Display(Name = "流水號")]
        public int Seq { get; set; }

        [Display(Name = "AD帳號")]
        public string EmployeeAd { get; set; }

        [Display(Name = "來源流水號")]
        public int ParentSeq { get; set; }

        [Display(Name = "優先序")]
        public int Order { get; set; }

        [Display(Name = "單號")]
        public string DocNo { get; set; }

        [Display(Name = "種類")]
        public string Category { get; set; }

        [Display(Name = "項目")]
        public string Item { get; set; }

        [Display(Name = "項目描述")]
        public string ItemDesc { get; set; }

        [Display(Name = "問題處理")]
        public string Question { get; set; }

        [Display(Name = "累計工時")]
        public decimal TtlTime { get; set; }

        [Display(Name = "本週工時")]
        [RegularExpression(@"[0-9]*\.?[0-9]+", ErrorMessage = "{0} 必須為數字")]
        public decimal ThisWeekTime { get; set; }

        [Display(Name = "上週進度")]
        public decimal LastWeekSchedule { get; set; }

        [Display(Name = "預計進度")]
        public decimal ThisWeekForecast { get; set; }

        [Display(Name = "實際進度")]
        public decimal ThisWeekActual { get; set; }

        [Display(Name = "建立日期")]
        public string InputDate { get; set; }

        [Display(Name = "逾期列表")]
        public string OverDueList { get; set; }

        [Display(Name = "預計完成日")]
        public string ForecastDate { get; set; }

        [Display(Name = "調整預計日")]
        public string EditForecastDate { get; set; }

        [Display(Name = "完成日")]
        public string CompleteDate { get; set; }

        [Display(Name = "檔案連結")]
        public string Url { get; set; }

        [Display(Name = "檔案名稱")]
        public string FileName { get; set; }

        [Display(Name = "更新日期")]
        public DateTime UpdateDate { get; set; }

        [Display(Name = "更新人員")]
        public string UpdateUser { get; set; }

        [Display(Name = "刪除項")]
        public String IsDel { get; set; }

        [Display(Name = "當週逾期")]
        public String IsDue { get; set; }
    }
}