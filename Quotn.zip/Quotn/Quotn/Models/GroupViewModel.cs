﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using Quotn.Domain;

namespace CSSystem.Models
{
    public class GroupViewModel
    {
        public String GroupId { get; set; }
        public String GroupName { get; set; }
        public IPagedList<vc_quotn_Group> Groups { get; set; }
        public int Page { get; set; }

        public GroupViewModel()
        {
            GroupId = string.Empty;
            GroupName = string.Empty;
            Page = 0;
        }
    }
}