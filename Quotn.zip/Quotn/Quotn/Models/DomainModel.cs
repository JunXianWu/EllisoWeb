﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Data;
using Base.Data;
using CSSystem.Domain;
using Base.Data.Infrastructure;

namespace CSSystem.Models
{
    public class DomainModel
    {

        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        private readonly IUnitOfWork unitOfWork;

        public DomainModel(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

 
    }
}