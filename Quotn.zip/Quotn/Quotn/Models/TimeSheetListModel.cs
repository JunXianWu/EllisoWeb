﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace TS.Models
{
    public class TimeSheetListModel
    {
        public String UserAd { get; set; }
        public String UserName { get; set; }
        public String TimeSheetId { get; set; }
        public DateTime UpdateDate { get; set; }
        public int OverDueCount { get; set; }
        public IPagedList<TimeSheetListModel> TimeSheetListModels { get; set; }
        public int Page { get; set; }
    }
}