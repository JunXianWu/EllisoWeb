﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace QT.Models
{
    public class FormulaParamList
    {
        public String FormulaId { get; set; }
        public String FormulaName { get; set; }
        public String Memo { get; set; }
        public long Seq { get; set; }
        public String Updator { get; set; }
        public DateTime UpdateTime { get; set; }
        public IPagedList<FormulaParamList> FormulaParamListModels { get; set; }
        public IPagedList<FormulaParamList> FormulaParamHListModels { get; set; }
        public int Page { get; set; }
    }
}