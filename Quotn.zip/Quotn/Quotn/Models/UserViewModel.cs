﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using Quotn.Domain;
using System.ComponentModel.DataAnnotations;

namespace CSSystem.Models
{
    public class UserViewModel
    {
        public int UserSeq { get; set; }

        [Required]
        [Display(Name = "使用者代號")]
        [StringLength(25, ErrorMessage = "{0} 長度至少必須為 {2} 個字元。", MinimumLength = 1)]
        public String UserId {get; set; }

        [Required]
        [Display(Name = "使用者名稱")]
        public String UserName { get; set; }

        [Required]
        [Range(1, 999999, ErrorMessage = "群組名稱 欄位是必要項")]
        [Display(Name = "群組名稱")]
        public int GrpId { get; set; }

        [Required]
        [Display(Name = "使用者AD")]
        public string UserAd { get; set; }

        [Required]
        [Display(Name = "部門別")]
        public string DepartmentId { get; set; }

        public String GrpName { get; set; }        
        public DateTime CreateDate { get; set; }
        public string CreateUser { get; set; }
        public DateTime UpdateDate { get; set; }
        public string UpdateUser { get; set; }
        public IPagedList<vc_quotn_Employee> Users { get; set; }
        public int Page { get; set; }

        public UserViewModel() 
        {
            UserId = string.Empty;
            UserName = string.Empty;
            Page = 0;
        }
    }
}