﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace QT.Models
{
    public class CategoryParamList
    {
        public String CategoryId { get; set; }
        public String CategoryName { get; set; }
        public long Seq { get; set; }
        public String Updator { get; set; }
        public DateTime UpdateTime { get; set; }
        public IPagedList<CategoryParamList> CategoryParamListModels { get; set; }
        public IPagedList<CategoryParamList> CategoryParamHListModels { get; set; }
        public int Page { get; set; }
    }
}