﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Quotn.Domain;

namespace CSSystem.Models
{
    public class TreeViewModel
    {
        public vc_quotn_Function RootNode { get; set; }
        public List<vc_quotn_Function> TreeNodes { get; set; }
    }
}
