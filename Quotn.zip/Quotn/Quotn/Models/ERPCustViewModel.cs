﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;

namespace CSSystem.Models
{
    public class ERPCustViewModel
    {
        public String CustId { get; set; }
        public String CustName {get; set; }
        public IPagedList<UserViewModel> Users { get; set; }
        public int Page { get; set; }

        public ERPCustViewModel() 
        {
            CustId = string.Empty;
            CustName = string.Empty;
            Page = 0;
        }
    }
}