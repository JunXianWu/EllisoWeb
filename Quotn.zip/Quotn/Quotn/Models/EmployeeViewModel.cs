﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcPaging;
using CSSystem.Domain;
using System.ComponentModel.DataAnnotations;

namespace TS.Models
{
    public class EmployeeViewModel
    {
        [Display(Name = "使用者ID")]
        public string UserId { get; set; }

        [Display(Name = "使用者名稱")]
        public string UserName { get; set; }

        [Display(Name = "是否為管理者")]
        public Boolean IsAdmin { get; set; }

    }
}