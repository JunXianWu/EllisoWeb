﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using System.ComponentModel;
using CSSystem.Domain;

namespace CSSystem.Models
{
    public class UsersContext : DbContext
    {
        public UsersContext()
            : base(System.Environment.MachineName)
        {
        }

        public DbSet<UserProfile> UserProfiles { get; set; }
    }

    [Table("vc_css_User")]
    public class UserProfile
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int UserSeq { get; set; }
        public string UserId { get; set; }
	    public string FisrtName { get; set; }
	    public string LastName { get; set; }
	    public string Email  { get; set; }
	    public string UserName { get; set; }
	    public int Enabled  { get; set; }
	    public int GrpId { get; set; }
	    public string CustNum { get; set; }
        public DateTime CreateDate { get; set; }
	    public string CreateUser { get; set; }
        public DateTime UpdateDate { get; set; }
        public string UpdateUser { get; set; }
    }

    public class RegisterExternalLoginModel
    {
        [Required]
        [Display(Name = "使用者名稱")]
        public string UserName { get; set; }

        public string ExternalLoginData { get; set; }
    }

    public class LocalPasswordModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "{0} 長度至少必須為 {2} 個字元。", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New Password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Comfirm New Password")]
        [Compare("NewPassword", ErrorMessage = "新密碼與確認密碼不相符。")]
        public string ConfirmPassword { get; set; }
    }

    public class LoginModel
    {
        [Required(ErrorMessage = "User Name is required")]
        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "User Password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "User Password")]
        public string Password { get; set; }

        [Display(Name = "Remember Me?")]
        public bool RememberMe { get; set; }
    }

    public class RegisterModel
    {
        [Required]
        [Display(Name = "使用者名稱")]
        public string UserName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "{0} 長度至少必須為 {2} 個字元。", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "密碼")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "確認密碼")]
        [Compare("Password", ErrorMessage = "密碼和確認密碼不相符。")]
        public string ConfirmPassword { get; set; }
    }

    public class ExternalLogin
    {
        public string Provider { get; set; }
        public string ProviderDisplayName { get; set; }
        public string ProviderUserId { get; set; }
    }

    public class FunctionModel
    {
        public int FuncId { get; set; }
        public string FuncName { get; set; }
    }

    public class GroupModel
    {
        [DisplayName("群組編號")]
        public int GrpId { get; set; }
        [DisplayName("群組名稱")]
        public string GrpName { get; set; }
        [DisplayName("建立日期")]
        public DateTime CreateDate { get; set; }
        [DisplayName("建立者")]
        public string CreateUser { get; set; }
        [DisplayName("更新日期")]
        public DateTime UpdateDate { get; set; }
        [DisplayName("更新者")]
        public string UpdateUser { get; set; }
    }

    public class ForgotPasswordModel
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        public string Email { get; set; }
    }
}
