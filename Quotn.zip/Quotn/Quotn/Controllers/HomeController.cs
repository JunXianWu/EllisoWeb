﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CSSystem.Models;
using Base.Data;
using System.Collections;
using System.Web.Security;
using Quotn.Service;
using Quotn.Domain;

namespace Quotn.Controllers
{
    public class HomeController : Controller
    {
        private QtEasyUITreeHelper _help = new QtEasyUITreeHelper();

        private readonly IQtGroupService groupService;
        private readonly IQtUserService userService;

        public HomeController(IQtGroupService groupService, IQtUserService userService)
        {
            this.groupService = groupService;
            this.userService = userService;
        }

        public ActionResult Index()
        {
            HttpCookie myCookie = Request.Cookies[FormsAuthentication.FormsCookieName];

            if (myCookie != null)
            {
                FormsAuthenticationTicket fat = FormsAuthentication.Decrypt(myCookie.Value);
                string[] userData = fat.UserData.Split(',');
                var EmployeeAd = userData[1];
                var EmployeeName = userData[0];
                Session.Add("UserAd", EmployeeAd);
                Session.Add("UserName", EmployeeName);
                Session.Add("HeadOpen", "1");

                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                  EmployeeAd,//你想要存放在 User.Identy.Name 的值，通常是使用者帳號
                  DateTime.Now,
                  DateTime.Now.AddMinutes(FormsAuthentication.Timeout.TotalMinutes),
                  false,//將管理者登入的 Cookie 設定成 Session Cookie
                  EmployeeName + "," + EmployeeAd,//userdata看你想存放啥
                  FormsAuthentication.FormsCookiePath);

                string encTicket = FormsAuthentication.Encrypt(ticket);

                Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }

            if (User.Identity is FormsIdentity)
            {
                FormsIdentity id = (FormsIdentity) User.Identity;
                FormsAuthenticationTicket ticket = id.Ticket;
                string[] userData = ticket.UserData.Split(',');
                Session.Add("UserName", userData[0]);
                Session.Add("UserAd", userData[1]);
                if (Session["HeadOpen"]==null) Session.Add("HeadOpen", "1");
                if (userData.Length>=3) Session.Add("src", userData[2]);
            }

            var rootNode = this._help.GetRootNode();
            var nodes = this._help.GetNodes();
            TreeViewModel model = new TreeViewModel
            {
                RootNode = rootNode,
                TreeNodes = nodes.ToList()
            };

            var userAd = User.Identity.Name;
            vc_quotn_Employee ue = userService.GetUserByAd(userAd);

            Hashtable ht = groupService.GetGroupFunction(ue.GrpId);
            ht.Add("Model", model);

            System.Web.HttpContext.Current.Session["menu"] = ht;

            return View(model);
        }
    }
}
