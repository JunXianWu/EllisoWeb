﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CSSystem.Models;
using Base.Data;
using Base.Service.Utils;
using System.Collections;
using Quotn.Service;
using Quotn.Domain;
using QT.Models;
using MvcPaging;
using CSSystem.Web.Helpers;
using System.Web.Security;
using Base.Service;

namespace Quotn.Controllers
{
    public class PreParameterController : Controller
    {
        private int PageSize = 0;
        private readonly IQtFormulaParamService qtFormulaParamService;
        private readonly IQtAreaParamService qtAreaParamService;
        private readonly IQtCategoryParamService qtCategoryParamService;
        private readonly IQtAreaMagService qtAreaMagService;
        private readonly IQtQuantityMagService qtQuantityMagService;
        private readonly IQtUserService qtUserService;
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private readonly DropDownList ddl = new DropDownList();

        private String FUN_MASTER_SETTING = "FUN_MASTER_SETTING";
        private String search = @Resources.Resource.BTN_SEARCH;
        private String query = @Resources.Resource.BTN_QUERY;
        private String setting = @Resources.Resource.BTN_SET;
        private String back = @Resources.Resource.BTN_BACK_LAST_PAGE;
        private String submit = @Resources.Resource.BTN_SUBMIT;
        private String addRow = @Resources.Resource.BTN_ADD_ROW;

        public PreParameterController(IQtUserService qtUserService, IQtSystemService qtSystemService, 
                                      IQtFormulaParamService qtFormulaParamService, IQtAreaParamService qtAreaParamService, 
                                      IQtCategoryParamService qtCategoryParamService, IQtAreaMagService qtAreaMagService, 
                                      IQtQuantityMagService qtQuantityMagService)
        {
            this.qtUserService = qtUserService;
            this.qtFormulaParamService = qtFormulaParamService;
            this.qtAreaParamService = qtAreaParamService;
            this.qtCategoryParamService = qtCategoryParamService;
            this.qtAreaMagService = qtAreaMagService;
            this.qtQuantityMagService = qtQuantityMagService;
            PageSize = Int32.Parse(qtSystemService.GetSystemByKey(1, "分頁", "筆數").ParamValue);
        }

        //公式參數設定-主檔設定
        /*****************************************************************************************/
        public ActionResult FormulaParamM()
        {
            List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);
            IEnumerable<vc_quotn_FormulaParam> getFormulas = qtFormulaParamService.GetFormulas();
            List<FormulaParamList> mainList = new List<FormulaParamList>();

            foreach (vc_quotn_FormulaParam listModel in getFormulas)
            {
                FormulaParamList fpl = new FormulaParamList();
                fpl.FormulaId = listModel.FormulaId;
                fpl.FormulaName = listModel.FormulaName;
                fpl.Memo = listModel.Memo;
                mainList.Add(fpl);
            }

            FormulaParamList viewModel = new FormulaParamList();

            viewModel.FormulaParamHListModels = mainList.AsEnumerable().OrderBy(p => p.FormulaId)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }

            ViewBag.ActionList = actionList;
            return View("FormulaParam/FormulaParamM", viewModel);
        }

        [HttpPost]
        public ActionResult FormulaParamM(IEnumerable<vc_quotn_FormulaParam> formulaParam, string submitValue)
        {
            if (submitValue.Equals(back))
            {
                return RedirectToAction("FormulaParamM", "PreParameter");
            }

            if (submitValue.Equals(submit))
            {
                try
                {
                    qtFormulaParamService.UpdateFormulas(formulaParam, User.Identity.Name);
                    this.AddNotification("更新成功", NotificationType.SUCCESS);
                    return RedirectToAction("FormulaParamM","PreParameter");
                }
                catch (Exception ex)
                {
                    logger.Error("FormulaParamSetM Exception : " + ex);
                    this.AddNotification("更新失敗 : " + ExceptionHandle.getExceptionMsg(ex), NotificationType.ERROR);
                    return View("FormulaParam/FormulaParamSet", formulaParam);
                }
            }

            List<vc_quotn_FormulaParam> formula = null;
            if (formulaParam == null)
            {
                formula = qtFormulaParamService.GetFormulas().ToList();
            }
            else
            {
                formula = formulaParam.ToList();
            }

            if (submitValue.Equals(addRow))
            {
                for (int i = 0; i < 10; i++)
                {
                    vc_quotn_FormulaParam entity = new vc_quotn_FormulaParam();
                    formula.Add(entity);
                }
            }
            else
            {
                int count = formula.Count;

                if (count < 10)
                {
                    for (int i = 0; i < 10 - count; i++)
                    {
                        vc_quotn_FormulaParam entity = new vc_quotn_FormulaParam();
                        formula.Add(entity);
                    }
                }
            }

            return View("FormulaParam/FormulaParamSet", formula);
        }
        /*****************************************************************************************/


        //公式參數設定-歷程查詢
        /*****************************************************************************************/
        public ActionResult FormulaParamHIndex(int page=1)
        {
            var userAd = User.Identity.Name;
            IEnumerable<vc_quotn_FormulaParamHist> allFph = qtFormulaParamService.GetFormulaHList();
            List<FormulaParamList> mainList = new List<FormulaParamList>();

            foreach (vc_quotn_FormulaParamHist listModel in allFph)
            {
                FormulaParamList fpl = new FormulaParamList();
                fpl.Seq = listModel.Seq;
                fpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                fpl.UpdateTime = listModel.UpdateTime;
                mainList.Add(fpl);
            }

            FormulaParamList viewModel = new FormulaParamList();

            viewModel.FormulaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }
            ViewBag.UserAd = userAd;
            return View("FormulaParam/FormulaParamHIndex", viewModel);
        }

        [HttpPost]
        public ActionResult FormulaParamHIndex(FormulaParamList viewModel, string submitValue)
        {

            if (submitValue != null)
            {

                if (submitValue.Equals(back))
                {
                    return RedirectToAction("FormulaParamHIndex", "PreParameter");
                }

                if (submitValue.Equals(search))
                {
                    var userAd = User.Identity.Name;
                    IEnumerable<vc_quotn_FormulaParamHist> allFph = qtFormulaParamService.GetFormulaHList();
                    List<FormulaParamList> mainList = new List<FormulaParamList>();

                    foreach (vc_quotn_FormulaParamHist listModel in allFph)
                    {
                        FormulaParamList fpl = new FormulaParamList();
                        fpl.Seq = listModel.Seq;
                        fpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                        fpl.UpdateTime = listModel.UpdateTime;
                        mainList.Add(fpl);
                    }

                    viewModel.FormulaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    if (mainList.Count == 0)
                    {
                        this.AddNotification("查無資料", NotificationType.ERROR);
                    }
                    ViewBag.UserAd = userAd;
                }
                else if (submitValue.Equals(query))
                {
                    String seq = Request["Seq"];
                    if (seq != null)
                    {
                        long selectKey = (long)(Int64.Parse(seq));
                        IEnumerable<vc_quotn_FormulaParamHist> allFph = qtFormulaParamService.GetFormulaHListBySeq(selectKey);
                        return View("FormulaParam/FormulaParamH", allFph);
                    }
                    else
                    {
                        this.AddNotification("請選擇資料", NotificationType.ERROR);
                    }
                }
            }
            else
            {
                var userAd = User.Identity.Name;
                IEnumerable<vc_quotn_FormulaParamHist> allFph = qtFormulaParamService.GetFormulaHList();
                List<FormulaParamList> mainList = new List<FormulaParamList>();

                foreach (vc_quotn_FormulaParamHist listModel in allFph)
                {
                    FormulaParamList fpl = new FormulaParamList();
                    fpl.Seq = listModel.Seq;
                    fpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                    fpl.UpdateTime = listModel.UpdateTime;
                    mainList.Add(fpl);
                }

                viewModel.FormulaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                if (mainList.Count == 0)
                {
                    this.AddNotification("查無資料", NotificationType.ERROR);
                }
                ViewBag.UserAd = userAd;
            }

            return View("FormulaParam/FormulaParamHIndex", viewModel);
        }
        /*****************************************************************************************/

        //區域參數設定-主檔設定
        /*****************************************************************************************/
        public ActionResult AreaParamM(int page = 1)
        {
            IEnumerable<vc_quotn_AreaParam> getAreas = qtAreaParamService.GetAreas();
            List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);
            List<AreaParamList> mainList = new List<AreaParamList>();

            foreach (vc_quotn_AreaParam listModel in getAreas)
            {
                AreaParamList apl = new AreaParamList();
                apl.AreaId = listModel.AreaId;
                apl.AreaName = listModel.AreaName;
                mainList.Add(apl);
            }

            AreaParamList viewModel = new AreaParamList();

            viewModel.AreaParamListModels = mainList.AsEnumerable().OrderBy(p => p.AreaId)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }

            ViewBag.ActionList = actionList;

            return View("AreaParam/AreaParamM", viewModel);
        }

        [HttpPost]
        public ActionResult AreaParamM(AreaParamList viewModel, IEnumerable<vc_quotn_AreaParam> areaParam, string submitValue)
        {
            if (submitValue.Equals(back))
            {
                return RedirectToAction("AreaParamM", "PreParameter");
            }

            if (submitValue.Equals(submit))
            {
                try
                {
                    qtAreaParamService.UpdateAreas(areaParam, User.Identity.Name);
                    this.AddNotification("更新成功", NotificationType.SUCCESS);
                    return RedirectToAction("AreaParamM", "PreParameter");
                }
                catch (Exception ex)
                {
                    this.AddNotification("更新失敗 : " + ExceptionHandle.getExceptionMsg(ex), NotificationType.ERROR);
                    return View("AreaParam/AreaParamSet", areaParam);
                }
            }

            List<vc_quotn_AreaParam> area = null;
            if (areaParam == null)
            {
                area = qtAreaParamService.GetAreas().ToList();
            }
            else
            {
                area = areaParam.ToList();
            }

            if (submitValue.Equals(addRow))
            {
                for (int i = 0; i < 10; i++)
                {
                    vc_quotn_AreaParam entity = new vc_quotn_AreaParam();
                    area.Add(entity);
                }
            }
            else
            {
                int count = area.Count;

                if (count < 10)
                {
                    for (int i = 0; i < 10 - count; i++)
                    {
                        vc_quotn_AreaParam entity = new vc_quotn_AreaParam();
                        area.Add(entity);
                    }
                }
            }

            return View("AreaParam/AreaParamSet", area);

        }
        /*****************************************************************************************/

        //區域參數設定-歷程查詢
        /*****************************************************************************************/
        public ActionResult AreaParamHIndex(int page = 1)
        {
            var userAd = User.Identity.Name;
            IEnumerable<vc_quotn_AreaParamHist> allAph = qtAreaParamService.GetAreaHList();
            List<AreaParamList> mainList = new List<AreaParamList>();

            foreach (vc_quotn_AreaParamHist listModel in allAph)
            {
                AreaParamList apl = new AreaParamList();
                apl.Seq = listModel.Seq;
                apl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                apl.UpdateTime = listModel.UpdateTime;
                mainList.Add(apl);
            }

            AreaParamList viewModel = new AreaParamList();

            viewModel.AreaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }
            ViewBag.UserAd = userAd;
            return View("AreaParam/AreaParamHIndex", viewModel);
        }

        [HttpPost]
        public ActionResult AreaParamHIndex(AreaParamList viewModel, string submitValue)
        {

            if (submitValue != null)
            {

                if (submitValue.Equals(back))
                {
                    return RedirectToAction("AreaParamHIndex", "PreParameter");
                }

                if (submitValue.Equals(search))
                {
                    var userAd = User.Identity.Name;
                    IEnumerable<vc_quotn_AreaParamHist> allAph = qtAreaParamService.GetAreaHList();
                    List<AreaParamList> mainList = new List<AreaParamList>();

                    foreach (vc_quotn_AreaParamHist listModel in allAph)
                    {
                        AreaParamList apl = new AreaParamList();
                        apl.Seq = listModel.Seq;
                        apl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                        apl.UpdateTime = listModel.UpdateTime;
                        mainList.Add(apl);
                    }

                    viewModel.AreaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    if (mainList.Count == 0)
                    {
                        this.AddNotification("查無資料", NotificationType.ERROR);
                    }
                    ViewBag.UserAd = userAd;
                }
                else if (submitValue.Equals(query))
                {
                    String seq = Request["Seq"];
                    long selectKey = (long)(Int64.Parse(seq));
                    IEnumerable<vc_quotn_AreaParamHist> allTs = qtAreaParamService.GetAreaHListBySeq(selectKey);

                    return View("AreaParam/AreaParamH", allTs);
                }
            }
            else
            {
                var userAd = User.Identity.Name;
                IEnumerable<vc_quotn_AreaParamHist> allAph = qtAreaParamService.GetAreaHList();
                List<AreaParamList> mainList = new List<AreaParamList>();

                foreach (vc_quotn_AreaParamHist listModel in allAph)
                {
                    AreaParamList apl = new AreaParamList();
                    apl.Seq = listModel.Seq;
                    apl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                    apl.UpdateTime = listModel.UpdateTime;
                    mainList.Add(apl);
                }

                viewModel.AreaParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                if (mainList.Count == 0)
                {
                    this.AddNotification("查無資料", NotificationType.ERROR);
                }
                ViewBag.UserAd = userAd;
            }

            return View("AreaParam/AreaParamHIndex", viewModel);
        }
        /*****************************************************************************************/

        //分類參數設定-主檔設定
        /*****************************************************************************************/
        public ActionResult CategoryParamM()
        {
            IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
            List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);
            List<CategoryParamList> mainList = new List<CategoryParamList>();

            foreach (vc_quotn_CategoryParam listModel in getCategorys)
            {
                CategoryParamList cpl = new CategoryParamList();
                cpl.CategoryId = listModel.CategoryId;
                cpl.CategoryName = listModel.CategoryName;
                mainList.Add(cpl);
            }

            CategoryParamList viewModel = new CategoryParamList();

            viewModel.CategoryParamListModels = mainList.AsEnumerable().OrderBy(p => p.CategoryId)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }

            ViewBag.ActionList = actionList;

            return View("CategoryParam/CategoryParamM", viewModel);
        }

        [HttpPost]
        public ActionResult CategoryParamM(CategoryParamList viewModel, IEnumerable<vc_quotn_CategoryParam> categoryParam, string submitValue)
        {
            if (submitValue.Equals(back))
            {
                return RedirectToAction("CategoryParamM", "PreParameter");
            }

            if (submitValue.Equals(submit))
            {
                try
                {
                    qtCategoryParamService.UpdateCategorys(categoryParam, User.Identity.Name);
                    this.AddNotification("更新成功", NotificationType.SUCCESS);
                    return RedirectToAction("CategoryParamM", "PreParameter");
                }
                catch (Exception ex)
                {
                    logger.Error("CategoryParamSetM Exception : " + ex);
                    this.AddNotification("更新失敗 : " + ExceptionHandle.getExceptionMsg(ex), NotificationType.ERROR);
                    return View("CategoryParam/CategoryParamSet", categoryParam);
                }
            }

            List<vc_quotn_CategoryParam> category = null;
            if (categoryParam == null)
            {
                category = qtCategoryParamService.GetCategorys().ToList();
            }
            else
            {
                category = categoryParam.ToList();
            }

            if (submitValue.Equals(addRow))
            {
                for (int i = 0; i < 10; i++)
                {
                    vc_quotn_CategoryParam entity = new vc_quotn_CategoryParam();
                    category.Add(entity);
                }
            }
            else
            {
                int count = category.Count;

                if (count < 10)
                {
                    for (int i = 0; i < 10 - count; i++)
                    {
                        vc_quotn_CategoryParam entity = new vc_quotn_CategoryParam();
                        category.Add(entity);
                    }
                }
            }

            return View("CategoryParam/CategoryParamSet", category);
        }
        /*****************************************************************************************/

        //分類參數設定-歷程查詢
        /*****************************************************************************************/
        public ActionResult CategoryParamHIndex(int page = 1)
        {
            var userAd = User.Identity.Name;
            IEnumerable<vc_quotn_CategoryParamHist> allCph = qtCategoryParamService.GetCategoryHList();
            List<CategoryParamList> mainList = new List<CategoryParamList>();

            foreach (vc_quotn_CategoryParamHist listModel in allCph)
            {
                CategoryParamList cpl = new CategoryParamList();
                cpl.Seq = listModel.Seq;
                cpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                cpl.UpdateTime = listModel.UpdateTime;
                mainList.Add(cpl);
            }

            CategoryParamList viewModel = new CategoryParamList();

            viewModel.CategoryParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }
            ViewBag.UserAd = userAd;
            return View("CategoryParam/CategoryParamHIndex", viewModel);
        }

        [HttpPost]
        public ActionResult CategoryParamHIndex(CategoryParamList viewModel, string submitValue)
        {

            if (submitValue != null)
            {

                if (submitValue.Equals(back))
                {
                    return RedirectToAction("CategoryParamHIndex", "PreParameter");
                }

                if (submitValue.Equals(search))
                {
                    var userAd = User.Identity.Name;
                    IEnumerable<vc_quotn_CategoryParamHist> allCph = qtCategoryParamService.GetCategoryHList();
                    List<CategoryParamList> mainList = new List<CategoryParamList>();

                    foreach (vc_quotn_CategoryParamHist listModel in allCph)
                    {
                        CategoryParamList cpl = new CategoryParamList();
                        cpl.Seq = listModel.Seq;
                        cpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                        cpl.UpdateTime = listModel.UpdateTime;
                        mainList.Add(cpl);
                    }

                    viewModel.CategoryParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    if (mainList.Count == 0)
                    {
                        this.AddNotification("查無資料", NotificationType.ERROR);
                    }
                    ViewBag.UserAd = userAd;
                }
                else if (submitValue.Equals(query))
                {
                    String seq = Request["Seq"];
                    long selectKey = (long)(Int64.Parse(seq));
                    IEnumerable<vc_quotn_CategoryParamHist> allTs = qtCategoryParamService.GetCategoryHListBySeq(selectKey);

                    return View("CategoryParam/CategoryParamH", allTs);
                }
            }
            else
            {
                var userAd = User.Identity.Name;
                IEnumerable<vc_quotn_CategoryParamHist> allCph = qtCategoryParamService.GetCategoryHList();
                List<CategoryParamList> mainList = new List<CategoryParamList>();

                foreach (vc_quotn_CategoryParamHist listModel in allCph)
                {
                    CategoryParamList cpl = new CategoryParamList();
                    cpl.Seq = listModel.Seq;
                    cpl.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                    cpl.UpdateTime = listModel.UpdateTime;
                    mainList.Add(cpl);
                }

                viewModel.CategoryParamHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                if (mainList.Count == 0)
                {
                    this.AddNotification("查無資料", NotificationType.ERROR);
                }
                ViewBag.UserAd = userAd;
            }

            return View("CategoryParam/CategoryParamHIndex", viewModel);
        }
        /*****************************************************************************************/

        //區域倍率設定-主檔設定
        /*****************************************************************************************/
        public ActionResult AreaMagM(int page = 1)
        {
            IEnumerable<vc_quotn_AreaParam> getAreas = qtAreaParamService.GetAreas();
            IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
            IEnumerable<vc_quotn_AreaMag> getAreaMags = qtAreaMagService.GetAreaMags();

            List<AreaMagList> mainList = (from a in getAreaMags
                                       join b in getCategorys on a.CategoryId equals b.CategoryId
                                       join c in getAreas on a.AreaId equals c.AreaId
                                       select new AreaMagList
                                       {
                                        AreaId = a.AreaId,
                                        CategoryId = a.CategoryId,
                                        CategoryName = b.CategoryName,
                                        AreaMag = a.AreaMag,
                                        AreaName = c.AreaName
                                       }).ToList();

            List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);

            AreaMagList viewModel = new AreaMagList();

            viewModel.AreaMagListModels = mainList.AsEnumerable().OrderBy(p => p.CategoryId)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }

            ViewBag.ActionList = actionList;

            return View("AreaMag/AreaMagM", viewModel);
        }

        [HttpPost]
        public ActionResult AreaMagM(AreaMagList viewModel, List<AreaMagList> AreaMag, string submitValue)
        {
            if (submitValue.Equals(back))
            {
                return RedirectToAction("AreaMagM", "PreParameter");
            }

            if (submitValue.Equals(submit))
            {
                try
                {
                    AreaMag = null;
                    List<vc_quotn_AreaMag> areaMag = new List<vc_quotn_AreaMag>();

                    string[] keys = Request.Form.AllKeys;
                    for (int i = 0; i < keys.Length; i++)
                    {
                        if (keys[i].Contains("AreaMag"))
                        {
                            String[] key = (keys[i].Split('_')[1]).Split('+');
                            String areaId = key[0];
                            String categoryId = key[1];

                            vc_quotn_AreaMag am = new vc_quotn_AreaMag();
                            am.Memo = Request["memo"];
                            am.AreaId = areaId;
                            am.CategoryId = categoryId;
                            am.AreaMag = Decimal.Parse(Request.Form[keys[i]]);
                            areaMag.Add(am);
                        }
                    }

                    qtAreaMagService.UpdateAreaMags(areaMag, User.Identity.Name);
                    this.AddNotification("更新成功", NotificationType.SUCCESS);
                    return RedirectToAction("AreaMagM", "PreParameter");
                }
                catch (Exception ex)
                {
                    logger.Error("AreaMagSetM Exception : " + ex);
                    this.AddNotification("更新失敗 : " + ExceptionHandle.getExceptionMsg(ex), NotificationType.ERROR);
                    return View("AreaMag/AreaMagSet", AreaMag);
                }
            }

            List<AreaMagList> aml = null;
            if (AreaMag == null)
            {
                IEnumerable<vc_quotn_AreaParam> getAreas = qtAreaParamService.GetAreas();
                IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
                IEnumerable<vc_quotn_AreaMag> getAreaMags = qtAreaMagService.GetAreaMags();

                if (getAreaMags.Count() > 0)
                {
                    aml = (from a in getAreaMags
                               join b in getCategorys on a.CategoryId equals b.CategoryId
                               join c in getAreas on a.AreaId equals c.AreaId
                               select new AreaMagList
                               {
                                   AreaId = a.AreaId,
                                   CategoryId = a.CategoryId,
                                   CategoryName = b.CategoryName,
                                   AreaMag = a.AreaMag,
                                   AreaName = c.AreaName,
                                   Memo = a.Memo
                               }).ToList();
                }
                else
                {
                    aml = new List<AreaMagList>(); 
                    foreach (vc_quotn_CategoryParam category in getCategorys)
                    {
                        foreach (vc_quotn_AreaParam area in getAreas)
                        {
                            AreaMagList entity = new AreaMagList();
                            entity.CategoryId = category.CategoryId;
                            entity.CategoryName = category.CategoryName;
                            entity.AreaId = area.AreaId;
                            entity.AreaName = area.AreaName;
                            entity.AreaMag = 0;
                            entity.Memo = "";
                            aml.Add(entity);
                        }
                    }
                }
            }
            else
            {
                aml = AreaMag;
            }

            return View("AreaMag/AreaMagSet", aml);
        }
        /*****************************************************************************************/

        //區域倍率設定-歷程查詢
        /*****************************************************************************************/
        public ActionResult AreaMagHIndex(int page = 1)
        {
            var userAd = User.Identity.Name;
            IEnumerable<vc_quotn_AreaMagHist> allAmh = qtAreaMagService.GetAreaMagHList();
            List<AreaMagList> mainList = new List<AreaMagList>();

            foreach (vc_quotn_AreaMagHist listModel in allAmh)
            {
                AreaMagList aml = new AreaMagList();
                aml.Seq = listModel.Seq;
                aml.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                aml.UpdateTime = listModel.UpdateTime;
                mainList.Add(aml);
            }

            AreaMagList viewModel = new AreaMagList();

            viewModel.AreaMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }
            ViewBag.UserAd = userAd;
            return View("AreaMag/AreaMagHIndex", viewModel);
        }

        [HttpPost]
        public ActionResult AreaMagHIndex(AreaMagList viewModel, string submitValue)
        {

            if (submitValue != null)
            {

                if (submitValue.Equals(back))
                {
                    return RedirectToAction("AreaMagHIndex", "PreParameter");
                }

                if (submitValue.Equals(search))
                {
                    var userAd = User.Identity.Name;
                    IEnumerable<vc_quotn_AreaMagHist> allAmh = qtAreaMagService.GetAreaMagHList();
                    List<AreaMagList> mainList = new List<AreaMagList>();

                    foreach (vc_quotn_AreaMagHist listModel in allAmh)
                    {
                        AreaMagList aml = new AreaMagList();
                        aml.Seq = listModel.Seq;
                        aml.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                        aml.UpdateTime = listModel.UpdateTime;
                        mainList.Add(aml);
                    }

                    viewModel.AreaMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    if (mainList.Count == 0)
                    {
                        this.AddNotification("查無資料", NotificationType.ERROR);
                    }
                    ViewBag.UserAd = userAd;
                }
                else if (submitValue.Equals(query))
                {
                    String seq = Request["Seq"];
                    long selectKey = (long)(Int64.Parse(seq));

                    IEnumerable<vc_quotn_AreaParam> getAreas = qtAreaParamService.GetAreas();
                    IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
                    IEnumerable<vc_quotn_AreaMagHist> getAreaMags = qtAreaMagService.GetAreaMagHListBySeq(selectKey);

                    List<AreaMagList> mainList = (from a in getAreaMags
                                                  join b in getCategorys on a.CategoryId equals b.CategoryId
                                                  join c in getAreas on a.AreaId equals c.AreaId
                                                  select new AreaMagList
                                                  {
                                                      AreaId = a.AreaId,
                                                      CategoryId = a.CategoryId,
                                                      CategoryName = b.CategoryName,
                                                      AreaMag = a.AreaMag,
                                                      AreaName = c.AreaName,
                                                      Memo = a.Memo
                                                  }).ToList();

                    List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);

                    viewModel = new AreaMagList();

                    viewModel.AreaMagHListModels = mainList.AsEnumerable().OrderBy(p => p.CategoryId)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);


                    return View("AreaMag/AreaMagH", viewModel);
                }
            }
            else
            {
                var userAd = User.Identity.Name;
                IEnumerable<vc_quotn_AreaMagHist> allAmh = qtAreaMagService.GetAreaMagHList();
                List<AreaMagList> mainList = new List<AreaMagList>();

                foreach (vc_quotn_AreaMagHist listModel in allAmh)
                {
                    AreaMagList aml = new AreaMagList();
                    aml.Seq = listModel.Seq;
                    aml.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                    aml.UpdateTime = listModel.UpdateTime;
                    mainList.Add(aml);
                }

                viewModel.AreaMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                if (mainList.Count == 0)
                {
                    this.AddNotification("查無資料", NotificationType.ERROR);
                }
                ViewBag.UserAd = userAd;
            }

            return View("AreaMag/AreaMagHIndex", viewModel);
        }
        /*****************************************************************************************/

        //數量倍率設定-主檔設定
        /*****************************************************************************************/
        public ActionResult QuantityMagM()
        {
            IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
            IEnumerable<vc_quotn_QuantityMag> getCategoryMags = qtQuantityMagService.GetQuantityMags();

            List<QuantityMagList> mainList = (from a in getCategoryMags
                                          join b in getCategorys on a.CategoryId equals b.CategoryId
                                          select new QuantityMagList
                                          {
                                              CategoryId = a.CategoryId,
                                              CategoryName = b.CategoryName,
                                              Color = a.Color,
                                              QtyMag1 = a.QtyMag1,
                                              QtyMag2 = a.QtyMag2,
                                              QtyMag3 = a.QtyMag3,
                                              QtyMag4 = a.QtyMag4,
                                              QtyMag5 = a.QtyMag5
                                          }).ToList();

            List<String> actionList = qtUserService.GetActionByUserFuncId(User.Identity.Name, FUN_MASTER_SETTING);

            QuantityMagList viewModel = new QuantityMagList();

            viewModel.QuantityMagListModels = mainList.AsEnumerable().OrderBy(p => p.CategoryId).ThenBy(p => p.Color)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }

            ViewBag.ActionList = actionList;

            return View("QuantityMag/QuantityMagM", viewModel);
        }

        [HttpPost]
        public ActionResult QuantityMagM(List<QuantityMagList> QuantityMag, string submitValue)
        {
            if (submitValue.Equals(back))
            {
                return RedirectToAction("QuantityMagM", "PreParameter");
            }

            if (submitValue.Equals(submit))
            {
                try
                {
                    List<vc_quotn_QuantityMag> quantity = new List<vc_quotn_QuantityMag>();
                    foreach (QuantityMagList qtyMag in QuantityMag)
                    {
                        vc_quotn_QuantityMag qty = new vc_quotn_QuantityMag();
                        qty.CategoryId = qtyMag.CategoryId;
                        qty.Color = qtyMag.Color;
                        qty.QtyMag1 = qtyMag.QtyMag1;
                        qty.QtyMag2 = qtyMag.QtyMag2;
                        qty.QtyMag3 = qtyMag.QtyMag3;
                        qty.QtyMag4 = qtyMag.QtyMag4;
                        qty.QtyMag5 = qtyMag.QtyMag5;
                        qty.Memo = Request["memo"];
                        quantity.Add(qty);
                    }

                    qtQuantityMagService.UpdateQuantityMags(quantity, User.Identity.Name);
                    this.AddNotification("更新成功", NotificationType.SUCCESS);
                    return RedirectToAction("QuantityMagM", "PreParameter");
                }
                catch (Exception ex)
                {
                    logger.Error("QuantityMagSetM Exception : " + ex);
                    this.AddNotification("更新失敗 : " + ExceptionHandle.getExceptionMsg(ex), NotificationType.ERROR);

                    ViewBag.ColorList = ddl.getColorDownList();
                    ViewBag.CategoryList = qtQuantityMagService.getCategoryDownList();

                    return View("QuantityMag/QuantityMagSet", QuantityMag);
                }
            }

            List<QuantityMagList> quantityMag = null;
            if (QuantityMag == null)
            {
                IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();
                IEnumerable<vc_quotn_QuantityMag> getCategoryMags = qtQuantityMagService.GetQuantityMags();

                quantityMag = (from a in getCategoryMags
                               join b in getCategorys on a.CategoryId equals b.CategoryId
                               select new QuantityMagList
                               {
                                   CategoryId = a.CategoryId,
                                   CategoryName = b.CategoryName,
                                   Color = a.Color,
                                   QtyMag1 = a.QtyMag1,
                                   QtyMag2 = a.QtyMag2,
                                   QtyMag3 = a.QtyMag3,
                                   QtyMag4 = a.QtyMag4,
                                   QtyMag5 = a.QtyMag5,
                                   Memo = a.Memo
                               }).ToList();
            }
            else
            {
                quantityMag = QuantityMag.ToList();
            }

            if (submitValue.Equals(addRow))
            {
                for (int i = 0; i < 10; i++)
                {
                    QuantityMagList entity = new QuantityMagList();
                    quantityMag.Add(entity);
                }
            }
            else
            {
                int count = quantityMag.Count;

                if (count < 10)
                {
                    for (int i = 0; i < 10 - count; i++)
                    {
                        QuantityMagList entity = new QuantityMagList();
                        quantityMag.Add(entity);
                    }
                }
            }

            ViewBag.ColorList = ddl.getColorDownList();
            ViewBag.CategoryList = qtQuantityMagService.getCategoryDownList();

            return View("QuantityMag/QuantityMagSet", quantityMag);
        }
        /*****************************************************************************************/

        //數量倍率設定-歷程查詢
        /*****************************************************************************************/
        public ActionResult QuantityMagHIndex(int page = 1)
        {
            var userAd = User.Identity.Name;
            IEnumerable<vc_quotn_QuantityMagHist> allQmh = qtQuantityMagService.GetQuantityMagHList();
            List<QuantityMagList> mainList = new List<QuantityMagList>();

            foreach (vc_quotn_QuantityMagHist listModel in allQmh)
            {
                QuantityMagList qm = new QuantityMagList();
                qm.Seq = listModel.Seq;
                qm.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                qm.UpdateTime = listModel.UpdateTime;
                mainList.Add(qm);
            }

            QuantityMagList viewModel = new QuantityMagList();

            viewModel.QuantityMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
            if (mainList.Count == 0)
            {
                this.AddNotification("查無資料", NotificationType.ERROR);
            }
            ViewBag.UserAd = userAd;
            return View("QuantityMag/QuantityMagHIndex", viewModel);
        }

        [HttpPost]
        public ActionResult QuantityMagHIndex(QuantityMagList viewModel, string submitValue)
        {

            if (submitValue != null)
            {

                if (submitValue.Equals(back))
                {
                    return RedirectToAction("QuantityMagHIndex", "PreParameter");
                }

                if (submitValue.Equals(search))
                {
                    var userAd = User.Identity.Name;
                    IEnumerable<vc_quotn_QuantityMagHist> allQmh = qtQuantityMagService.GetQuantityMagHList();
                    List<QuantityMagList> mainList = new List<QuantityMagList>();

                    foreach (vc_quotn_QuantityMagHist listModel in allQmh)
                    {
                        QuantityMagList qm = new QuantityMagList();
                        qm.Seq = listModel.Seq;
                        qm.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                        qm.UpdateTime = listModel.UpdateTime;
                        mainList.Add(qm);
                    }

                    viewModel.QuantityMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    if (mainList.Count == 0)
                    {
                        this.AddNotification("查無資料", NotificationType.ERROR);
                    }
                    ViewBag.UserAd = userAd;
                }
                else if (submitValue.Equals(query))
                {
                    String seq = Request["Seq"];
                    long selectKey = (long)(Int64.Parse(seq));
                    IEnumerable<vc_quotn_QuantityMagHist> allQmh = qtQuantityMagService.GetQuantityMagHListBySeq(selectKey);

                    IEnumerable<vc_quotn_CategoryParam> getCategorys = qtCategoryParamService.GetCategorys();

                    List<QuantityMagList> mainList = (from a in allQmh
                                                      join b in getCategorys on a.CategoryId equals b.CategoryId
                                                      select new QuantityMagList
                                                      {
                                                          CategoryId = a.CategoryId,
                                                          CategoryName = b.CategoryName,
                                                          Color = a.Color,
                                                          QtyMag1 = a.QtyMag1,
                                                          QtyMag2 = a.QtyMag2,
                                                          QtyMag3 = a.QtyMag3,
                                                          QtyMag4 = a.QtyMag4,
                                                          QtyMag5 = a.QtyMag5,
                                                          Memo = a.Memo
                                                      }).ToList();

                    viewModel.QuantityMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, int.MaxValue);

                    return View("QuantityMag/QuantityMagH", viewModel);
                }
            }
            else
            {
                var userAd = User.Identity.Name;
                IEnumerable<vc_quotn_QuantityMagHist> allQmh = qtQuantityMagService.GetQuantityMagHList();
                List<QuantityMagList> mainList = new List<QuantityMagList>();

                foreach (vc_quotn_QuantityMagHist listModel in allQmh)
                {
                    QuantityMagList qm = new QuantityMagList();
                    qm.Seq = listModel.Seq;
                    qm.Updator = qtUserService.GetUserByAd(userAd).EmployeeName;
                    qm.UpdateTime = listModel.UpdateTime;
                    mainList.Add(qm);
                }

                viewModel.QuantityMagHListModels = mainList.AsEnumerable().OrderByDescending(p => p.Seq)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                if (mainList.Count == 0)
                {
                    this.AddNotification("查無資料", NotificationType.ERROR);
                }
                ViewBag.UserAd = userAd;
            }

            return View("QuantityMag/QuantityMagHIndex", viewModel);
        }
        /*****************************************************************************************/
    }
}
