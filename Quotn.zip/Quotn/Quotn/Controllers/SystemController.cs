﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CSSystem.Models;
using Base.Data;
using Base.Service.Utils;
using System.Collections;
using Quotn.Service;
using Quotn.Domain;
using TS.Models;
using MvcPaging;
using CSSystem.Web.Helpers;
using System.Web.Security;
using Base.Service;

namespace Quotn.Controllers
{
    public class SystemController : Controller
    {
        private readonly IQtUserService qtUserService;
        private readonly IQtSystemService systemService;
        private readonly DropDownList dropDownList = new DropDownList();
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public SystemController(IQtUserService qtUserService, IQtSystemService systemService)
        {
            this.qtUserService = qtUserService;
            this.systemService = systemService;
        }

        public ActionResult Parameter()
        {
            IEnumerable<vc_quotn_SystemParam> se = systemService.GetSystems();
            se = se.OrderBy(x => x.ParamId).ThenBy(x => x.Order).ToList();

            IEnumerable<vc_quotn_SystemParam> ts;

            ts = se.Select
                                (
                                    x => new vc_quotn_SystemParam
                                    {
                                        ParamId = x.ParamId,
                                        ParamName = x.ParamName,
                                        ParamUm = x.ParamUm,
                                        ParamValue = x.ParamValue,
                                        Updator = qtUserService.GetUserByAd(x.Updator).EmployeeName,
                                        UpdateTime = x.UpdateTime
                                    }
                                ).ToList();

            List<SelectListItem> listItem = dropDownList.getTrueFalseDownList();
            ViewBag.TrueFalseItem = listItem;

            return View(ts);
        }

        public ActionResult EditParameter(IEnumerable<vc_quotn_SystemParam> se)
        {
            try
            {
                var user = User.Identity.Name;
                systemService.UpdateSystem(se, user);
                this.AddNotification("設定系統參數成功", NotificationType.SUCCESS);
            }
            catch (Exception ex)
            {
                logger.Error("SystemController EditParameter Exception : " + ex);
                this.AddNotification("設定系統參數失敗", NotificationType.ERROR);
            }
            return RedirectToAction("Parameter", "System");
        }
    }
}
