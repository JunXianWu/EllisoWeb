﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Quotn.Service;
using CSSystem.Models;
using Base.Data;
using Quotn.Domain;
using MvcPaging;
using System.IO;
using System.Web.Script.Serialization;
using CSSystem.Web.Helpers;
using System.Collections;
using WebMatrix.WebData;
using CSSystem.Filters;
using System.Web.Security;

namespace Quotn.Controllers
{
    public class SecurityController : Controller
    {
        private int PageSize = 0;
        private readonly IQtGroupService groupService;
        private readonly IQtUserService userService;
        private readonly IQtSystemService systemService;
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private QtEasyUITreeHelper _help = new QtEasyUITreeHelper();
        private DomainModel dm;
        private String FUN_GROUP_SETTING = "FUN_GROUP_SETTING";
        private String FUN_USER_SETTING = "FUN_USER_SETTING";

        //one form && multiple submit
        private String add = @Resources.Resource.BTN_ADD;
        private String edit = @Resources.Resource.BTN_EDIT;
        private String delete = @Resources.Resource.BTN_DELETE;
        private String query = @Resources.Resource.BTN_QUERY;

        //群組設定
        /******************************************************************************/
        public SecurityController(IQtGroupService groupService, IQtUserService userService, IQtSystemService systemService, DomainModel dm)
        {
            this.groupService = groupService;
            this.userService = userService;
            this.systemService = systemService;
            this.dm = dm;
            PageSize = Int32.Parse(systemService.GetSystemByKey(1, "分頁", "筆數").ParamValue);
        }

        public ActionResult GroupIndex(int page=0)
        {
            GroupViewModel viewModel  = new GroupViewModel();

            IQueryable<vc_quotn_Group> groups = groupService.GetGroups().AsQueryable();

            List<String> actionList = userService.GetActionByUserFuncId(User.Identity.Name, FUN_GROUP_SETTING);
            ViewBag.ActionList = actionList;

            // 回傳搜尋結果
            viewModel.Groups = groups.OrderBy(p => p.GrpId)
                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult GroupIndex(GroupViewModel viewModel, string submitValue)
        {
            var grpId = "";
            try
            {
                if (submitValue != null)
                {
                    if (submitValue.Equals(add))
                    {
                        var rootNode = this._help.GetRootNode();
                        var nodes = this._help.GetNodes();
                        TreeViewModel model = new TreeViewModel
                        {
                            RootNode = rootNode,
                            TreeNodes = nodes.ToList()
                        };

                        return View("GroupAdd", model);
                    }
                    else if (submitValue.Equals(edit))
                    {
                        grpId = Request["GroupId"].Trim().Replace(",", "");
                        var rootNode = this._help.GetRootNode();
                        var nodes = this._help.GetNodes();
                        TreeViewModel model = new TreeViewModel
                        {
                            RootNode = rootNode,
                            TreeNodes = nodes.ToList()
                        };

                        Hashtable ht = groupService.GetGroupFunction(Int32.Parse(grpId));

                        IEnumerable<vc_quotn_Employee> users = userService.GetUsers();

                        ViewBag.GrpId = ht["GrpId"];
                        ViewBag.GroupName = ht["GrpName"];
                        ViewBag.FuncId = ht["FuncId"];
                        ViewBag.Users = users;

                        return View("GroupEdit", model);
                    }
                    else if (submitValue.Equals(delete))
                    {
                        try
                        {
                            grpId = Request["GroupId"].Trim().Replace(",", "");
                            groupService.DeleteGroupFunction(Int32.Parse(grpId));
                            this.AddNotification(@Resources.Resource.MSG_DELETE_SUCCESS, NotificationType.SUCCESS);
                        }
                        catch (Exception ex)
                        {
                            logger.Error("SecurityController Delete Exception : " + ex.StackTrace);
                            this.AddNotification(@Resources.Resource.MSG_DELETE_FAIL, NotificationType.ERROR);
                        }
                    }
                    else if (submitValue.Equals(query))
                    {
                        grpId = Request["GroupId"].Trim().Replace(",", "");
                        var rootNode = this._help.GetRootNode();
                        var nodes = this._help.GetNodes();
                        TreeViewModel model = new TreeViewModel
                        {
                            RootNode = rootNode,
                            TreeNodes = nodes.ToList()
                        };

                        Hashtable ht = groupService.GetGroupFunction(Int32.Parse(grpId));

                        IEnumerable<vc_quotn_Employee> users = userService.GetUsers();

                        ViewBag.GrpId = ht["GrpId"];
                        ViewBag.GroupName = ht["GrpName"];
                        ViewBag.FuncId = ht["FuncId"];
                        ViewBag.Users = users;

                        return View("GroupQuery", model);
                    }
                    else
                    {
                        IQueryable<vc_quotn_Group> groups = groupService.GetGroups().AsQueryable();

                        // 如果有輸入群組名稱作為搜尋條件時
                        if (!string.IsNullOrWhiteSpace(viewModel.GroupName))
                        { groups = groups.Where(p => p.GrpName.Contains(viewModel.GroupName)); }

                        // 回傳搜尋結果
                        viewModel.Groups = groups.OrderBy(p => p.GrpId)
                                                    .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    }
                }
                else {
                    IQueryable<vc_quotn_Group> groups = groupService.GetGroups().AsQueryable();

                    // 如果有輸入群組名稱作為搜尋條件時
                    if (!string.IsNullOrWhiteSpace(viewModel.GroupName))
                    { groups = groups.Where(p => p.GrpName.Contains(viewModel.GroupName)); }

                    // 回傳搜尋結果
                    viewModel.Groups = groups.OrderBy(p => p.GrpId)
                                                .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);               
                }
            }catch(Exception ex){
                logger.Error("SecurityController GroupIndex Exception : " + ex.StackTrace);
            }

            List<String> actionList = userService.GetActionByUserFuncId(User.Identity.Name, FUN_GROUP_SETTING);
            ViewBag.ActionList = actionList;

            IQueryable<vc_quotn_Group> group = groupService.GetGroups().AsQueryable();
            if (!string.IsNullOrWhiteSpace(viewModel.GroupName))
            { group = group.Where(p => p.GrpName.Contains(viewModel.GroupName)); }
            viewModel.Groups = group.OrderBy(p => p.GrpId)
                                        .ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
              
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult GroupAdd()
        {
            var grpName = Request["grpName"];
            var funcId = Request["funcId"];
            var user = User.Identity.Name;
            var err = false;

            if (grpName.Equals("")) {
                this.AddNotification("群組名稱不得為空", NotificationType.ERROR);
                err = true;
            }

            if (funcId==null)
            {
                this.AddNotification("功能不得為空", NotificationType.ERROR);
                err = true;
            }

            if (err) {
                var rootNode = this._help.GetRootNode();
                var nodes = this._help.GetNodes();
                TreeViewModel model = new TreeViewModel
                {
                    RootNode = rootNode,
                    TreeNodes = nodes.ToList()
                };

                ViewBag.GroupName = grpName;

                int[] FuncId = null;
                Hashtable ht = new Hashtable();
                if (funcId != null)
                {
                    string[] funcIdArr = funcId.Split(',');
                    FuncId = Array.ConvertAll<string, int>(funcIdArr, int.Parse);
                }

                ht.Add("FuncId", FuncId);

                ViewBag.FuncId = ht["FuncId"];

                return View("GroupAdd", model);
            }

            try
            {
                groupService.CreateGroupFunction(grpName, funcId,user);
                this.AddNotification(@Resources.Resource.MSG_ADD_SUCCESS, NotificationType.SUCCESS);
            }catch(Exception ex){
                logger.Error("SecurityController AddGroup Exception : " + ex.StackTrace);
                this.AddNotification(@Resources.Resource.MSG_ADD_FAIL, NotificationType.ERROR);
            }
            return RedirectToAction("GroupIndex");
        }

        [HttpPost]
        public ActionResult GroupEdit()
        {
            var grpId = Request["grpId"];
            var grpName = Request["grpName"];
            var funcId = Request["funcId"];
            var user = User.Identity.Name;

            var err = false;

            if (grpName.Equals(""))
            {
                this.AddNotification("群組名稱不得為空", NotificationType.ERROR);
                err = true;
            }

            if (funcId == null)
            {
                this.AddNotification("功能不得為空", NotificationType.ERROR);
                err = true;
            }

            if (err)
            {
                var rootNode = this._help.GetRootNode();
                var nodes = this._help.GetNodes();
                TreeViewModel model = new TreeViewModel
                {
                    RootNode = rootNode,
                    TreeNodes = nodes.ToList()
                };

                ViewBag.GrpId = grpId;
                ViewBag.GroupName = grpName;

                int[] FuncId = null;
                Hashtable ht = new Hashtable();
                if (funcId != null)
                {
                    string[] funcIdArr = funcId.Split(',');
                    FuncId = Array.ConvertAll<string, int>(funcIdArr, int.Parse);
                }

                ht.Add("FuncId", FuncId);

                ViewBag.FuncId = ht["FuncId"];

                IEnumerable<vc_quotn_Employee> users = userService.GetUsers();
                ViewBag.Users = users;

                return View("GroupEdit", model);
            }

            try
            {
                groupService.EditGroupFunction(Int32.Parse(grpId), grpName, funcId, user);
                this.AddNotification(@Resources.Resource.MSG_EDIT_SUCCESS, NotificationType.SUCCESS);
            }
            catch (Exception ex)
            {
                logger.Error("SecurityController EditGroup Exception : " + ex.StackTrace);
                this.AddNotification(@Resources.Resource.MSG_EDIT_FAIL, NotificationType.ERROR);
            }
            return RedirectToAction("GroupIndex");
        }
        /******************************************************************************/

        //使用者
        /******************************************************************************/
        [Quotn.Filters.ActionFilter]
        public ActionResult UserIndex(int page = 0)
        {
            UserViewModel viewModel = new UserViewModel();

            var getUsers = userService.GetUsers().AsQueryable();

            List<String> actionList = userService.GetActionByUserFuncId(User.Identity.Name, FUN_USER_SETTING);
            ViewBag.ActionList = actionList;

            // 回傳搜尋結果
            viewModel.Users = getUsers.OrderBy(p => p.EmployeeId).ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);  

            return View(viewModel);
        }

        [HttpPost]
        public ActionResult UserIndex(UserViewModel viewModel, string submitValue)
        {
            var userId = "";
            try
            {
                if (submitValue != null)
                {
                    if (submitValue.Equals(add))
                    {
                        var groupList = groupService.GetGroups().ToList();
                        groupList.Insert(0, new vc_quotn_Group() { GrpId = -1, GrpName = @Resources.Resource.FLD_GROUP_NAME});
                        SelectList selectList = new SelectList(groupList, "GrpId", "GrpName");
                        ViewBag.GroupList = selectList;
                        ModelState.Clear();
                        return View("UserAdd");
                    }
                    else if (submitValue.Equals(edit))
                    {
                        userId = Request["UserId"].Trim().Replace(",", "");
                        vc_quotn_Employee ue = userService.GetUserById(userId);
                        UserViewModel model = new UserViewModel();
                        model.UserAd = ue.EmployeeAd;
                        model.UserId = ue.EmployeeId;
                        model.UserName = ue.EmployeeName;
                        model.DepartmentId = ue.DepartmentId;
                        model.GrpId = ue.GrpId;
                        model.CreateUser = ue.Creator;
                        model.CreateDate = ue.CreateTime;
                        model.UpdateUser = ue.Updator;
                        model.UpdateDate = ue.UpdateTime;

                        ViewBag.Enabled = ue.Enabled;

                        var groupList = groupService.GetGroups().ToList();
                        groupList.Insert(0, new vc_quotn_Group() { GrpId = -1, GrpName = "" });
                        SelectList selectList = new SelectList(groupList, "GrpId", "GrpName", model.GrpId);
                        ViewBag.GroupList = selectList;

                        return View("UserEdit", model);
                    }
                    else if (submitValue.Equals(delete))
                    {
                        try
                        {
                            userId = Request["UserId"].Trim().Replace(",", "");
                            userService.DeleteUser(userId);
                            this.AddNotification(@Resources.Resource.MSG_DELETE_SUCCESS, NotificationType.SUCCESS);
                        }
                        catch (Exception ex)
                        {
                            logger.Error("SecurityController Delete Exception : " + ex.StackTrace);
                            this.AddNotification(@Resources.Resource.MSG_DELETE_FAIL, NotificationType.ERROR);
                        }
                    }
                    else if (submitValue.Equals(query))
                    {
                        userId = Request["UserId"].Trim().Replace(",", "");
                        vc_quotn_Employee ue = userService.GetUserById(userId);
                        UserViewModel model = new UserViewModel();
                        model.UserAd = ue.EmployeeAd;
                        model.UserId = ue.EmployeeId;
                        model.UserName = ue.EmployeeName;
                        model.DepartmentId = ue.DepartmentId;
                        model.GrpId = ue.GrpId;
                        model.CreateUser = ue.Creator;
                        model.CreateDate = ue.CreateTime;
                        model.UpdateUser = ue.Updator;
                        model.UpdateDate = ue.UpdateTime;

                        ViewBag.Enabled = ue.Enabled;

                        var groupList = groupService.GetGroups().ToList();
                        groupList.Insert(0, new vc_quotn_Group() { GrpId = -1, GrpName = @Resources.Resource.FLD_GROUP_NAME });
                        SelectList selectList = new SelectList(groupList, "GrpId", "GrpName", model.GrpId);
                        ViewBag.GroupList = selectList;

                        return View("UserQuery", model);
                    }
                    else
                    {
                        var getUsers = userService.GetUsers().AsQueryable();

                        // 如果有輸入使用者代號作為搜尋條件時
                        if (!string.IsNullOrWhiteSpace(viewModel.UserId))
                        { getUsers = getUsers.Where(p => p.EmployeeId.Contains(viewModel.UserId)); }

                        // 如果有輸入使用者名稱作為搜尋條件時
                        if (!string.IsNullOrWhiteSpace(viewModel.UserName))
                        { getUsers = getUsers.Where(p => p.EmployeeName.Contains(viewModel.UserName)); }

                        // 回傳搜尋結果
                        viewModel.Users = getUsers.OrderBy(p => p.EmployeeId).ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);
                    }
                }
                else {
                    var getUsers = userService.GetUsers().AsQueryable();

                    // 如果有輸入使用者代號作為搜尋條件時
                    if (!string.IsNullOrWhiteSpace(viewModel.UserId))
                    { getUsers = getUsers.Where(p => p.EmployeeId.Contains(viewModel.UserId)); }

                    // 如果有輸入使用者名稱作為搜尋條件時
                    if (!string.IsNullOrWhiteSpace(viewModel.UserName))
                    { getUsers = getUsers.Where(p => p.EmployeeName.Contains(viewModel.UserName)); }

                    // 回傳搜尋結果
                    viewModel.Users = getUsers.OrderBy(p => p.EmployeeId).ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize);              
                }
            }
            catch (Exception ex)
            {
                logger.Error("SecurityController UserIndex Exception : " + ex.StackTrace);
            }

            List<String> actionList = userService.GetActionByUserFuncId(User.Identity.Name, FUN_USER_SETTING);
            ViewBag.ActionList = actionList;

            var getUser = userService.GetUsers().AsQueryable();
            if (!string.IsNullOrWhiteSpace(viewModel.UserId))
            { getUser = getUser.Where(p => p.EmployeeId.Contains(viewModel.UserId)); }
            if (!string.IsNullOrWhiteSpace(viewModel.UserName))
            { getUser = getUser.Where(p => p.EmployeeName.Contains(viewModel.UserName)); }
            viewModel.Users = getUser.OrderBy(p => p.EmployeeId).ToPagedList(viewModel.Page > 0 ? viewModel.Page - 1 : 0, PageSize); 

            return View(viewModel);
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        [Authorize]
        [InitializeSimpleMembership]
        public ActionResult UserAdd(UserViewModel model)
        {
            byte enabled = (Request["Enabled"] != null && Request["Enabled"].Equals("on")) ? (byte)1 : (byte)0;
            var user = User.Identity.Name;
            DateTime currentTime = DateTime.Now;

            try
            {
                if (ModelState.IsValid)
                {
                    vc_quotn_Employee employee = new vc_quotn_Employee();
                    employee.EmployeeId = model.UserId;
                    employee.EmployeeAd = model.UserAd;
                    employee.DepartmentId = model.DepartmentId;
                    employee.EmployeeName = model.UserName;
                    employee.GrpId = model.GrpId;
                    employee.Enabled = enabled;
                    employee.Creator = user;
                    employee.CreateTime = currentTime;
                    employee.Updator = user;
                    employee.UpdateTime = currentTime;

                    userService.CreateUser(employee);

                    this.AddNotification(@Resources.Resource.MSG_ADD_SUCCESS, NotificationType.SUCCESS);
                }
                else 
                {
                    var groupList = groupService.GetGroups().ToList();
                    groupList.Insert(0, new vc_quotn_Group() { GrpId = -1, GrpName = @Resources.Resource.FLD_GROUP_NAME });
                    SelectList selectList = new SelectList(groupList, "GrpId", "GrpName");
                    ViewBag.GroupList = selectList;

                    return View("UserAdd", model);
                }
            }
            catch (Exception ex)
            {
                logger.Error("SecurityController AddUser Exception : " + ex.StackTrace);
                this.AddNotification(@Resources.Resource.MSG_ADD_FAIL, NotificationType.ERROR);
            }
            return RedirectToAction("UserIndex");
        }

        [HttpPost]
        public ActionResult UserEdit(UserViewModel model)
        {
            byte enabled = (Request["Enabled"] != null && Request["Enabled"].Equals("on")) ? (byte)1 : (byte)0;
            var user = User.Identity.Name;
            DateTime currentTime = DateTime.Now;

            try
            {
                vc_quotn_Employee ue = userService.GetUserById(model.UserId);
                ue.EmployeeAd = model.UserAd;
                ue.EmployeeId = model.UserId;
                ue.EmployeeName = model.UserName;
                ue.DepartmentId = model.DepartmentId;
                ue.GrpId = model.GrpId;
                ue.Updator = user;
                ue.UpdateTime = currentTime;

                userService.UpdateUser(ue);

                this.AddNotification(@Resources.Resource.MSG_EDIT_SUCCESS, NotificationType.SUCCESS);
            }
            catch (Exception ex)
            {
                logger.Error("SecurityController EditUser Exception : " + ex.StackTrace);
                this.AddNotification(@Resources.Resource.MSG_EDIT_FAIL, NotificationType.ERROR);
            }
            return RedirectToAction("UserIndex");
        }

        /******************************************************************************/
    }
}
