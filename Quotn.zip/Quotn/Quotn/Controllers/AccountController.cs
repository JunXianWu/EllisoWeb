﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using CSSystem.Filters;
using CSSystem.Models;
using CSSystem.Web.Helpers;
using Quotn.Service;
using Base.Service.Utils;
using Quotn.Domain;

namespace Quotn.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private readonly IQtUserService qtUserService;

        public AccountController(IQtUserService qtUserService, DomainModel dm)
        {
            this.qtUserService = qtUserService;
        }

        //
        // GET: /Account/Login

        [AllowAnonymous]
        public ActionResult Login()
        {
            var src = Request["src"];
            ViewBag.src = src;
            return View();
        }

        //
        // POST: /Account/Login

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            if (model.UserName == null || model.Password == null)
            {
                ModelState.AddModelError("", @Resources.Resource.MSG_USER_PASSWORD_ERR);
                return View(model);
            }
            var src = Request["src"];

            if (!src.Equals("DB"))
            {
                string adPath = "LDAP://univacco.com.tw/DC=univacco,DC=com,DC=tw";
                LdapAuthentication adAuth = new LdapAuthentication(adPath);
                if (adAuth.IsAuthenticated("univacco.com.tw", model.UserName, model.Password) == true)
                {
                    var EmployeeName = adAuth.GetUserName("univacco.com.tw", model.UserName, model.Password);
                    // 登入時清空所有 Session 資料
                    Session.RemoveAll();
                    Session.Add("UserAd", model.UserName);
                    Session.Add("UserName", EmployeeName);

                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                      model.UserName,//你想要存放在 User.Identy.Name 的值，通常是使用者帳號
                      DateTime.Now,
                      DateTime.Now.AddMinutes(FormsAuthentication.Timeout.TotalMinutes),
                      false,//將管理者登入的 Cookie 設定成 Session Cookie
                      EmployeeName + "," + model.UserName,//userdata看你想存放啥
                      FormsAuthentication.FormsCookiePath);

                    string encTicket = FormsAuthentication.Encrypt(ticket);

                    Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    adPath = "LDAP://MCTFILM.com/DC=MCTFILM,DC=com";
                    LdapAuthentication adAuth_MCT = new LdapAuthentication(adPath);
                    if (adAuth_MCT.IsAuthenticated("MCTFILM.com", model.UserName, model.Password) == true)
                    {
                        //var EmployeeName = adAuth.GetUserName("univacco.com.tw", model.UserName, model.Password);
                        var EmployeeName="";
                        var employee = qtUserService.GetUserByAd(model.UserName);
                        if (employee != null)
                        {
                            EmployeeName = employee.EmployeeName;
                        }
                        // 登入時清空所有 Session 資料
                        Session.RemoveAll();
                        Session.Add("UserAd", model.UserName);
                        Session.Add("UserName", EmployeeName);

                        FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                          model.UserName,//你想要存放在 User.Identy.Name 的值，通常是使用者帳號
                          DateTime.Now,
                          DateTime.Now.AddMinutes(FormsAuthentication.Timeout.TotalMinutes),
                          false,//將管理者登入的 Cookie 設定成 Session Cookie
                          EmployeeName + "," + model.UserName,//userdata看你想存放啥
                          FormsAuthentication.FormsCookiePath);

                        string encTicket = FormsAuthentication.Encrypt(ticket);

                        Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));
                        return RedirectToAction("Index", "Home");
                    }
                }
            }
            else {
                var employee = qtUserService.GetUserByAd(model.UserName);
                if (employee != null) 
                {
                    // 登入時清空所有 Session 資料
                    Session.RemoveAll();
                    Session.Add("UserAd", model.UserName);
                    Session.Add("UserName", employee.EmployeeName);
                    Session.Add("src", "DB");

                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                      model.UserName,//你想要存放在 User.Identy.Name 的值，通常是使用者帳號
                      DateTime.Now,
                      DateTime.Now.AddMinutes(FormsAuthentication.Timeout.TotalMinutes),
                      false,//將管理者登入的 Cookie 設定成 Session Cookie
                      employee.EmployeeName + "," + model.UserName+",DB",//userdata看你想存放啥
                      FormsAuthentication.FormsCookiePath);

                    string encTicket = FormsAuthentication.Encrypt(ticket);

                    Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, encTicket));

                    return RedirectToAction("Index", "Home");
                }
            }

            // 如果執行到這裡，發生某項失敗，則重新顯示表單
            ModelState.AddModelError("", @Resources.Resource.MSG_USER_PASSWORD_ERR);
            return View(model);
        }

        //
        // POST: /Account/LogOff

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Clear();  // This may not be needed -- but can't hurt
            Session.Abandon();

            // Clear authentication cookie
            HttpCookie rFormsCookie = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            rFormsCookie.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(rFormsCookie);

            // Clear session cookie 
            HttpCookie rSessionCookie = new HttpCookie("ASP.NET_SessionId", "");
            rSessionCookie.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(rSessionCookie);

            return RedirectToAction("Index", "Home");
        }
    }
}
